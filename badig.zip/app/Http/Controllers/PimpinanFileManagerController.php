<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\DataAttachment;
use App\Services\SecureMediaStorage;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PimpinanFileManagerController extends Controller
{
    private const ALLOWED_TYPES = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt', 'ppt', 'pptx'];
    private array $units = [
        'unit1' => 'Unit 1',
        'unit2' => 'Unit 2',
        'unit3' => 'Unit 3',
        'unit4' => 'Unit 4',
    ];

    public function index(Request $request)
    {
        $this->authorizeSuperAdmin();
        [$query, $filters] = $this->filteredQuery($request);
        $attachments = $query->latest()->paginate(20)->withQueryString();
        $units = $this->units;

        return view('pimpinan.file-manager', compact('attachments', 'filters', 'units'));
    }

    public function export(Request $request, string $type)
    {
        $this->authorizeSuperAdmin();
        abort_unless($type === 'pdf', 404);
        [$query, $filters] = $this->filteredQuery($request);
        $attachments = $query->latest()->limit(1000)->get();
        $units = $this->units;

        AuditLog::record('GLOBAL_FILE_MANAGER_EXPORT_PDF', 'Export PDF File Manager Semua Unit total '.$attachments->count().' file.');

        @ini_set('memory_limit', '512M');
        @set_time_limit(300);

        return Pdf::loadView('units.report-pdf', [
            'unit' => 'all',
            'module' => ['title' => 'File Manager Semua Unit'],
            'items' => collect(),
            'filters' => $filters,
            'attachmentCounts' => collect(),
            'globalAttachments' => $attachments,
            'units' => $units,
        ])->setPaper('a4', 'landscape')
            ->stream(Str::slug('BADIG file manager semua unit '.now()->format('Ymd His')).'.pdf');
    }

    public function downloadAttachment(int $attachment, SecureMediaStorage $storage)
    {
        $this->authorizeSuperAdmin();
        $file = DataAttachment::query()->findOrFail($attachment);
        AuditLog::record('DOWNLOAD_ATTACHMENT_SUPER_ADMIN', 'Download lampiran '.$file->original_name.' record #'.$file->record_id);

        return $storage->download($file->file_path, $file->original_name);
    }

    public function deleteAttachment(int $attachment, SecureMediaStorage $storage)
    {
        $this->authorizeSuperAdmin();
        $file = DataAttachment::query()->findOrFail($attachment);
        $storage->delete($file->file_path);
        $file->delete();
        AuditLog::record('DELETE_ATTACHMENT_SUPER_ADMIN', 'Menghapus lampiran '.$file->original_name.' record #'.$file->record_id);

        return back()->with('success', 'File berhasil dihapus.');
    }

    private function filteredQuery(Request $request): array
    {
        $filters = $request->validate([
            'q' => ['nullable', 'string', 'max:200'],
            'unit' => ['nullable', 'string', 'in:all,unit1,unit2,unit3,unit4'],
            'type' => ['nullable', 'string', 'in:'.implode(',', self::ALLOWED_TYPES)],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
        ]);

        $filters = [
            'q' => trim((string) ($filters['q'] ?? '')),
            'unit' => (string) ($filters['unit'] ?? 'all'),
            'type' => trim((string) ($filters['type'] ?? '')),
            'date_from' => (string) ($filters['date_from'] ?? ''),
            'date_to' => (string) ($filters['date_to'] ?? ''),
        ];

        $query = DataAttachment::query()->with('uploader');

        if ($filters['unit'] !== 'all') {
            $query->where('unit', $filters['unit']);
        }
        if ($filters['q'] !== '') {
            $q = $filters['q'];
            $query->where(function ($sub) use ($q): void {
                $sub->where('original_name', 'like', '%'.$q.'%')
                    ->orWhere('extension', 'like', '%'.$q.'%');

                if (is_numeric($q)) {
                    $sub->orWhere('record_id', (int) $q);
                }
            });
        }
        if ($filters['type'] !== '') {
            $query->where('extension', strtolower($filters['type']));
        }
        if ($filters['date_from'] !== '') {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }
        if ($filters['date_to'] !== '') {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }

        return [$query, $filters];
    }

    private function authorizeSuperAdmin(): void
    {
        abort_unless(auth()->user()?->isSuperAdmin(), 403, 'Akses hanya untuk Super Admin.');
    }
}
