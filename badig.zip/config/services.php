<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'static_map' => [
        'enabled' => env('STATIC_MAP_REMOTE_ENABLED', false),
        'url' => env('STATIC_MAP_REMOTE_URL', 'https://staticmap.openstreetmap.de/staticmap.php'),
        'max_bytes' => (int) env('STATIC_MAP_MAX_BYTES', 5242880),
        'allowed_hosts' => array_values(array_filter(array_map('trim', explode(',', (string) env('STATIC_MAP_ALLOWED_HOSTS', 'staticmap.openstreetmap.de'))))),
    ],

];
