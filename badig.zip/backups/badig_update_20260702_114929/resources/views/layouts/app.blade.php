<!DOCTYPE html>
<html class="light" lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BADIG | @yield('title', 'Dashboard')</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                colors: {
                    primary: "#001143", "primary-container": "#16275b", "on-primary": "#ffffff", "on-primary-container": "#808fca",
                    "primary-fixed-dim": "#b6c4ff", secondary: "#505f76", "secondary-container": "#d0e1fb", "on-secondary-container": "#54647a",
                    "secondary-fixed-dim": "#b7c8e1", surface: "#fbf8fe", "surface-container-lowest": "#ffffff", "surface-container-low": "#f5f3f8",
                    "surface-container": "#efedf2", "surface-container-high": "#e9e7ec", "surface-container-highest": "#e4e1e7",
                    "on-surface": "#1b1b1f", "on-surface-variant": "#45464f", outline: "#757680", "outline-variant": "#c5c6d1",
                    error: "#ba1a1a", "error-container": "#ffdad6", "on-error-container": "#93000a", "tertiary-fixed": "#ffdbc8", "on-tertiary-fixed": "#311300"
                },
                borderRadius: { DEFAULT: "0.25rem", lg: "0.5rem", xl: "0.75rem", "2xl": "1rem", "3xl": "1.5rem", full: "9999px" },
                spacing: { gutter: "24px", md: "16px", lg: "24px", xl: "32px" }
            } }
        }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #eeeff3; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #c5c6d1; border-radius: 10px; }

        /* Animasi Transisi Halus untuk Efek Sidebar Collapse */
        .sidebar-animate {
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
                        margin 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
                        transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
                        padding 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Modifikasi Layout Khusus Mode Desktop Ringkas (Mini State) */
        @media (min-width: 1024px) {
            body.sidebar-mini .sidebar-text-hide {
                display: none !important;
                opacity: 0;
            }
            body.sidebar-mini aside {
                width: 5rem !important; /* Lebar menyusut ke 80px */
                padding-left: 0.75rem !important;
                padding-right: 0.75rem !important;
            }
            body.sidebar-mini main {
                margin-left: 5rem !important;
            }
            body.sidebar-mini header {
                width: calc(100% - 5rem) !important;
            }
            body.sidebar-mini aside nav a {
                justify-content: center !important;
                padding-left: 0 !important;
                padding-right: 0 !important;
                gap: 0 !important;
            }
        }

        /* Pengkondisian Khusus HP & Tablet (Overlay Drawer Mode) */
        @media (max-width: 1023px) {
            body.mobile-sidebar-open {
                overflow: hidden;
            }
            body.mobile-sidebar-open aside {
                transform: translateX(0) !important;
            }
        }

        /* SIBDI responsive refinement */
        .leaflet-container, canvas, iframe { max-width: 100%; }
        @media (max-width: 640px) {
            h2 { word-break: break-word; }
            table { font-size: 12px; }
            .leaflet-popup-content { width: 220px !important; }
        }
        @media (min-width: 641px) and (max-width: 1023px) {
            .leaflet-popup-content { width: 260px !important; }
        }
    </style>
</head>
<body class="text-on-surface antialiased">
@auth
    <div id="sidebarBackdrop" class="fixed inset-0 bg-black/40 z-40 hidden lg:hidden transition-opacity duration-300"></div>

    <aside class="h-screen w-72 flex flex-col fixed left-0 top-0 bg-primary shadow-xl z-50 py-6 px-4 text-on-primary -translate-x-full lg:translate-x-0 sidebar-animate">
        
        <div class="flex items-center gap-3 mb-8 px-2 shrink-0">
            <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-md shrink-0 overflow-hidden">
                <img src="{{ asset('images/logo-badig.png') }}" alt="Logo BADIG" class="w-9 h-9 object-contain" onerror="this.style.display='none'; this.nextElementSibling.style.display='inline-flex';">
                <span class="material-symbols-outlined text-primary text-2xl font-bold" style="display:none;">military_tech</span>
            </div>
            <div class="sidebar-text-hide whitespace-nowrap overflow-hidden">
                <h1 class="font-bold text-lg leading-tight tracking-wide">BADIG</h1>
                <p class="text-xs opacity-70">Basis Data Terintegrasi Sat Intelkam</p>
            </div>
        </div>

        <nav class="flex-1 space-y-1.5 overflow-y-auto custom-scrollbar pr-1">
            <a class="flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all duration-200 {{ request()->routeIs('dashboard') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('dashboard') }}">
                <span class="material-symbols-outlined shrink-0">dashboard</span>
                <span class="text-sm sidebar-text-hide whitespace-nowrap">Dashboard</span>
            </a>

            @if(in_array((int) auth()->user()->role_id, [1,5], true) && Route::has('pimpinan.file-manager'))
                <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('pimpinan.file-manager') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('pimpinan.file-manager') }}">
                    <span class="material-symbols-outlined shrink-0">folder_managed</span>
                    <span class="text-sm sidebar-text-hide whitespace-nowrap">File Manager Semua Unit</span>
                </a>
            @endif

            @if((int) auth()->user()->role_id === 5 && Route::has('super-admin.index'))
                <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('super-admin.*') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('super-admin.index') }}">
                    <span class="material-symbols-outlined shrink-0">admin_panel_settings</span>
                    <span class="text-sm sidebar-text-hide whitespace-nowrap">Super Admin IT</span>
                </a>
            @endif

            @if(auth()->user()->role_id !== 4)
                @php
                    $units = [
                        'unit1' => ['label' => 'Unit 1 Ideologi', 'icon' => 'security'],
                        'unit2' => ['label' => 'Unit 2 Ekonomi', 'icon' => 'shield'],
                        'unit3' => ['label' => 'Unit 3 Sosbud', 'icon' => 'gavel'],
                        'unit4' => ['label' => 'Unit 4 Keamanan', 'icon' => 'military_tech']
                    ];
                @endphp
                @foreach($units as $key => $data)
                    @if(auth()->user()->role_id !== 2 || auth()->user()->unit_id === (int) substr($key, -1))
                        <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->is('data/'.$key.'*') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('units.index', $key) }}">
                            <span class="material-symbols-outlined shrink-0">{{ $data['icon'] }}</span>
                            <span class="text-sm sidebar-text-hide whitespace-nowrap">{{ $data['label'] }}</span>
                        </a>
                    @endif
                @endforeach
            @endif

            @if(in_array((int) auth()->user()->role_id, [3,5], true))
                <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('reports.*') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('reports.index') }}">
                    <span class="material-symbols-outlined shrink-0">description</span>
                    <span class="text-sm sidebar-text-hide whitespace-nowrap">Validasi Laporan</span>
                </a>
            @endif

            @if(in_array((int) auth()->user()->role_id, [4,5], true))
                <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('admin.users') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('admin.users') }}">
                    <span class="material-symbols-outlined shrink-0">manage_accounts</span>
                    <span class="text-sm sidebar-text-hide whitespace-nowrap">Manajemen User</span>
                </a>
                <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('admin.audit') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('admin.audit') }}">
                    <span class="material-symbols-outlined shrink-0">receipt_long</span>
                    <span class="text-sm sidebar-text-hide whitespace-nowrap">Audit Trail</span>
                </a>
                <a class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('admin.backup') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}" href="{{ route('admin.backup') }}">
                    <span class="material-symbols-outlined shrink-0">database</span>
                    <span class="text-sm sidebar-text-hide whitespace-nowrap">Backup Sistem</span>
                </a>
                @if(Route::has('admin.backup.files'))
                    <a href="{{ route('admin.backup.files') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ request()->routeIs('admin.backup.files') ? 'bg-secondary-container text-on-secondary-container font-bold' : 'text-on-primary opacity-80 hover:opacity-100 hover:bg-primary-container' }}">
                        <span class="material-symbols-outlined shrink-0">folder_zip</span>
                        <span class="text-sm sidebar-text-hide whitespace-nowrap">File Backup</span>
                    </a>
                @endif
            @endif
        </nav>

        <div class="mt-auto pt-4 border-t border-on-primary/10 px-2 shrink-0 flex items-center gap-3 min-h-[50px]">
            <div class="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-xs shrink-0 text-white shadow-inner">
                {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
            </div>
            <div class="sidebar-text-hide overflow-hidden truncate">
                <div class="text-[10px] opacity-60 uppercase tracking-wider leading-none">Pengguna Aktif</div>
                <div class="font-bold text-sm truncate mt-0.5">{{ auth()->user()->name }}</div>
                <div class="text-[10px] text-tertiary-fixed font-medium truncate mt-0.5">{{ auth()->user()->roleName() }}</div>
            </div>
        </div>
    </aside>

    <main class="ml-0 lg:ml-72 min-h-screen flex flex-col sidebar-animate">
        
        <header class="fixed top-0 right-0 w-full lg:w-[calc(100%-288px)] backdrop-blur-xl bg-surface/80 border-b border-outline-variant z-40 flex justify-between items-center h-16 px-3 sm:px-6 sidebar-animate">
            
            <div class="flex items-center gap-4">
                <button type="button" id="sidebarToggleBtn" class="p-2 rounded-xl text-secondary hover:bg-surface-container-high transition-colors flex items-center justify-center focus:outline-none active:scale-95">
                    <span class="material-symbols-outlined text-[24px]">menu</span>
                </button>

                <div class="flex items-center gap-3  px-4 py-1.5 rounded-full focus-within:ring-2 focus-within:ring-primary transition-all">
                </div>
            </div>

            <div class="flex items-center gap-4">
                <div class="text-right text-xs text-on-surface-variant opacity-80 hidden sm:block">
                    <div class="font-semibold">{{ now()->format('d M Y H:i') }}</div>
                    <div class="text-[10px] text-secondary">Sesi otomatis 30 mnt</div>
                </div>
                <div class="h-8 w-px bg-outline-variant hidden sm:block"></div>
                
                <div class="relative" id="profileDropdownWrap">
                    <button type="button" onclick="document.getElementById('profileDropdownMenu').classList.toggle('hidden')" class="flex items-center gap-3 rounded-full hover:bg-surface-container-high px-2 py-1 transition-colors">
                        <div class="text-right hidden md:block">
                            <p class="text-xs font-bold text-primary leading-tight">{{ auth()->user()->name }}</p>
                            <p class="text-[10px] uppercase tracking-wider text-secondary">{{ auth()->user()->roleName() }}</p>
                        </div>
                        <div class="w-10 h-10 rounded-full border-2 border-primary bg-primary-container flex items-center justify-center text-white font-bold text-sm shadow-sm">
                            {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
                        </div>
                        <span class="material-symbols-outlined text-secondary text-[20px]">expand_more</span>
                    </button>
                    
                    <div id="profileDropdownMenu" class="hidden absolute right-0 top-14 w-72 bg-white rounded-2xl shadow-2xl border border-outline-variant overflow-hidden z-50 animate-fade-in">
                        <div class="p-4 bg-surface-container-low border-b border-outline-variant">
                            <div class="font-bold text-primary text-sm truncate">{{ auth()->user()->name }}</div>
                            <div class="text-xs text-secondary truncate">{{ auth()->user()->email }}</div>
                        </div>
                        <div class="p-2">
                            @if(Route::has('profile.edit'))
                                <a href="{{ route('profile.edit') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-surface-container text-sm font-semibold text-primary transition-colors">
                                    <span class="material-symbols-outlined text-[20px]">settings_account_box</span>Setting Profil
                                </a>
                            @endif
                            <form action="{{ route('logout') }}" method="POST" class="mt-1">
                                @csrf
                                <button type="submit" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-error-container text-sm font-semibold text-error transition-colors">
                                    <span class="material-symbols-outlined text-[20px]">logout</span>Logout
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div class="pt-20 sm:pt-24 px-3 sm:px-5 lg:px-6 pb-8 sm:pb-12 flex-1 max-w-full overflow-x-hidden">
            @if(session('success'))
                <div class="mb-5 rounded-xl bg-green-50 border border-green-200 text-green-800 px-4 py-3 text-sm flex items-center gap-2"><span class="material-symbols-outlined text-green-600">check_circle</span>{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="mb-5 rounded-xl bg-error-container/40 border border-error/20 text-on-error-container px-4 py-3 text-sm flex items-center gap-2"><span class="material-symbols-outlined text-error">error</span>{{ session('error') }}</div>
            @endif
            @if($errors->any())
                <div class="mb-5 rounded-xl bg-error-container/40 border border-error/20 text-on-error-container px-4 py-3 text-sm flex items-center gap-2"><span class="material-symbols-outlined text-error">warning</span>{{ $errors->first() }}</div>
            @endif
            @yield('content')
        </div>
    </main>
@else
    @yield('content')
@endauth

@stack('scripts')

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const toggleBtn = document.getElementById('sidebarToggleBtn');
        const backdrop = document.getElementById('sidebarBackdrop');

        // Memuat status preferensi ukuran sidebar dari lokal memori browser pimpinan
        if (window.innerWidth >= 1024 && localStorage.getItem('sidebar-mini') === 'true') {
            document.body.classList.add('sidebar-mini');
        }

        if (toggleBtn) {
            toggleBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (window.innerWidth >= 1024) {
                    // Eksekusi Pengecilan Sidebar di Layar Desktop (Mini Mode)
                    document.body.classList.toggle('sidebar-mini');
                    localStorage.setItem('sidebar-mini', document.body.classList.contains('sidebar-mini'));
                } else {
                    // Eksekusi Pemunculan Drawer Sidebar di Layar HP & Tablet
                    document.body.classList.toggle('mobile-sidebar-open');
                    if (backdrop) backdrop.classList.toggle('hidden');
                }
            });
        }

        // Penutupan drawer otomatis jika pimpinan mengetuk area latar belakang redup
        if (backdrop) {
            backdrop.addEventListener('click', () => {
                document.body.classList.remove('mobile-sidebar-open');
                backdrop.classList.add('hidden');
            });
        }

        // Klik di luar dropdown profil otomatis menutup menu
        document.addEventListener('click', function(e){
            const wrap = document.getElementById('profileDropdownWrap');
            const menu = document.getElementById('profileDropdownMenu');
            if(wrap && menu && !wrap.contains(e.target)){ menu.classList.add('hidden'); }
        });
    });
</script>
</body>
</html>