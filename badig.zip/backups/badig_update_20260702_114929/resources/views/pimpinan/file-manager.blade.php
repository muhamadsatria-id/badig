@extends('layouts.app')

@section('title', 'File Manager Semua Unit')
@section('page_title', 'File Manager Semua Unit')

@section('content')
<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-primary">File Manager Semua Unit</h2>
        <p class="text-xs text-secondary mt-1">Repositori global seluruh lampiran Daftar Arsip. Akses untuk Pimpinan dan Super Admin.</p>
    </div>
    <a href="{{ route('pimpinan.file-manager.export', array_merge(request()->query(), ['type' => 'pdf'])) }}" target="_blank" class="bg-error hover:bg-red-800 text-white px-5 py-3.5 rounded-xl text-xs font-bold inline-flex items-center gap-2 shadow-md"><span class="material-symbols-outlined text-[18px]">picture_as_pdf</span>Export PDF</a>
</div>

<form method="GET" action="{{ route('pimpinan.file-manager') }}" class="bg-white rounded-2xl border border-outline-variant shadow-sm p-5 mb-6 grid grid-cols-1 md:grid-cols-6 gap-4 items-end">
    <div class="md:col-span-2"><label class="text-xs font-bold text-on-surface-variant">Cari File</label><input type="text" name="q" value="{{ $filters['q'] }}" placeholder="Nama file, ekstensi, ID arsip..." class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm"></div>
    <div><label class="text-xs font-bold text-on-surface-variant">Unit</label><select name="unit" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm"><option value="all">Semua Unit</option>@foreach($units as $key=>$label)<option value="{{ $key }}" @selected($filters['unit']===$key)>{{ $label }}</option>@endforeach</select></div>
    <div><label class="text-xs font-bold text-on-surface-variant">Tipe</label><input type="text" name="type" value="{{ $filters['type'] }}" placeholder="pdf, jpg..." class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm"></div>
    <div><label class="text-xs font-bold text-on-surface-variant">Dari</label><input type="date" name="date_from" value="{{ $filters['date_from'] }}" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm"></div>
    <div><label class="text-xs font-bold text-on-surface-variant">Sampai</label><div class="flex gap-2"><input type="date" name="date_to" value="{{ $filters['date_to'] }}" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm"><button type="submit" class="bg-primary text-on-primary px-4 rounded-xl text-xs font-bold">Filter</button></div></div>
</form>

<div class="bg-white rounded-2xl border border-outline-variant shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full text-sm divide-y divide-outline-variant">
            <thead class="bg-surface-container text-on-surface-variant"><tr><th class="p-4 text-left">File</th><th class="p-4 text-left">Unit</th><th class="p-4 text-left">ID Arsip</th><th class="p-4 text-left">Uploader</th><th class="p-4 text-left">Tanggal Upload</th><th class="p-4 text-right">Aksi</th></tr></thead>
            <tbody class="divide-y divide-outline-variant">
                @forelse($attachments as $attachment)
                    <tr>
                        <td class="p-4"><div class="font-bold text-primary">{{ $attachment->original_name }}</div><div class="text-xs text-secondary uppercase">{{ $attachment->extension }} • {{ $attachment->human_file_size }}</div></td>
                        <td class="p-4 text-xs font-bold">{{ $units[$attachment->unit] ?? strtoupper($attachment->unit) }}</td>
                        <td class="p-4 font-mono text-xs">#{{ $attachment->record_id }}</td>
                        <td class="p-4 text-xs">{{ $attachment->uploader?->name ?? '-' }}</td>
                        <td class="p-4 text-xs">{{ $attachment->created_at?->format('d/m/Y H:i') }}</td>
                        <td class="p-4 text-right"><a href="{{ route('units.attachments.download', [$attachment->unit, $attachment->id]) }}" class="bg-primary text-on-primary px-3 py-2 rounded-lg text-xs font-bold">Download</a></td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="p-10 text-center text-outline">Belum ada file lampiran.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="p-4 border-t border-outline-variant">{{ $attachments->links() }}</div>
</div>
@endsection
