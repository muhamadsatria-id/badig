<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>BADIG Export Terpilih</title><style>
body{font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#1e293b}.page{page-break-after:always;padding:10mm}.last{page-break-after:auto}h1{font-size:16px;color:#001143;margin:0 0 3px}h2{font-size:14px;margin:10px 0 6px}.muted{color:#64748b}.table{width:100%;border-collapse:collapse;margin-top:8px}.table td,.table th{border:1px solid #cbd5e1;padding:6px;vertical-align:top}.label{width:30%;background:#f8fafc;font-weight:bold}.kop{border-bottom:3px solid #001143;padding-bottom:8px;margin-bottom:12px}
</style></head><body>
@foreach($items as $item)
<div class="page {{ $loop->last ? 'last' : '' }}">
    <div class="kop"><h1>BADIG</h1><div class="muted">Basis Data Terintegrasi Sat Intelkam — Export PDF Arsip Terpilih — {{ $module['title'] }}</div></div>
    <h2>#{{ $item->id }} — {{ $item->{$module['main']} }}</h2>
    <table class="table">
        @foreach($module['fields'] as $field)
            @php $value = match($field){'district_id'=>$item->district?->name ?? '-', 'village_id'=>$item->village?->name ?? '-', 'tanggal_pembuatan'=>optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-', default=>$item->{$field} ?? '-'}; @endphp
            <tr><td class="label">{{ ucwords(str_replace('_',' ', $field)) }}</td><td>{!! nl2br(e($value)) !!}</td></tr>
        @endforeach
        <tr><td class="label">Operator</td><td>{{ $item->operator?->name ?? '-' }}</td></tr>
    </table>
    <h2>Lampiran</h2>
    <table class="table"><thead><tr><th>No</th><th>Nama File</th><th>Tipe</th><th>Ukuran</th></tr></thead><tbody>
        @forelse(($attachments[$item->id] ?? collect()) as $file)
            <tr><td>{{ $loop->iteration }}</td><td>{{ $file->original_name }}</td><td>{{ strtoupper($file->extension) }}</td><td>{{ $file->human_file_size }}</td></tr>
        @empty
            <tr><td colspan="4">Tidak ada lampiran.</td></tr>
        @endforelse
    </tbody></table>
</div>
@endforeach
</body></html>
