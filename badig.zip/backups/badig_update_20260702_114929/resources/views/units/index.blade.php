@extends('layouts.app')

@section('title', 'Daftar Arsip '.$module['title'])
@section('page_title', 'Daftar Arsip '.$module['title'])

@section('content')
<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
    <div>
        <h2 class="text-2xl font-extrabold tracking-tight text-primary">Daftar Arsip: {{ $module['title'] }}</h2>
        <p class="text-xs text-secondary mt-1">Kelola data arsip unit, lampiran multi-file, export PDF terpilih, dan report PDF.</p>
    </div>
    <div class="flex flex-wrap gap-2">
        <a href="{{ route('units.file-manager', $unit) }}" class="bg-surface-container hover:bg-surface-container-high text-primary border border-outline-variant px-4 py-3 rounded-xl text-xs font-bold inline-flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[18px]">folder_managed</span> File Manager
        </a>
        <a href="{{ route('units.report-pdf', array_merge([$unit], request()->query())) }}" target="_blank" class="bg-error hover:bg-red-800 text-white px-4 py-3 rounded-xl text-xs font-bold inline-flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[18px]">picture_as_pdf</span> Report PDF
        </a>
        @if(auth()->user()->role_id !== 1)
            <a href="{{ route('units.create', $unit) }}" class="bg-primary-container hover:bg-[#0f1b40] text-on-primary font-bold text-xs px-5 py-3 rounded-xl shadow-md inline-flex items-center gap-2">
                <span class="material-symbols-outlined text-[18px]">add_circle</span> Tambah Data Arsip
            </a>
        @endif
    </div>
</div>

@if(session('success'))
    <div class="mb-5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 text-sm font-semibold">{{ session('success') }}</div>
@endif
@if($errors->any())
    <div class="mb-5 rounded-xl bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-sm font-semibold">{{ $errors->first() }}</div>
@endif

<form method="GET" action="{{ route('units.index', $unit) }}" class="bg-white rounded-2xl border border-outline-variant shadow-sm p-5 mb-6 grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
    <div class="md:col-span-2">
        <label class="block text-xs font-bold text-on-surface-variant mb-1">Cari Arsip</label>
        <input type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Cari ID, kategori, nama arsip..." class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm">
    </div>
    <div>
        <label class="block text-xs font-bold text-on-surface-variant mb-1">Status</label>
        <select name="status" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm">
            @foreach(['all'=>'Semua','draft'=>'Draft','submitted'=>'Submitted','approved'=>'Approved','rejected'=>'Rejected'] as $k=>$v)
                <option value="{{ $k }}" @selected(($filters['status'] ?? 'all') === $k)>{{ $v }}</option>
            @endforeach
        </select>
    </div>
    <div>
        <label class="block text-xs font-bold text-on-surface-variant mb-1">Dari Tanggal</label>
        <input type="date" name="date_from" value="{{ $filters['date_from'] ?? '' }}" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm">
    </div>
    <div>
        <label class="block text-xs font-bold text-on-surface-variant mb-1">Sampai</label>
        <div class="flex gap-2">
            <input type="date" name="date_to" value="{{ $filters['date_to'] ?? '' }}" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest text-sm">
            <button class="bg-primary text-on-primary rounded-xl px-4 text-xs font-bold" type="submit">Filter</button>
        </div>
    </div>
</form>

<form id="bulkExportForm" method="POST" action="{{ route('units.export-selected-pdf', $unit) }}" target="_blank">
    @csrf
</form>

<div class="bg-white rounded-2xl border border-outline-variant shadow-sm p-4 sm:p-5 md:p-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
            <h3 class="font-bold text-primary text-base">Basis Data Arsip Terintegrasi</h3>
            <p class="text-xs text-on-surface-variant">Centang beberapa arsip lalu export menjadi satu file PDF.</p>
        </div>
        <button form="bulkExportForm" type="submit" class="bg-error hover:bg-red-800 text-white px-5 py-3 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5">
            <span class="material-symbols-outlined text-[18px]">picture_as_pdf</span> Export PDF Terpilih
        </button>
    </div>

    <div class="overflow-x-auto rounded-xl border border-outline-variant shadow-inner">
        <table class="min-w-full text-sm divide-y divide-outline-variant">
            <thead class="bg-surface-container text-on-surface-variant font-semibold">
                <tr>
                    <th class="p-4 text-center w-12"><input type="checkbox" id="selectAllRows"></th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">ID</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Tanggal</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Kategori</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Nama / Entitas Arsip</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Wilayah</th>
                    <th class="p-4 text-center text-xs uppercase tracking-wider">Lampiran</th>
                    <th class="p-4 text-center text-xs uppercase tracking-wider">Status</th>
                    <th class="p-4 text-right text-xs uppercase tracking-wider">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-outline-variant bg-white text-on-surface">
                @forelse($items as $item)
                    <tr class="hover:bg-surface-container-low/60">
                        <td class="p-4 text-center"><input class="rowCheckbox" type="checkbox" name="ids[]" value="{{ $item->id }}" form="bulkExportForm"></td>
                        <td class="p-4 font-mono text-xs font-bold text-outline">#{{ $item->id }}</td>
                        <td class="p-4 text-xs font-semibold text-secondary">{{ optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-' }}</td>
                        <td class="p-4"><span class="bg-primary-container/10 text-primary px-2.5 py-0.5 rounded-md text-xs font-semibold">{{ $item->kategori }}</span></td>
                        <td class="p-4 font-bold text-primary">{{ $item->{$module['main']} }}</td>
                        <td class="p-4 text-xs text-on-surface-variant">{{ $item->village?->name ?? '-' }}, {{ $item->district?->name ?? '-' }}</td>
                        <td class="p-4 text-center">
                            <span class="inline-flex items-center gap-1 bg-surface-container px-2.5 py-1 rounded-lg text-xs font-bold text-primary">
                                <span class="material-symbols-outlined text-[15px]">attach_file</span>{{ $attachmentCounts[$item->id] ?? 0 }} file
                            </span>
                        </td>
                        <td class="p-4 text-center"><span class="text-[11px] uppercase font-bold px-2.5 py-1 rounded-md bg-amber-50 text-amber-700">{{ $item->status_laporan }}</span></td>
                        <td class="p-4 text-right whitespace-nowrap text-xs font-bold">
                            <a href="{{ route('units.show', [$unit, $item->id]) }}" class="text-primary hover:bg-surface-container px-2.5 py-1.5 rounded-lg inline-flex items-center gap-0.5"><span class="material-symbols-outlined text-[16px]">visibility</span>Detail</a>
                            <a href="{{ route('units.pdf', [$unit, $item->id]) }}" target="_blank" class="text-error hover:bg-error-container/20 px-2.5 py-1.5 rounded-lg inline-flex items-center gap-0.5"><span class="material-symbols-outlined text-[16px]">picture_as_pdf</span>PDF</a>
                            @if(auth()->user()->role_id !== 1)
                                <a href="{{ route('units.edit', [$unit, $item->id]) }}" class="text-amber-700 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg inline-flex items-center gap-0.5"><span class="material-symbols-outlined text-[16px]">edit</span>Edit</a>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="p-10 text-center text-outline">Belum ada data arsip.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6 flex justify-end">{{ $items->links() }}</div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', () => {
    const all = document.getElementById('selectAllRows');
    const rows = document.querySelectorAll('.rowCheckbox');
    all?.addEventListener('change', () => rows.forEach(cb => cb.checked = all.checked));
});
</script>
@endpush
