@extends('layouts.app')

@section('title', 'Detail '.$module['title'])
@section('page_title', 'Detail '.$module['title'])

@section('content')
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
    <div>
        <h2 class="text-2xl font-extrabold tracking-tight text-primary">Detail Data Daftar Arsip</h2>
        <p class="text-xs text-secondary mt-1">Detail data arsip dan lampiran file multi-format.</p>
    </div>
    <div class="flex gap-2.5 w-full sm:w-auto">
        <a href="{{ route('units.pdf', [$unit, $item->id]) }}" target="_blank" class="flex-1 sm:flex-none bg-error hover:bg-red-800 text-white px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5">
            <span class="material-symbols-outlined text-[16px]">picture_as_pdf</span> Buka PDF
        </a>
    </div>
</div>

@if(session('success'))
    <div class="mb-5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 text-sm font-semibold">{{ session('success') }}</div>
@endif

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
    <div class="lg:col-span-2 bg-white rounded-2xl border border-outline-variant shadow-sm p-4 sm:p-5 md:p-6">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 pb-5 border-b border-outline-variant/40">
            <div>
                <h3 class="text-xl md:text-2xl font-extrabold tracking-tight text-primary">{{ $item->{$module['main']} }}</h3>
                <div class="text-xs text-on-surface-variant font-semibold flex items-center flex-wrap gap-x-2 gap-y-1 mt-2">
                    <span class="bg-primary-container/10 text-primary px-2 py-0.5 rounded border border-primary-container/10">{{ $item->kategori }}</span>
                    <span>•</span>
                    <span>{{ optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-' }}</span>
                </div>
            </div>
            <span class="bg-amber-50 text-amber-700 border border-amber-200 px-3 py-1.5 rounded-lg font-bold text-xs uppercase tracking-wide">{{ $item->status_laporan }}</span>
        </div>

        <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            @foreach($module['fields'] as $field)
                @php $isFullWidth = str_contains($field, 'catatan') || str_contains($field, 'modus') || str_contains($field, 'data') || str_contains($field, 'alamat'); @endphp
                <div class="bg-surface-container-low/50 border border-outline-variant/40 rounded-xl p-4 {{ $isFullWidth ? 'sm:col-span-2' : '' }}">
                    <dt class="text-[11px] font-bold text-secondary uppercase tracking-wider mb-1.5">{{ ucwords(str_replace('_',' ', $field)) }}</dt>
                    <dd class="font-semibold text-primary text-sm whitespace-pre-line leading-relaxed">
                        @if($field === 'district_id')
                            {{ $item->district?->name ?? '-' }}
                        @elseif($field === 'village_id')
                            {{ $item->village?->name ?? '-' }}
                        @elseif($field === 'tanggal_pembuatan')
                            {{ optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-' }}
                        @else
                            {{ $item->{$field} ?? '-' }}
                        @endif
                    </dd>
                </div>
            @endforeach
            <div class="bg-surface-container-low/50 border border-outline-variant/40 rounded-xl p-4">
                <dt class="text-[11px] font-bold text-secondary uppercase tracking-wider mb-1.5">Operator Registrasi</dt>
                <dd class="font-bold text-primary text-sm">{{ $item->operator?->name ?? '-' }}</dd>
            </div>
            <div class="bg-surface-container-low/50 border border-outline-variant/40 rounded-xl p-4">
                <dt class="text-[11px] font-bold text-secondary uppercase tracking-wider mb-1.5">Catatan Koreksi Validasi</dt>
                <dd class="font-bold text-error text-sm">{{ $item->catatan_validasi ?? '-' }}</dd>
            </div>
        </dl>

        <div class="mt-6 pt-5 border-t border-outline-variant/40 flex flex-wrap items-center gap-3">
            <a href="{{ route('units.index', $unit) }}" class="w-full sm:w-auto bg-surface-container hover:bg-surface-container-high text-primary border border-outline-variant/60 px-5 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5">
                <span class="material-symbols-outlined text-[18px]">arrow_back</span>Kembali Ke Daftar
            </a>
            @if(auth()->user()->role_id !== 1)
                <a href="{{ route('units.edit', [$unit, $item->id]) }}" class="w-full sm:w-auto bg-primary-container hover:bg-[#0f1b40] text-on-primary font-bold text-xs px-5 py-3 rounded-xl shadow-xs flex items-center justify-center gap-1.5">
                    <span class="material-symbols-outlined text-[18px]">edit</span>Ubah Data Berkas
                </a>
            @endif
        </div>
    </div>

    <div class="space-y-6 lg:sticky lg:top-24">
        <div class="bg-white rounded-2xl border border-outline-variant shadow-sm p-4">
            <h3 class="font-bold text-primary text-sm mb-3 flex items-center gap-2"><span class="material-symbols-outlined text-[18px]">attach_file</span>Lampiran Arsip</h3>
            @forelse($attachments as $attachment)
                <div class="border border-outline-variant rounded-xl p-3 mb-3">
                    @if($attachment->is_image && Storage::disk('public')->exists($attachment->file_path))
                        <img src="{{ asset('storage/'.$attachment->file_path) }}" alt="{{ $attachment->original_name }}" class="w-full h-32 object-cover rounded-lg mb-2 border border-outline-variant">
                    @endif
                    <div class="font-bold text-sm text-primary break-words">{{ $attachment->original_name }}</div>
                    <div class="text-[11px] text-secondary uppercase mb-2">{{ $attachment->extension }} • {{ $attachment->human_file_size }}</div>
                    <div class="flex gap-2">
                        <a href="{{ route('units.attachments.download', [$unit, $attachment->id]) }}" class="flex-1 bg-surface-container text-primary px-3 py-2 rounded-lg text-xs font-bold text-center">Download</a>
                        @if(auth()->user()->role_id !== 1)
                            <form method="POST" action="{{ route('units.attachments.delete', [$unit, $attachment->id]) }}" onsubmit="return confirm('Hapus lampiran ini?')">
                                @csrf @method('DELETE')
                                <button class="bg-red-50 text-error px-3 py-2 rounded-lg text-xs font-bold" type="submit">Hapus</button>
                            </form>
                        @endif
                    </div>
                </div>
            @empty
                <div class="text-sm text-outline text-center py-8 border border-dashed border-outline-variant rounded-xl">Belum ada lampiran arsip.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection
