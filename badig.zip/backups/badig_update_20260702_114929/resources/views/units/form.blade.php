@extends('layouts.app')

@php
    $item = $item ?? null;
    $isEdit = !is_null($item);
    $attachments = $attachments ?? collect();
@endphp

@section('title', $isEdit ? 'Edit '.$module['title'] : 'Tambah '.$module['title'])
@section('page_title', $isEdit ? 'Edit '.$module['title'] : 'Tambah '.$module['title'])

@section('content')
@php
    $action = $isEdit ? route('units.update', [$unit, $item->id]) : route('units.store', $unit);
    $categories = [
        'unit1' => ['Aliran','Parpol','Kades','Camat'],
        'unit2' => ['Pengusaha','SPBU','LPG','Pasar'],
        'unit3' => ['Ormas','Ormawa','LSM','Tokoh'],
        'unit4' => ['Terorisme','Narkotika','Curanmor','Premanisme'],
    ][$unit] ?? [];
@endphp

<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-primary">{{ $isEdit ? 'Perbarui Daftar Arsip' : 'Tambah Data Daftar Arsip' }}</h2>
        <p class="text-xs text-secondary mt-1">Isi data arsip, tanggal pembuatan, koordinat bila dibutuhkan, dan upload beberapa lampiran sekaligus.</p>
    </div>
    <div class="bg-surface-container text-on-surface-variant font-bold text-xs px-4 py-1.5 rounded-full uppercase tracking-wider border border-outline-variant/40 flex items-center gap-1.5 shadow-sm">
        <span class="material-symbols-outlined text-[16px] text-primary">inventory_2</span> {{ strtoupper($unit) }} Daftar Arsip
    </div>
</div>

@if($errors->any())
    <div class="mb-5 rounded-xl bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-sm font-semibold">{{ $errors->first() }}</div>
@endif

<div class="bg-white rounded-2xl border border-outline-variant shadow-sm p-5 md:p-6 max-w-6xl mx-auto">
    <form method="POST" action="{{ $action }}" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-5">
        @csrf
        @if($isEdit) @method('PUT') @endif

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Tanggal Pembuatan <span class="text-error">*</span></label>
            <input type="date" name="tanggal_pembuatan" value="{{ old('tanggal_pembuatan', optional(data_get($item, 'tanggal_pembuatan', now()))->format('Y-m-d') ?? now()->toDateString()) }}" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-semibold" required>
        </div>

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Kategori Entitas <span class="text-error">*</span></label>
            <select name="kategori" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-semibold" required>
                @foreach($categories as $cat)
                    <option value="{{ $cat }}" @selected(old('kategori', data_get($item, 'kategori', '')) === $cat)>{{ $cat }}</option>
                @endforeach
            </select>
        </div>

        @if($unit === 'unit1')
            <x-form-input name="nama_subjek" label="Nama Subjek Organisasi / Kelompok" :value="old('nama_subjek', data_get($item, 'nama_subjek', ''))" required="true" icon="person" />
            <x-form-input name="pengikut" label="Estimasi Jumlah Pengikut" type="number" :value="old('pengikut', data_get($item, 'pengikut', ''))" icon="groups" />
            <x-form-input name="status_legal" label="Status Legalitas Kemenkumham / Instansi" :value="old('status_legal', data_get($item, 'status_legal', ''))" icon="gavel" />
            <x-form-textarea name="catatan_rawan" label="Catatan Indeks Kerawanan Kamtibmas" :value="old('catatan_rawan', data_get($item, 'catatan_rawan', ''))" />
        @elseif($unit === 'unit2')
            <x-form-input name="nama_aset" label="Nama Objek Vital / Objek Ekonomi" :value="old('nama_aset', data_get($item, 'nama_aset', ''))" required="true" icon="factory" />
            <x-form-input name="alamat" label="Alamat Operasional Lengkap" :value="old('alamat', data_get($item, 'alamat', ''))" required="true" icon="location_on" />
            <x-form-input name="kapasitas" label="Kapasitas / Volume Komoditas Logistik" :value="old('kapasitas', data_get($item, 'kapasitas', ''))" icon="database" />
        @elseif($unit === 'unit3')
            <x-form-input name="nama_organisasi" label="Nama Resmi Ormas / LSM / Lembaga" :value="old('nama_organisasi', data_get($item, 'nama_organisasi', ''))" required="true" icon="corporate_fare" />
            <x-form-input name="pimpinan" label="Nama Penanggung Jawab / Pimpinan Utama" :value="old('pimpinan', data_get($item, 'pimpinan', ''))" icon="person_celebration" />
            <x-form-input name="total_anggota" label="Total Anggota Terdaftar" type="number" :value="old('total_anggota', data_get($item, 'total_anggota', ''))" icon="groups" />
            <x-form-input name="legalitas" label="Nomor SK Akta / Surat Izin Operasional" :value="old('legalitas', data_get($item, 'legalitas', ''))" icon="description" />
            <x-form-textarea name="catatan_aktivitas" label="Catatan Monitoring Rekam Jejak Aktivitas" :value="old('catatan_aktivitas', data_get($item, 'catatan_aktivitas', ''))" />
        @elseif($unit === 'unit4')
            <x-form-input name="nama_kasus" label="Nama Lengkap Tersangka / Judul Kasus" :value="old('nama_kasus', data_get($item, 'nama_kasus', ''))" required="true" icon="gpp_bad" />
            <x-form-textarea name="modus" label="Modus Operandi Tindakan Kriminalitas" :value="old('modus', data_get($item, 'modus', ''))" />
            <x-form-input name="status_kasus" label="Status Penanganan Kasus (Lidik / Sidik / P21)" :value="old('status_kasus', data_get($item, 'status_kasus', ''))" required="true" icon="quick_reference_all" />
            <x-form-textarea name="data_enkripsi" label="Data Sensitif Tambahan (Terenkripsi Internal)" :value="old('data_enkripsi', data_get($item, 'data_enkripsi', ''))" />
        @endif

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Kecamatan <span class="text-error">*</span></label>
            <select name="district_id" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-medium" required>
                @foreach($districts as $district)
                    <option value="{{ $district->id }}" @selected(old('district_id', data_get($item, 'district_id', '')) == $district->id)>{{ $district->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Kelurahan / Desa <span class="text-error">*</span></label>
            <select name="village_id" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-medium" required>
                @foreach($villages as $village)
                    <option value="{{ $village->id }}" @selected(old('village_id', data_get($item, 'village_id', '')) == $village->id)>{{ $village->name }}</option>
                @endforeach
            </select>
        </div>

        <x-form-input name="koordinat_lat" label="Koordinat Garis Lintang (Latitude)" :value="old('koordinat_lat', data_get($item, 'koordinat_lat', ''))" icon="explore" placeholder="Contoh: -6.92712" />
        <x-form-input name="koordinat_lng" label="Koordinat Garis Bujur (Longitude)" :value="old('koordinat_lng', data_get($item, 'koordinat_lng', ''))" icon="explore" placeholder="Contoh: 106.93041" />

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Status Alur Laporan <span class="text-error">*</span></label>
            <select name="status_laporan" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-semibold" required>
                @foreach(['draft'=>'Draft (Arsip Internal)','submitted'=>'Diajukan (Validasi Kasat)','approved'=>'Disetujui (Rilis Pimpinan)','rejected'=>'Ditolak (Butuh Revisi)'] as $k=>$v)
                    <option value="{{ $k }}" @selected(old('status_laporan', data_get($item, 'status_laporan', 'draft')) === $k)>{{ $v }}</option>
                @endforeach
            </select>
        </div>

        <div class="md:col-span-2 bg-surface-container-low rounded-2xl border border-outline-variant p-4">
            <label class="block text-sm font-extrabold text-primary mb-1">Tambah File Lampiran Arsip</label>
            <p class="text-xs text-secondary mb-3">Bisa pilih banyak file sekaligus: 5 gambar, 4 PDF, Word, Excel, CSV, ZIP/RAR, dan format pendukung lain. Maksimal 50 MB per file.</p>
            <input type="file" name="attachments[]" multiple class="block w-full text-sm rounded-xl border border-dashed border-outline-variant bg-white p-4" accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,.rar,.ppt,.pptx">
        </div>

        @if($isEdit && $attachments->count())
            <div class="md:col-span-2 bg-white rounded-2xl border border-outline-variant p-4">
                <h3 class="font-bold text-primary text-sm mb-3">Lampiran Saat Ini</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    @foreach($attachments as $attachment)
                        <div class="border border-outline-variant rounded-xl p-3 flex items-center justify-between gap-3">
                            <div class="min-w-0">
                                <div class="font-bold text-sm text-primary truncate">{{ $attachment->original_name }}</div>
                                <div class="text-[11px] text-secondary uppercase">{{ $attachment->extension }} • {{ $attachment->human_file_size }}</div>
                            </div>
                            <a href="{{ route('units.attachments.download', [$unit, $attachment->id]) }}" class="text-xs font-bold text-primary bg-surface-container px-3 py-2 rounded-lg">Download</a>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif

        <div class="md:col-span-2 flex flex-wrap items-center gap-3 pt-4 border-t border-outline-variant/30 mt-2">
            <button type="submit" class="bg-primary-container hover:bg-primary text-on-primary font-bold text-xs px-6 py-3.5 rounded-xl transition-all shadow-md flex items-center gap-2"><span class="material-symbols-outlined text-[18px]">save</span>Simpan Daftar Arsip</button>
            <a href="{{ route('units.index', $unit) }}" class="bg-surface-container hover:bg-surface-container-high text-primary border border-outline-variant/60 px-6 py-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1"><span class="material-symbols-outlined text-[18px]">arrow_back</span>Batal / Kembali</a>
        </div>
    </form>
</div>
@endsection
