<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>BADIG - Dokumen {{ $module['title'] }} #{{ $item->id }}</title>
    <style>
        body { font-family: Arial, Helvetica, sans-serif; color: #1e293b; margin: 0; font-size: 12px; line-height: 1.4; }
        .page { padding: 10mm; background: #fff; }
        .kop-table { width: 100%; border-collapse: collapse; border-bottom: 3px solid #001143; margin-bottom: 20px; }
        .kop-table td { border: none; padding: 0 0 15px 0; }
        .logo-box { width: 54px; height: 54px; background: #001143; color: #fff; text-align:center; font-size: 21px; font-weight:bold; line-height:54px; border-radius: 8px; }
        .kop-text h1 { font-size: 16px; margin: 0; color: #001143; font-weight: bold; letter-spacing: 0.5px; }
        .kop-text .sub-header { font-size: 10px; color: #64748b; margin-top: 3px; }
        .main-title { color: #001143; margin: 0; font-size: 18px; font-weight: bold; }
        .entity-sub { font-size: 11px; color: #475569; margin-bottom: 16px; }
        .data-table, .file-table { width:100%; border-collapse: collapse; margin-top: 10px; }
        .data-table td, .file-table td, .file-table th { border: 1px solid #cbd5e1; padding: 7px 10px; vertical-align: top; }
        .label-col { width: 30%; background:#f8fafc; font-weight:bold; color:#334155; font-size: 10.5px; text-transform: uppercase; }
        .section-title { margin-top: 18px; font-size: 13px; color:#001143; font-weight:bold; }
        .footer { border-top: 1px dashed #cbd5e1; margin-top: 30px; padding-top: 10px; font-size: 10px; color: #64748b; }
    </style>
</head>
<body>
<div class="page">
    <table class="kop-table">
        <tr>
            <td style="width: 64px;"><div class="logo-box">B</div></td>
            <td class="kop-text"><h1>BADIG</h1><div class="sub-header">BASIS DATA TERINTEGRASI SAT INTELKAM / {{ strtoupper($module['title']) }} / ID ARSIP {{ $item->id }}</div></td>
        </tr>
    </table>

    <div class="main-title">{{ $item->{$module['main']} }}</div>
    <div class="entity-sub">Kategori: <strong>{{ $item->kategori }}</strong> &bull; Wilayah: <strong>{{ $item->village?->name ?? '-' }}, {{ $item->district?->name ?? '-' }}</strong></div>

    <table class="data-table">
        @foreach($module['fields'] as $field)
            @php
                $value = match($field) {
                    'district_id' => $item->district?->name ?? '-',
                    'village_id' => $item->village?->name ?? '-',
                    'tanggal_pembuatan' => optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-',
                    'created_at' => optional($item->created_at)->format('d/m/Y H:i') ?? '-',
                    'updated_at' => optional($item->updated_at)->format('d/m/Y H:i') ?? '-',
                    default => $item->{$field} ?? '-'
                };
            @endphp
            <tr><td class="label-col">{{ ucwords(str_replace('_',' ', $field)) }}</td><td>{!! nl2br(e($value)) !!}</td></tr>
        @endforeach
        <tr><td class="label-col">Operator Input</td><td>{{ $item->operator?->name ?? '-' }}</td></tr>
        <tr><td class="label-col">Waktu Cetak</td><td>{{ now()->format('d/m/Y H:i') }} WIB</td></tr>
    </table>

    <div class="section-title">Lampiran Arsip</div>
    <table class="file-table">
        <thead><tr><th>No</th><th>Nama File</th><th>Tipe</th><th>Ukuran</th><th>Upload</th></tr></thead>
        <tbody>
        @forelse(($attachments ?? collect()) as $file)
            <tr><td>{{ $loop->iteration }}</td><td>{{ $file->original_name }}</td><td>{{ strtoupper($file->extension) }}</td><td>{{ $file->human_file_size }}</td><td>{{ $file->created_at?->format('d/m/Y H:i') }}</td></tr>
        @empty
            <tr><td colspan="5">Tidak ada lampiran.</td></tr>
        @endforelse
        </tbody>
    </table>

    <div class="footer">Dokumen ini dihasilkan otomatis oleh BADIG — Basis Data Terintegrasi Sat Intelkam. File lampiran asli tetap tersimpan di File Manager sistem.</div>
</div>
</body>
</html>
