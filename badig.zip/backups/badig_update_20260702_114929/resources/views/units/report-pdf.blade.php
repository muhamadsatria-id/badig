<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>BADIG Report PDF</title><style>
body{font-family:Arial,Helvetica,sans-serif;font-size:10.5px;color:#1e293b}.kop{border-bottom:3px solid #001143;margin-bottom:12px;padding-bottom:8px}h1{font-size:16px;color:#001143;margin:0}.muted{color:#64748b}.table{width:100%;border-collapse:collapse;margin-top:10px}.table th,.table td{border:1px solid #cbd5e1;padding:6px;text-align:left;vertical-align:top}.table th{background:#f8fafc;color:#334155}.summary{margin:8px 0 12px;font-weight:bold}
</style></head><body>
<div class="kop"><h1>BADIG</h1><div class="muted">Basis Data Terintegrasi Sat Intelkam — {{ $module['title'] ?? 'Report PDF' }}</div></div>
<div class="summary">Dicetak: {{ now()->format('d/m/Y H:i') }} WIB | Filter: {{ json_encode($filters ?? []) }}</div>
@if(isset($globalAttachments))
    <table class="table"><thead><tr><th>No</th><th>Unit</th><th>ID Arsip</th><th>Nama File</th><th>Tipe</th><th>Ukuran</th><th>Uploader</th><th>Tanggal Upload</th></tr></thead><tbody>
    @forelse($globalAttachments as $file)
        <tr><td>{{ $loop->iteration }}</td><td>{{ $units[$file->unit] ?? strtoupper($file->unit) }}</td><td>#{{ $file->record_id }}</td><td>{{ $file->original_name }}</td><td>{{ strtoupper($file->extension) }}</td><td>{{ $file->human_file_size }}</td><td>{{ $file->uploader?->name ?? '-' }}</td><td>{{ $file->created_at?->format('d/m/Y H:i') }}</td></tr>
    @empty
        <tr><td colspan="8">Tidak ada file.</td></tr>
    @endforelse
    </tbody></table>
@else
    <table class="table"><thead><tr><th>No</th><th>ID</th><th>Tanggal Pembuatan</th><th>Kategori</th><th>Nama / Entitas</th><th>Wilayah</th><th>Status</th><th>Jumlah Lampiran</th><th>Operator</th></tr></thead><tbody>
    @forelse($items as $item)
        <tr><td>{{ $loop->iteration }}</td><td>#{{ $item->id }}</td><td>{{ optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-' }}</td><td>{{ $item->kategori }}</td><td>{{ $item->{$module['main']} }}</td><td>{{ $item->village?->name ?? '-' }}, {{ $item->district?->name ?? '-' }}</td><td>{{ $item->status_laporan }}</td><td>{{ $attachmentCounts[$item->id] ?? 0 }}</td><td>{{ $item->operator?->name ?? '-' }}</td></tr>
    @empty
        <tr><td colspan="9">Tidak ada arsip.</td></tr>
    @endforelse
    </tbody></table>
@endif
</body></html>
