<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class DataAttachment extends Model
{
    protected $fillable = [
        'unit',
        'unit_id',
        'record_table',
        'record_id',
        'original_name',
        'stored_name',
        'file_path',
        'extension',
        'mime_type',
        'file_size',
        'uploaded_by',
    ];

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function getIsImageAttribute(): bool
    {
        return in_array(strtolower((string) $this->extension), ['jpg', 'jpeg', 'png', 'gif', 'webp'], true);
    }

    public function getHumanFileSizeAttribute(): string
    {
        $bytes = (int) $this->file_size;
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2).' MB';
        }
        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 2).' KB';
        }
        return $bytes.' B';
    }

    public function existsOnDisk(): bool
    {
        return Storage::disk('public')->exists($this->file_path);
    }
}
