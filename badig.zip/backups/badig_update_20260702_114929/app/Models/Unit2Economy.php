<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit2Economy extends Model
{
    protected $table = 'unit2_economy';

    protected $fillable = [
        'kategori', 'nama_aset', 'district_id', 'village_id', 'alamat', 'kapasitas',
        'koordinat_lat', 'koordinat_lng', 'status_laporan', 'catatan_validasi',
        'operator_id', 'tanggal_pembuatan',
    ];

    protected function casts(): array
    {
        return [
            'koordinat_lat' => 'decimal:8',
            'koordinat_lng' => 'decimal:8',
            'tanggal_pembuatan' => 'date',
        ];
    }

    public function district(){ return $this->belongsTo(District::class); }
    public function village(){ return $this->belongsTo(Village::class); }
    public function operator(){ return $this->belongsTo(User::class, 'operator_id'); }
}
