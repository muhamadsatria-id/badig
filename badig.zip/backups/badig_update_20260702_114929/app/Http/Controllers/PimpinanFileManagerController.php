<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\DataAttachment;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PimpinanFileManagerController extends Controller
{
    private array $units = [
        'unit1' => 'Unit 1 Ideologi',
        'unit2' => 'Unit 2 Ekonomi',
        'unit3' => 'Unit 3 Sosbud',
        'unit4' => 'Unit 4 Keamanan',
    ];

    public function index(Request $request)
    {
        abort_unless(in_array((int) auth()->user()->role_id, [1, 5], true), 403, 'Akses terbatas untuk pimpinan dan super admin.');
        [$query, $filters] = $this->filteredQuery($request);
        $attachments = $query->latest()->paginate(20)->withQueryString();
        $units = $this->units;
        return view('pimpinan.file-manager', compact('attachments', 'filters', 'units'));
    }

    public function export(Request $request, string $type)
    {
        abort_unless(in_array((int) auth()->user()->role_id, [1, 5], true), 403, 'Akses terbatas untuk pimpinan dan super admin.');
        abort_unless($type === 'pdf', 404);
        [$query, $filters] = $this->filteredQuery($request);
        $attachments = $query->latest()->limit(1000)->get();
        $units = $this->units;

        AuditLog::record('GLOBAL_FILE_MANAGER_EXPORT_PDF', 'Export PDF File Manager Semua Unit total '.$attachments->count().' file.');

        $pdf = Pdf::loadView('units.report-pdf', [
            'unit' => 'all',
            'module' => ['title' => 'File Manager Semua Unit'],
            'items' => collect(),
            'filters' => $filters,
            'attachmentCounts' => collect(),
            'globalAttachments' => $attachments,
            'units' => $units,
        ]);
        $pdf->setPaper('a4', 'landscape');
        return $pdf->stream(Str::slug('BADIG file manager semua unit '.now()->format('Ymd His')).'.pdf');
    }

    private function filteredQuery(Request $request): array
    {
        $filters = [
            'q' => trim((string) $request->query('q', '')),
            'unit' => (string) $request->query('unit', 'all'),
            'type' => trim((string) $request->query('type', '')),
            'date_from' => (string) $request->query('date_from', ''),
            'date_to' => (string) $request->query('date_to', ''),
        ];

        $query = DataAttachment::with('uploader');
        if ($filters['unit'] !== 'all' && isset($this->units[$filters['unit']])) {
            $query->where('unit', $filters['unit']);
        }
        if ($filters['q'] !== '') {
            $q = $filters['q'];
            $query->where(function ($sub) use ($q) {
                $sub->where('original_name', 'like', '%'.$q.'%')
                    ->orWhere('extension', 'like', '%'.$q.'%')
                    ->orWhere('record_id', is_numeric($q) ? (int) $q : 0);
            });
        }
        if ($filters['type'] !== '') {
            $query->where('extension', strtolower($filters['type']));
        }
        if ($filters['date_from'] !== '') {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }
        if ($filters['date_to'] !== '') {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }

        return [$query, $filters];
    }
}
