<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\DataAttachment;
use App\Models\Unit1Ideology;
use App\Models\Unit2Economy;
use App\Models\Unit3Sosbud;
use App\Models\Unit4Security;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Str;

class UnitDocumentController extends Controller
{
    private array $modules = [
        'unit1' => ['id' => 1, 'title' => 'Unit 1 Ideologi', 'model' => Unit1Ideology::class, 'table' => 'unit1_ideology', 'main' => 'nama_subjek', 'fields' => ['tanggal_pembuatan','kategori','nama_subjek','district_id','village_id','pengikut','status_legal','catatan_rawan','koordinat_lat','koordinat_lng','status_laporan','catatan_validasi','created_at','updated_at']],
        'unit2' => ['id' => 2, 'title' => 'Unit 2 Ekonomi', 'model' => Unit2Economy::class, 'table' => 'unit2_economy', 'main' => 'nama_aset', 'fields' => ['tanggal_pembuatan','kategori','nama_aset','district_id','village_id','alamat','kapasitas','koordinat_lat','koordinat_lng','status_laporan','catatan_validasi','created_at','updated_at']],
        'unit3' => ['id' => 3, 'title' => 'Unit 3 Sosbud', 'model' => Unit3Sosbud::class, 'table' => 'unit3_sosbud', 'main' => 'nama_organisasi', 'fields' => ['tanggal_pembuatan','kategori','nama_organisasi','pimpinan','district_id','village_id','total_anggota','legalitas','catatan_aktivitas','koordinat_lat','koordinat_lng','status_laporan','catatan_validasi','created_at','updated_at']],
        'unit4' => ['id' => 4, 'title' => 'Unit 4 Keamanan', 'model' => Unit4Security::class, 'table' => 'unit4_security_crim', 'main' => 'nama_kasus', 'fields' => ['tanggal_pembuatan','kategori','nama_kasus','district_id','village_id','modus','koordinat_lat','koordinat_lng','status_kasus','status_laporan','catatan_validasi','created_at','updated_at']],
    ];

    private function module(string $unit): array
    {
        abort_unless(isset($this->modules[$unit]), 404);
        return $this->modules[$unit];
    }

    private function authorizeUnit(string $unit): void
    {
        $user = auth()->user();
        $module = $this->module($unit);
        abort_if((int) $user->role_id === 4, 403, 'Admin IT tidak membuka dokumen operasional intelijen.');
        abort_if((int) $user->role_id === 2 && (int) $user->unit_id !== (int) $module['id'], 403, 'Operator hanya dapat membuka dokumen unit kerja masing-masing.');
    }

    private function findRecord(string $unit, int $id): array
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $item = $module['model']::with(['district','village','operator'])->findOrFail($id);
        $attachments = DataAttachment::where('unit', $unit)
            ->where('record_table', $module['table'])
            ->where('record_id', $id)
            ->latest()
            ->get();
        return [$module, $item, $attachments];
    }

    public function html(string $unit, int $id)
    {
        [$module, $item, $attachments] = $this->findRecord($unit, $id);
        AuditLog::record('PREVIEW_DOCUMENT', 'Membuka pratinjau dokumen '.$module['title'].' ID '.$id);
        return view('documents.unit', compact('unit', 'module', 'item', 'attachments'));
    }

    public function pdf(string $unit, int $id)
    {
        [$module, $item, $attachments] = $this->findRecord($unit, $id);
        AuditLog::record('DOWNLOAD_PDF', 'Mengunduh PDF dokumen '.$module['title'].' ID '.$id);
        $filename = Str::slug('BADIG '.$module['title'].' '.$item->{$module['main']}.' '.$item->id).'.pdf';
        $pdf = Pdf::loadView('units.pdf_cetak', compact('unit', 'module', 'item', 'attachments'));
        $pdf->setPaper('a4', 'portrait');
        return $pdf->stream($filename);
    }

    public function simplePdf(array $lines, string $title = 'BADIG'): string
    {
        $safeLines = [];
        foreach ($lines as $line) {
            $line = preg_replace('/\s+/', ' ', (string) $line);
            $safeLines[] = mb_substr($line, 0, 112);
        }

        $content = "BT\n/F1 10 Tf\n50 790 Td\n14 TL\n";
        foreach (array_slice($safeLines, 0, 52) as $line) {
            $content .= '('.$this->pdfEscape($line).") Tj\nT*\n";
        }
        $content .= "ET\n";

        $objects = [];
        $objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
        $objects[] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>';
        $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
        $objects[] = '<< /Length '.strlen($content).' >>' . "\nstream\n" . $content . "endstream";

        $pdf = "%PDF-1.4\n%BADIG\n";
        $offsets = [0];
        foreach ($objects as $i => $object) {
            $offsets[] = strlen($pdf);
            $pdf .= ($i + 1)." 0 obj\n".$object."\nendobj\n";
        }

        $xref = strlen($pdf);
        $pdf .= "xref\n0 ".(count($objects) + 1)."\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<< /Size ".(count($objects) + 1)." /Root 1 0 R /Title (".$this->pdfEscape($title).") >>\nstartxref\n".$xref."\n%%EOF";
        return $pdf;
    }

    private function pdfEscape(string $text): string
    {
        $text = iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $text) ?: $text;
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    }
}
