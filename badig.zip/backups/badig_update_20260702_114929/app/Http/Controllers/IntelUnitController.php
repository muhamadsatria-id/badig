<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\DataAttachment;
use App\Models\District;
use App\Models\Unit1Ideology;
use App\Models\Unit2Economy;
use App\Models\Unit3Sosbud;
use App\Models\Unit4Security;
use App\Models\Village;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class IntelUnitController extends Controller
{
    private array $modules = [
        'unit1' => [
            'id' => 1,
            'title' => 'Unit 1 Ideologi',
            'model' => Unit1Ideology::class,
            'table' => 'unit1_ideology',
            'main' => 'nama_subjek',
            'fields' => ['tanggal_pembuatan','kategori','nama_subjek','district_id','village_id','pengikut','status_legal','catatan_rawan','koordinat_lat','koordinat_lng','status_laporan'],
        ],
        'unit2' => [
            'id' => 2,
            'title' => 'Unit 2 Ekonomi',
            'model' => Unit2Economy::class,
            'table' => 'unit2_economy',
            'main' => 'nama_aset',
            'fields' => ['tanggal_pembuatan','kategori','nama_aset','district_id','village_id','alamat','kapasitas','koordinat_lat','koordinat_lng','status_laporan'],
        ],
        'unit3' => [
            'id' => 3,
            'title' => 'Unit 3 Sosbud',
            'model' => Unit3Sosbud::class,
            'table' => 'unit3_sosbud',
            'main' => 'nama_organisasi',
            'fields' => ['tanggal_pembuatan','kategori','nama_organisasi','pimpinan','district_id','village_id','total_anggota','legalitas','catatan_aktivitas','koordinat_lat','koordinat_lng','status_laporan'],
        ],
        'unit4' => [
            'id' => 4,
            'title' => 'Unit 4 Keamanan',
            'model' => Unit4Security::class,
            'table' => 'unit4_security_crim',
            'main' => 'nama_kasus',
            'fields' => ['tanggal_pembuatan','kategori','nama_kasus','district_id','village_id','modus','koordinat_lat','koordinat_lng','status_kasus','status_laporan'],
        ],
    ];

    private array $allowedAttachmentMimes = [
        'jpg', 'jpeg', 'png', 'gif', 'webp',
        'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt',
        'zip', 'rar', 'ppt', 'pptx',
    ];

    private function module(string $unit): array
    {
        abort_unless(isset($this->modules[$unit]), 404);
        return $this->modules[$unit];
    }

    private function authorizeUnit(string $unit, bool $write = false): void
    {
        $module = $this->module($unit);
        $user = auth()->user();

        abort_if((int) $user->role_id === 4, 403, 'Admin IT tidak membuka data operasional intelijen.');
        abort_if($write && (int) $user->role_id === 1, 403, 'Pimpinan hanya memiliki akses lihat data.');
        abort_if((int) $user->role_id === 2 && (int) $user->unit_id !== (int) $module['id'], 403, 'Operator hanya dapat mengakses unit kerja masing-masing.');
    }

    private function attachmentQueryFor(string $unit, array $module)
    {
        return DataAttachment::query()
            ->where('unit', $unit)
            ->where('record_table', $module['table']);
    }

    private function attachmentsFor(string $unit, array $module, int $recordId)
    {
        return $this->attachmentQueryFor($unit, $module)
            ->where('record_id', $recordId)
            ->with('uploader')
            ->latest()
            ->get();
    }

    private function formatFieldValue(string $field, object $item): string
    {
        return match ($field) {
            'district_id' => $item->district?->name ?? '-',
            'village_id' => $item->village?->name ?? '-',
            'tanggal_pembuatan' => optional($item->tanggal_pembuatan)->format('d/m/Y') ?? '-',
            'created_at' => optional($item->created_at)->format('d/m/Y H:i') ?? '-',
            'updated_at' => optional($item->updated_at)->format('d/m/Y H:i') ?? '-',
            default => (string) ($item->{$field} ?? '-'),
        };
    }

    public function index(Request $request, string $unit)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $model = $module['model'];

        $filters = [
            'q' => trim((string) $request->query('q', '')),
            'status' => (string) $request->query('status', 'all'),
            'date_from' => (string) $request->query('date_from', ''),
            'date_to' => (string) $request->query('date_to', ''),
        ];

        $query = $model::with(['district','village','operator']);

        if ($filters['status'] !== 'all') {
            $query->where('status_laporan', $filters['status']);
        }
        if ($filters['date_from'] !== '') {
            $query->whereDate('tanggal_pembuatan', '>=', $filters['date_from']);
        }
        if ($filters['date_to'] !== '') {
            $query->whereDate('tanggal_pembuatan', '<=', $filters['date_to']);
        }
        if ($filters['q'] !== '') {
            $needle = $filters['q'];
            $searchable = array_values(array_filter($module['fields'], fn ($field) => ! in_array($field, ['district_id','village_id','koordinat_lat','koordinat_lng'], true)));
            $query->where(function ($q) use ($searchable, $needle) {
                foreach ($searchable as $field) {
                    $q->orWhere($field, 'like', '%'.$needle.'%');
                }
                if (is_numeric($needle)) {
                    $q->orWhere('id', (int) $needle);
                }
            });
        }

        $items = $query->latest()->paginate(10)->withQueryString();
        $ids = $items->getCollection()->pluck('id')->all();
        $attachmentCounts = $this->attachmentQueryFor($unit, $module)
            ->whereIn('record_id', $ids)
            ->selectRaw('record_id, COUNT(*) as total')
            ->groupBy('record_id')
            ->pluck('total', 'record_id');

        return view('units.index', compact('unit', 'module', 'items', 'attachmentCounts', 'filters'));
    }

    public function create(string $unit)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $districts = District::with('villages')->orderBy('name')->get();
        $villages = Village::orderBy('name')->get();
        $attachments = collect();
        return view('units.form', compact('unit', 'module', 'districts', 'villages', 'attachments'));
    }

    public function store(Request $request, string $unit)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $this->validateAttachments($request);
        $data = $this->validated($request, $unit);
        $data['operator_id'] = auth()->id();

        $item = $module['model']::create($data);
        $uploaded = $this->storeAttachments($request, $unit, $module, $item->id);

        AuditLog::record('CREATE_'.$unit, 'Menambah arsip '.$module['title'].' ID '.$item->id.' dengan '.$uploaded.' lampiran.');
        return redirect()->route('units.show', [$unit, $item->id])->with('success', 'Data arsip berhasil disimpan. Lampiran tersimpan: '.$uploaded.' file.');
    }

    public function show(string $unit, int $id)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $item = $module['model']::with(['district','village','operator'])->findOrFail($id);
        $attachments = $this->attachmentsFor($unit, $module, $id);
        return view('units.show', compact('unit', 'module', 'item', 'attachments'));
    }

    public function edit(string $unit, int $id)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $item = $module['model']::findOrFail($id);
        $districts = District::with('villages')->orderBy('name')->get();
        $villages = Village::orderBy('name')->get();
        $attachments = $this->attachmentsFor($unit, $module, $id);
        return view('units.form', compact('unit', 'module', 'item', 'districts', 'villages', 'attachments'));
    }

    public function update(Request $request, string $unit, int $id)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $this->validateAttachments($request);
        $item = $module['model']::findOrFail($id);
        $item->update($this->validated($request, $unit));
        $uploaded = $this->storeAttachments($request, $unit, $module, $item->id);

        AuditLog::record('UPDATE_'.$unit, 'Mengubah arsip '.$module['title'].' ID '.$item->id.' dan menambah '.$uploaded.' lampiran.');
        return redirect()->route('units.show', [$unit, $item->id])->with('success', 'Data arsip berhasil diperbarui. Lampiran baru: '.$uploaded.' file.');
    }

    public function destroy(string $unit, int $id)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $item = $module['model']::findOrFail($id);
        $attachments = $this->attachmentsFor($unit, $module, $id);
        foreach ($attachments as $attachment) {
            Storage::disk('public')->delete($attachment->file_path);
            $attachment->delete();
        }
        $item->delete();
        AuditLog::record('DELETE_'.$unit, 'Menghapus arsip '.$module['title'].' ID '.$id.' beserta '.$attachments->count().' lampiran.');
        return redirect()->route('units.index', $unit)->with('success', 'Data arsip dan lampirannya berhasil dihapus.');
    }

    public function fileManager(Request $request, string $unit)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $filters = [
            'q' => trim((string) $request->query('q', '')),
            'type' => trim((string) $request->query('type', '')),
            'date_from' => (string) $request->query('date_from', ''),
            'date_to' => (string) $request->query('date_to', ''),
        ];

        $query = $this->attachmentQueryFor($unit, $module)->with('uploader');
        if ($filters['q'] !== '') {
            $q = $filters['q'];
            $query->where(function ($sub) use ($q) {
                $sub->where('original_name', 'like', '%'.$q.'%')
                    ->orWhere('extension', 'like', '%'.$q.'%')
                    ->orWhere('record_id', is_numeric($q) ? (int) $q : 0);
            });
        }
        if ($filters['type'] !== '') {
            $query->where('extension', strtolower($filters['type']));
        }
        if ($filters['date_from'] !== '') {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }
        if ($filters['date_to'] !== '') {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }

        $attachments = $query->latest()->paginate(15)->withQueryString();
        return view('units.file-manager', compact('unit', 'module', 'attachments', 'filters'));
    }

    public function downloadAttachment(string $unit, int $attachment)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $file = $this->attachmentQueryFor($unit, $module)->findOrFail($attachment);
        abort_unless(Storage::disk('public')->exists($file->file_path), 404, 'File tidak ditemukan di storage.');
        AuditLog::record('DOWNLOAD_ATTACHMENT', 'Download lampiran '.$file->original_name.' dari '.$module['title'].' record #'.$file->record_id);
        return Storage::disk('public')->download($file->file_path, $file->original_name);
    }

    public function deleteAttachment(string $unit, int $attachment)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $file = $this->attachmentQueryFor($unit, $module)->findOrFail($attachment);
        Storage::disk('public')->delete($file->file_path);
        $file->delete();
        AuditLog::record('DELETE_ATTACHMENT', 'Menghapus lampiran '.$file->original_name.' dari '.$module['title'].' record #'.$file->record_id);
        return back()->with('success', 'Lampiran berhasil dihapus.');
    }

    public function exportSelectedPdf(Request $request, string $unit)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer', 'min:1'],
        ]);

        $model = $module['model'];
        $items = $model::with(['district','village','operator'])
            ->whereIn('id', $data['ids'])
            ->orderBy('id')
            ->get();

        abort_if($items->isEmpty(), 404, 'Data arsip tidak ditemukan.');

        $attachments = $this->attachmentQueryFor($unit, $module)
            ->whereIn('record_id', $items->pluck('id')->all())
            ->latest()
            ->get()
            ->groupBy('record_id');

        AuditLog::record('EXPORT_SELECTED_PDF', 'Export '.$items->count().' arsip '.$module['title'].' menjadi satu PDF.');

        $pdf = Pdf::loadView('units.export-selected-pdf', compact('unit', 'module', 'items', 'attachments'));
        $pdf->setPaper('a4', 'portrait');
        return $pdf->stream(Str::slug('BADIG '.$module['title'].' export terpilih '.now()->format('Ymd His')).'.pdf');
    }

    public function reportPdf(Request $request, string $unit)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $filters = [
            'q' => trim((string) $request->query('q', '')),
            'status' => (string) $request->query('status', 'all'),
            'date_from' => (string) $request->query('date_from', ''),
            'date_to' => (string) $request->query('date_to', ''),
        ];

        $model = $module['model'];
        $query = $model::with(['district','village','operator']);
        if ($filters['status'] !== 'all') {
            $query->where('status_laporan', $filters['status']);
        }
        if ($filters['date_from'] !== '') {
            $query->whereDate('tanggal_pembuatan', '>=', $filters['date_from']);
        }
        if ($filters['date_to'] !== '') {
            $query->whereDate('tanggal_pembuatan', '<=', $filters['date_to']);
        }
        if ($filters['q'] !== '') {
            $needle = $filters['q'];
            $query->where(function ($q) use ($module, $needle) {
                $q->where('kategori', 'like', '%'.$needle.'%')
                  ->orWhere($module['main'], 'like', '%'.$needle.'%');
            });
        }

        $items = $query->latest()->limit(500)->get();
        $attachmentCounts = $this->attachmentQueryFor($unit, $module)
            ->whereIn('record_id', $items->pluck('id')->all())
            ->selectRaw('record_id, COUNT(*) as total')
            ->groupBy('record_id')
            ->pluck('total', 'record_id');

        AuditLog::record('REPORT_PDF', 'Mencetak report PDF '.$module['title'].' total '.$items->count().' arsip.');

        $pdf = Pdf::loadView('units.report-pdf', compact('unit', 'module', 'items', 'filters', 'attachmentCounts'));
        $pdf->setPaper('a4', 'landscape');
        return $pdf->stream(Str::slug('BADIG report '.$module['title'].' '.now()->format('Ymd His')).'.pdf');
    }

    public function reports()
    {
        abort_unless(in_array((int) auth()->user()->role_id, [3, 5], true), 403, 'Anda tidak memiliki otoritas untuk mengakses modul validasi ini.');
        $reports = collect();
        foreach ($this->modules as $unit => $module) {
            $module['model']::with(['operator','district','village'])
                ->whereIn('status_laporan', ['draft','submitted','rejected'])
                ->latest()->limit(10)->get()->each(function ($item) use (&$reports, $unit, $module) {
                    $reports->push(['unit' => $unit, 'module' => $module, 'item' => $item]);
                });
        }
        $reports = $reports->sortByDesc(fn($r) => $r['item']->updated_at)->values();
        return view('reports.index', compact('reports'));
    }

    public function validateReport(Request $request, string $unit, int $id)
    {
        abort_unless(in_array((int) auth()->user()->role_id, [3, 5], true), 403, 'Anda tidak memiliki otoritas untuk memproses validasi ini.');
        $module = $this->module($unit);
        $request->validate([
            'decision' => ['required', 'in:approved,rejected,submitted'],
            'catatan_validasi' => ['nullable', 'string', 'max:2000'],
        ]);
        $item = $module['model']::findOrFail($id);
        $item->update([
            'status_laporan' => $request->decision,
            'catatan_validasi' => $request->catatan_validasi,
        ]);
        AuditLog::record('VALIDATE_REPORT', strtoupper($request->decision).' '.$module['title'].' ID '.$id);
        return back()->with('success', 'Status laporan berhasil diperbarui.');
    }

    private function validateAttachments(Request $request): void
    {
        $request->validate([
            'attachments' => ['nullable', 'array'],
            'attachments.*' => ['file', 'max:51200', 'mimes:'.implode(',', $this->allowedAttachmentMimes)],
        ], [
            'attachments.*.max' => 'Ukuran setiap lampiran maksimal 50 MB.',
            'attachments.*.mimes' => 'Format lampiran harus berupa gambar, PDF, Word, Excel, CSV, TXT, ZIP, RAR, atau PowerPoint.',
        ]);
    }

    private function storeAttachments(Request $request, string $unit, array $module, int $recordId): int
    {
        if (! $request->hasFile('attachments')) {
            return 0;
        }

        $count = 0;
        foreach ((array) $request->file('attachments') as $file) {
            if (! $file || ! $file->isValid()) {
                continue;
            }

            $extension = strtolower($file->getClientOriginalExtension() ?: $file->extension());
            $storedName = now()->format('YmdHis').'_'.Str::random(12).'.'.$extension;
            $path = $file->storeAs('badig/arsip/'.$unit.'/'.$recordId, $storedName, 'public');

            DataAttachment::create([
                'unit' => $unit,
                'unit_id' => (int) $module['id'],
                'record_table' => $module['table'],
                'record_id' => $recordId,
                'original_name' => $file->getClientOriginalName(),
                'stored_name' => $storedName,
                'file_path' => $path,
                'extension' => $extension,
                'mime_type' => $file->getClientMimeType(),
                'file_size' => $file->getSize() ?: 0,
                'uploaded_by' => auth()->id(),
            ]);
            $count++;
        }

        return $count;
    }

    private function validated(Request $request, string $unit): array
    {
        $base = [
            'tanggal_pembuatan' => ['nullable', 'date'],
            'kategori' => ['required', 'string', 'max:100'],
            'district_id' => ['required', 'exists:districts,id'],
            'village_id' => ['required', 'exists:villages,id'],
            'koordinat_lat' => ['nullable', 'numeric', 'between:-90,90'],
            'koordinat_lng' => ['nullable', 'numeric', 'between:-180,180'],
            'status_laporan' => ['required', 'in:draft,submitted,approved,rejected'],
        ];

        $rules = match ($unit) {
            'unit1' => array_merge($base, [
                'nama_subjek' => ['required', 'string', 'max:255'],
                'pengikut' => ['nullable', 'integer', 'min:0'],
                'status_legal' => ['nullable', 'string', 'max:100'],
                'catatan_rawan' => ['nullable', 'string'],
            ]),
            'unit2' => array_merge($base, [
                'nama_aset' => ['required', 'string', 'max:255'],
                'alamat' => ['required', 'string', 'max:500'],
                'kapasitas' => ['nullable', 'string', 'max:255'],
            ]),
            'unit3' => array_merge($base, [
                'nama_organisasi' => ['required', 'string', 'max:255'],
                'pimpinan' => ['nullable', 'string', 'max:255'],
                'total_anggota' => ['nullable', 'integer', 'min:0'],
                'legalitas' => ['nullable', 'string', 'max:100'],
                'catatan_aktivitas' => ['nullable', 'string'],
            ]),
            'unit4' => array_merge($base, [
                'nama_kasus' => ['required', 'string', 'max:255'],
                'modus' => ['nullable', 'string'],
                'status_kasus' => ['required', 'string', 'max:100'],
                'data_enkripsi' => ['nullable', 'string'],
            ]),
        };

        $data = Validator::make($request->all(), $rules)->validate();
        $data['tanggal_pembuatan'] = $data['tanggal_pembuatan'] ?? now()->toDateString();
        return $data;
    }
}
