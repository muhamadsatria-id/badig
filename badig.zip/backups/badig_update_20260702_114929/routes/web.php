<?php

use App\Http\Controllers\AdminITController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BackupFileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IntelUnitController;
use App\Http\Controllers\PimpinanFileManagerController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\UnitDocumentController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => auth()->check() ? redirect()->route('dashboard') : redirect()->route('login'));

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'processLogin'])->name('login.process');
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth', 'session.fresh'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');

    Route::middleware('role:1,2,3,5')->group(function () {
        Route::get('/data/{unit}', [IntelUnitController::class, 'index'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.index');
        Route::get('/data/{unit}/create', [IntelUnitController::class, 'create'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.create');
        Route::post('/data/{unit}', [IntelUnitController::class, 'store'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.store');
        Route::post('/data/{unit}/export-selected-pdf', [IntelUnitController::class, 'exportSelectedPdf'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.export-selected-pdf');
        Route::get('/data/{unit}/report-pdf', [IntelUnitController::class, 'reportPdf'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.report-pdf');
        Route::get('/data/{unit}/file-manager', [IntelUnitController::class, 'fileManager'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.file-manager');
        Route::get('/data/{unit}/attachments/{attachment}/download', [IntelUnitController::class, 'downloadAttachment'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.attachments.download');
        Route::delete('/data/{unit}/attachments/{attachment}', [IntelUnitController::class, 'deleteAttachment'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.attachments.delete');
        Route::get('/data/{unit}/{id}/document', [UnitDocumentController::class, 'html'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.document');
        Route::get('/data/{unit}/{id}/pdf', [UnitDocumentController::class, 'pdf'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.pdf');
        Route::get('/data/{unit}/{id}', [IntelUnitController::class, 'show'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.show');
        Route::get('/data/{unit}/{id}/edit', [IntelUnitController::class, 'edit'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.edit');
        Route::put('/data/{unit}/{id}', [IntelUnitController::class, 'update'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.update');
        Route::delete('/data/{unit}/{id}', [IntelUnitController::class, 'destroy'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.destroy');
    });

    Route::middleware('role:3,5')->group(function () {
        Route::get('/validasi-laporan', [IntelUnitController::class, 'reports'])->name('reports.index');
        Route::post('/validasi-laporan/{unit}/{id}', [IntelUnitController::class, 'validateReport'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('reports.validate');
    });

    Route::middleware('role:1,5')->prefix('pimpinan')->name('pimpinan.')->group(function () {
        Route::get('/file-manager', [PimpinanFileManagerController::class, 'index'])->name('file-manager');
        Route::get('/file-manager/export/{type}', [PimpinanFileManagerController::class, 'export'])->whereIn('type', ['pdf'])->name('file-manager.export');
    });

    Route::middleware('role:4,5')->prefix('admin-it')->name('admin.')->group(function () {
        Route::get('/users', [AdminITController::class, 'users'])->name('users');
        Route::post('/users', [AdminITController::class, 'storeUser'])->name('users.store');
        Route::patch('/users/{user}/toggle', [AdminITController::class, 'toggleUser'])->name('users.toggle');
        Route::get('/audit-trail', [AdminITController::class, 'auditTrail'])->name('audit');
        Route::get('/backup', [AdminITController::class, 'backups'])->name('backup');
        Route::post('/backup', [AdminITController::class, 'triggerBackup'])->name('backup.trigger');
        Route::get('/backup-files', [BackupFileController::class, 'index'])->name('backup.files');
        Route::get('/backup-files/download/{filename}', [BackupFileController::class, 'download'])->where('filename', '[A-Za-z0-9._-]+')->name('backup.download');
        Route::delete('/backup-files/delete/{filename}', [BackupFileController::class, 'delete'])->where('filename', '[A-Za-z0-9._-]+')->name('backup.delete');
    });

    Route::middleware('role:5')->prefix('super-admin')->name('super-admin.')->group(function () {
        Route::get('/', [SuperAdminController::class, 'index'])->name('index');
    });
});
