<?php

use App\Http\Controllers\AdminITController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IntelUnitController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => auth()->check() ? redirect()->route('dashboard') : redirect()->route('login'));

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'processLogin'])->name('login.process');
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth', 'session.fresh'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::middleware('role:1,2,3')->group(function () {
        Route::get('/data/{unit}', [IntelUnitController::class, 'index'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.index');
        Route::get('/data/{unit}/create', [IntelUnitController::class, 'create'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.create');
        Route::post('/data/{unit}', [IntelUnitController::class, 'store'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.store');
        Route::get('/data/{unit}/{id}', [IntelUnitController::class, 'show'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.show');
        Route::get('/data/{unit}/{id}/edit', [IntelUnitController::class, 'edit'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.edit');
        Route::put('/data/{unit}/{id}', [IntelUnitController::class, 'update'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.update');
        Route::delete('/data/{unit}/{id}', [IntelUnitController::class, 'destroy'])->whereIn('unit', ['unit1','unit2','unit3','unit4'])->name('units.destroy');
    });

Route::middleware('role:3,5')
    ->group(function () {

        Route::get('/validasi-laporan', [\App\Http\Controllers\IntelUnitController::class, 'reports'])
            ->name('reports.index');

        Route::post('/validasi-laporan/{unit}/{id}', [\App\Http\Controllers\IntelUnitController::class, 'validateReport'])
            ->whereIn('unit', ['unit1','unit2','unit3','unit4'])
            ->name('reports.validate');
    });

    Route::middleware('role:4')->prefix('admin-it')->name('admin.')->group(function () {
        Route::get('/users', [AdminITController::class, 'users'])->name('users');
        Route::post('/users', [AdminITController::class, 'storeUser'])->name('users.store');
        Route::patch('/users/{user}/toggle', [AdminITController::class, 'toggleUser'])->name('users.toggle');
        Route::get('/audit-trail', [AdminITController::class, 'auditTrail'])->name('audit');
        Route::get('/backup', [AdminITController::class, 'backups'])->name('backup');
        Route::post('/backup', [AdminITController::class, 'triggerBackup'])->name('backup.trigger');
    });
});

/*
|--------------------------------------------------------------------------
| SIBDI-PSK Backup File Download Routes
|--------------------------------------------------------------------------
| Route ini ditambahkan otomatis oleh add_sibdi_backup_download.sh.
| Hanya Admin IT (role 4) yang dapat melihat, mengunduh, dan menghapus backup.
*/
Route::middleware(['auth', 'role:4'])->prefix('admin-it')->group(function () {
    Route::get('/backup-files', [\App\Http\Controllers\BackupFileController::class, 'index'])->name('admin.backup.files');
    Route::get('/backup-files/download/{filename}', [\App\Http\Controllers\BackupFileController::class, 'download'])
        ->where('filename', '[A-Za-z0-9._-]+')
        ->name('admin.backup.download');
    Route::delete('/backup-files/delete/{filename}', [\App\Http\Controllers\BackupFileController::class, 'delete'])
        ->where('filename', '[A-Za-z0-9._-]+')
        ->name('admin.backup.delete');
});
// BEGIN SIBDI FEATURE EXTENSION PROFILE MANAGER PDF MAPS
Route::middleware(['auth', 'session.fresh'])->group(function () {
    Route::get('/profile', [\App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [\App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');

Route::middleware('role:1,5')
    ->prefix('pimpinan')
    ->name('pimpinan.')
    ->group(function () {

        Route::get('/file-manager', [\App\Http\Controllers\PimpinanFileManagerController::class, 'index'])
            ->name('file-manager');

        Route::get('/file-manager/export/{type}', [\App\Http\Controllers\PimpinanFileManagerController::class, 'export'])
            ->whereIn('type', ['pdf', 'excel'])
            ->name('file-manager.export');
    });

    Route::middleware('role:1,2,3')->group(function () {
        Route::get('/data/{unit}/{id}/document', [\App\Http\Controllers\UnitDocumentController::class, 'html'])
            ->whereIn('unit', ['unit1','unit2','unit3','unit4'])
            ->name('units.document');
        Route::get('/data/{unit}/{id}/pdf', [\App\Http\Controllers\UnitDocumentController::class, 'pdf'])
            ->whereIn('unit', ['unit1','unit2','unit3','unit4'])
            ->name('units.pdf');
    });
});
// END SIBDI FEATURE EXTENSION PROFILE MANAGER PDF MAPS
// BEGIN SIBDI SUPER ADMIN IT EXTENSION
Route::middleware(['auth', 'session.fresh', 'role:5'])
    ->prefix('super-admin')
    ->name('super-admin.')
    ->group(function () {
        Route::get('/', [\App\Http\Controllers\SuperAdminController::class, 'index'])->name('index');
    });
// END SIBDI SUPER ADMIN IT EXTENSION
