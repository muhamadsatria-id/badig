<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Unit1Ideology;
use App\Models\Unit2Economy;
use App\Models\Unit3Sosbud;
use App\Models\Unit4Security;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

class PimpinanFileManagerController extends Controller
{
    private array $modules = [
        'unit1' => ['id' => 1, 'title' => 'Unit 1 Ideologi', 'model' => Unit1Ideology::class, 'main' => 'nama_subjek'],
        'unit2' => ['id' => 2, 'title' => 'Unit 2 Ekonomi', 'model' => Unit2Economy::class, 'main' => 'nama_aset'],
        'unit3' => ['id' => 3, 'title' => 'Unit 3 Sosbud', 'model' => Unit3Sosbud::class, 'main' => 'nama_organisasi'],
        'unit4' => ['id' => 4, 'title' => 'Unit 4 Keamanan', 'model' => Unit4Security::class, 'main' => 'nama_kasus'],
    ];

    public function index(Request $request)
    {
        // PERBAIKAN: Mengizinkan Pimpinan (1) DAN Super Admin (5)
        abort_unless(in_array((int) auth()->user()->role_id, [1, 5], true), 403, 'Akses terbatas untuk pimpinan dan super admin.');
        
        [$rows, $filters] = $this->filteredRows($request);
        $rows = $rows->take(1000)->values();
        return view('pimpinan.file-manager', compact('rows', 'filters'));
    }

    public function export(Request $request, string $type)
    {
        // PERBAIKAN: Mengizinkan Pimpinan (1) DAN Super Admin (5)
        abort_unless(in_array((int) auth()->user()->role_id, [1, 5], true), 403, 'Akses terbatas untuk pimpinan dan super admin.');
        abort_unless(in_array($type, ['pdf', 'excel'], true), 404);

        [$rows, $filters] = $this->filteredRows($request);
        $rows = $rows->values();

        AuditLog::record('PIMPINAN_EXPORT_'.strtoupper($type), 'Export File Manager Pimpinan format '.$type.' total '.$rows->count().' data.');

        if ($type === 'excel') {
            return $this->exportExcel($rows);
        }

        return $this->exportPdf($rows, $filters);
    }

    private function filteredRows(Request $request): array
    {
        $filters = [
            'q' => trim((string) $request->query('q', '')),
            'unit' => (string) $request->query('unit', 'all'),
            'status' => (string) $request->query('status', 'all'),
            'date_from' => (string) $request->query('date_from', ''),
            'date_to' => (string) $request->query('date_to', ''),
        ];

        $selected = $filters['unit'] !== 'all' && isset($this->modules[$filters['unit']])
            ? [$filters['unit'] => $this->modules[$filters['unit']]]
            : $this->modules;

        $rows = collect();

        foreach ($selected as $unit => $module) {
            $query = $module['model']::with(['district', 'village', 'operator']);

            if ($filters['status'] !== 'all') {
                $query->where('status_laporan', $filters['status']);
            }
            if ($filters['date_from'] !== '') {
                $query->whereDate('created_at', '>=', $filters['date_from']);
            }
            if ($filters['date_to'] !== '') {
                $query->whereDate('created_at', '<=', $filters['date_to']);
            }

            $query->latest()->get()->each(function ($item) use (&$rows, $unit, $module) {
                $rows->push([
                    'unit' => $unit,
                    'unit_title' => $module['title'],
                    'main_field' => $module['main'],
                    'id' => $item->id,
                    'kategori' => $item->kategori,
                    'nama' => $item->{$module['main']},
                    'district' => $item->district?->name ?? '-',
                    'village' => $item->village?->name ?? '-',
                    'operator' => $item->operator?->name ?? '-',
                    'status' => $item->status_laporan ?? '-',
                    'lat' => $item->koordinat_lat,
                    'lng' => $item->koordinat_lng,
                    'created_at' => $item->created_at,
                    'updated_at' => $item->updated_at,
                ]);
            });
        }

        if ($filters['q'] !== '') {
            $needle = Str::lower($filters['q']);
            $rows = $rows->filter(function ($row) use ($needle) {
                return Str::contains(Str::lower(implode(' ', array_filter([
                    $row['unit_title'], $row['kategori'], $row['nama'], $row['district'], $row['village'], $row['operator'], $row['status']
                ]))), $needle);
            });
        }

        $rows = $rows->sortByDesc(fn ($row) => optional($row['updated_at'])->timestamp ?? 0)->values();
        return [$rows, $filters];
    }

    private function exportExcel(Collection $rows)
    {
        $html = '<html><head><meta charset="UTF-8"></head><body>';
        $html .= '<table border="1"><thead><tr>';
        foreach (['Unit','ID','Kategori','Nama/Entitas','Kecamatan','Kelurahan/Desa','Operator','Status','Latitude','Longitude','Dibuat','Diubah'] as $head) {
            $html .= '<th>'.e($head).'</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($rows as $row) {
            $html .= '<tr>';
            foreach ([$row['unit_title'], '#'.$row['id'], $row['kategori'], $row['nama'], $row['district'], $row['village'], $row['operator'], $row['status'], $row['lat'], $row['lng'], optional($row['created_at'])->format('d/m/Y H:i'), optional($row['updated_at'])->format('d/m/Y H:i')] as $cell) {
                $html .= '<td>'.e((string) $cell).'</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></body></html>';

        return response($html, 200, [
            'Content-Type' => 'application/vnd.ms-excel; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="sibdi_file_manager_'.now()->format('Ymd_His').'.xls"',
        ]);
    }

    private function exportPdf(Collection $rows, array $filters)
    {
        $lines = [
            'SISTEM INFORMASI DATABASE INTELIJEN POLRES SUKABUMI KOTA',
            'FILE MANAGER PIMPINAN - EXPORT PDF',
            'Filter Unit: '.$filters['unit'].' | Status: '.$filters['status'].' | Dari: '.($filters['date_from'] ?: 'Semua').' | Sampai: '.($filters['date_to'] ?: 'Semua'),
            'Total Data: '.$rows->count(),
            ' ',
        ];

        foreach ($rows->take(48) as $row) {
            $lines[] = $row['unit_title'].' | #'.$row['id'].' | '.$row['kategori'].' | '.$row['nama'].' | '.$row['village'].'/'.$row['district'].' | '.$row['status'];
        }

        if ($rows->count() > 48) {
            $lines[] = 'Catatan: PDF ringkas menampilkan 48 data pertama. Gunakan export Excel untuk seluruh data.';
        }

        $pdf = app(UnitDocumentController::class)->simplePdf($lines, 'File Manager Pimpinan SIBDI-PSK');
        return response($pdf, 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="sibdi_file_manager_'.now()->format('Ymd_His').'.pdf"',
        ]);
    }
}