<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\District;
use App\Models\Unit1Ideology;
use App\Models\Unit2Economy;
use App\Models\Unit3Sosbud;
use App\Models\Unit4Security;
use App\Models\Village;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class IntelUnitController extends Controller
{
    private array $modules = [
        'unit1' => [
            'id' => 1, 'title' => 'Unit 1 Ideologi', 'model' => Unit1Ideology::class,
            'main' => 'nama_subjek', 'fields' => ['kategori','nama_subjek','district_id','village_id','pengikut','status_legal','catatan_rawan','koordinat_lat','koordinat_lng','status_laporan']
        ],
        'unit2' => [
            'id' => 2, 'title' => 'Unit 2 Ekonomi', 'model' => Unit2Economy::class,
            'main' => 'nama_aset', 'fields' => ['kategori','nama_aset','district_id','village_id','alamat','kapasitas','koordinat_lat','koordinat_lng','status_laporan']
        ],
        'unit3' => [
            'id' => 3, 'title' => 'Unit 3 Sosbud', 'model' => Unit3Sosbud::class,
            'main' => 'nama_organisasi', 'fields' => ['kategori','nama_organisasi','pimpinan','district_id','village_id','total_anggota','legalitas','catatan_aktivitas','koordinat_lat','koordinat_lng','status_laporan']
        ],
        'unit4' => [
            'id' => 4, 'title' => 'Unit 4 Keamanan', 'model' => Unit4Security::class,
            'main' => 'nama_kasus', 'fields' => ['kategori','nama_kasus','district_id','village_id','modus','koordinat_lat','koordinat_lng','status_kasus','data_enkripsi','status_laporan']
        ],
    ];

    private function module(string $unit): array
    {
        abort_unless(isset($this->modules[$unit]), 404);
        return $this->modules[$unit];
    }

    private function authorizeUnit(string $unit, bool $write = false): void
    {
        $module = $this->module($unit);
        $user = auth()->user();

        if ($user->role_id === 4) {
            abort(403, 'Admin IT tidak membuka data operasional intelijen.');
        }

        // PERBAIKAN: Jika write (menulis/mengubah), batasi Pimpinan (1) DAN Super Admin (5) jika Super Admin hanya boleh melihat data operasional unit langsung. 
        // Namun jika Super Admin (5) BOLEH menulis, ubah bagian ini. Di bawah ini diasumsikan Super Admin memiliki hak penuh termasuk menulis, sehingga hanya role 1 (Pimpinan) yang dilarang menulis data mentah.
        if ($write && $user->role_id === 1) {
            abort(403, 'Pimpinan hanya memiliki akses lihat data.');
        }

        if ($user->role_id === 2 && (int) $user->unit_id !== (int) $module['id']) {
            abort(403, 'Operator hanya dapat mengakses unit kerja masing-masing.');
        }
    }

    public function index(string $unit)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $model = $module['model'];
        $items = $model::with(['district','village','operator'])->latest()->paginate(10);
        return view('units.index', compact('unit', 'module', 'items'));
    }

    public function create(string $unit)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $districts = District::with('villages')->orderBy('name')->get();
        $villages = Village::orderBy('name')->get();
        return view('units.form', compact('unit', 'module', 'districts', 'villages'));
    }

    public function store(Request $request, string $unit)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $data = $this->validated($request, $unit);
        $data['operator_id'] = auth()->id();
        $item = $module['model']::create($data);
        AuditLog::record('CREATE_'.$unit, 'Menambah data '.$module['title'].' ID '.$item->id);
        return redirect()->route('units.show', [$unit, $item->id])->with('success', 'Data berhasil disimpan.');
    }

    public function show(string $unit, int $id)
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $item = $module['model']::with(['district','village','operator'])->findOrFail($id);
        return view('units.show', compact('unit', 'module', 'item'));
    }

    public function edit(string $unit, int $id)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $item = $module['model']::findOrFail($id);
        $districts = District::with('villages')->orderBy('name')->get();
        $villages = Village::orderBy('name')->get();
        return view('units.form', compact('unit', 'module', 'item', 'districts', 'villages'));
    }

    public function update(Request $request, string $unit, int $id)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $item = $module['model']::findOrFail($id);
        $item->update($this->validated($request, $unit));
        AuditLog::record('UPDATE_'.$unit, 'Mengubah data '.$module['title'].' ID '.$item->id);
        return redirect()->route('units.show', [$unit, $item->id])->with('success', 'Data berhasil diperbarui.');
    }

    public function destroy(string $unit, int $id)
    {
        $this->authorizeUnit($unit, true);
        $module = $this->module($unit);
        $item = $module['model']::findOrFail($id);
        $item->delete();
        AuditLog::record('DELETE_'.$unit, 'Menghapus data '.$module['title'].' ID '.$id);
        return redirect()->route('units.index', $unit)->with('success', 'Data berhasil dihapus.');
    }

    public function reports()
    {
        // PERBAIKAN: Mengizinkan Validator (3) DAN Super Admin (5) untuk masuk ke halaman validasi
        abort_unless(in_array((int) auth()->user()->role_id, [3, 5], true), 403, 'Anda tidak memiliki otoritas untuk mengakses modul validasi ini.');
        
        $reports = collect();
        foreach ($this->modules as $unit => $module) {
            $module['model']::with(['operator','district','village'])
                ->whereIn('status_laporan', ['draft','submitted','rejected'])
                ->latest()->limit(10)->get()->each(function ($item) use (&$reports, $unit, $module) {
                    $reports->push(['unit' => $unit, 'module' => $module, 'item' => $item]);
                });
        }
        $reports = $reports->sortByDesc(fn($r) => $r['item']->updated_at)->values();
        return view('reports.index', compact('reports'));
    }

    public function validateReport(Request $request, string $unit, int $id)
    {
        // PERBAIKAN: Mengizinkan Validator (3) DAN Super Admin (5) untuk memproses validasi keputusan laporan
        abort_unless(in_array((int) auth()->user()->role_id, [3, 5], true), 403, 'Anda tidak memiliki otoritas untuk memproses validasi ini.');
        
        $module = $this->module($unit);
        $request->validate([
            'decision' => ['required', 'in:approved,rejected,submitted'],
            'catatan_validasi' => ['nullable', 'string', 'max:2000'],
        ]);
        $item = $module['model']::findOrFail($id);
        $item->update([
            'status_laporan' => $request->decision,
            'catatan_validasi' => $request->catatan_validasi,
        ]);
        AuditLog::record('VALIDATE_REPORT', strtoupper($request->decision).' '.$module['title'].' ID '.$id);
        return back()->with('success', 'Status laporan berhasil diperbarui.');
    }

    private function validated(Request $request, string $unit): array
    {
        $base = [
            'kategori' => ['required', 'string', 'max:100'],
            'district_id' => ['required', 'exists:districts,id'],
            'village_id' => ['required', 'exists:villages,id'],
            'koordinat_lat' => ['nullable', 'numeric', 'between:-90,90'],
            'koordinat_lng' => ['nullable', 'numeric', 'between:-180,180'],
            'status_laporan' => ['required', 'in:draft,submitted,approved,rejected'],
        ];

        // Baris 176: Dibuka dengan tanda kurung kurawal '{'
        $rules = match ($unit) {
            'unit1' => array_merge($base, [
                'nama_subjek' => ['required', 'string', 'max:255'],
                'pengikut' => ['nullable', 'integer', 'min:0'],
                'status_legal' => ['nullable', 'string', 'max:100'],
                'catatan_rawan' => ['nullable', 'string'],
            ]),
            'unit2' => array_merge($base, [
                'nama_aset' => ['required', 'string', 'max:255'],
                'alamat' => ['required', 'string', 'max:500'],
                'kapasitas' => ['nullable', 'string', 'max:255'],
            ]),
            'unit3' => array_merge($base, [
                'nama_organisasi' => ['required', 'string', 'max:255'],
                'pimpinan' => ['nullable', 'string', 'max:255'],
                'total_anggota' => ['nullable', 'integer', 'min:0'],
                'legalitas' => ['nullable', 'string', 'max:100'],
                'catatan_aktivitas' => ['nullable', 'string'],
            ]),
            'unit4' => array_merge($base, [
                'nama_kasus' => ['required', 'string', 'max:255'],
                'modus' => ['nullable', 'string'],
                'status_kasus' => ['required', 'string', 'max:100'],
                'data_enkripsi' => ['nullable', 'string'],
            ]),
        }; // BARIS 201: DIUBAH MENJADI }; (BUKAN ];)

        return Validator::make($request->all(), $rules)->validate();
    }
}