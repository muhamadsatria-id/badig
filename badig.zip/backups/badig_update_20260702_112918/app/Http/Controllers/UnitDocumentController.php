<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Unit1Ideology;
use App\Models\Unit2Economy;
use App\Models\Unit3Sosbud;
use App\Models\Unit4Security;
use Illuminate\Support\Str;
use Barryvdh\DomPDF\Facade\Pdf;

class UnitDocumentController extends Controller
{
    private array $modules = [
        'unit1' => [
            'id' => 1, 'title' => 'Unit 1 Ideologi', 'model' => Unit1Ideology::class, 'main' => 'nama_subjek',
            'fields' => ['kategori','nama_subjek','district_id','village_id','pengikut','status_legal','catatan_rawan','koordinat_lat','koordinat_lng','status_laporan','catatan_validasi','created_at','updated_at'],
        ],
        'unit2' => [
            'id' => 2, 'title' => 'Unit 2 Ekonomi', 'model' => Unit2Economy::class, 'main' => 'nama_aset',
            'fields' => ['kategori','nama_aset','district_id','village_id','alamat','kapasitas','koordinat_lat','koordinat_lng','status_laporan','catatan_validasi','created_at','updated_at'],
        ],
        'unit3' => [
            'id' => 3, 'title' => 'Unit 3 Sosbud', 'model' => Unit3Sosbud::class, 'main' => 'nama_organisasi',
            'fields' => ['kategori','nama_organisasi','pimpinan','district_id','village_id','total_anggota','legalitas','catatan_aktivitas','koordinat_lat','koordinat_lng','status_laporan','catatan_validasi','created_at','updated_at'],
        ],
        'unit4' => [
            'id' => 4, 'title' => 'Unit 4 Keamanan', 'model' => Unit4Security::class, 'main' => 'nama_kasus',
            'fields' => ['kategori','nama_kasus','district_id','village_id','modus','koordinat_lat','koordinat_lng','status_kasus','data_enkripsi','status_laporan','catatan_validasi','created_at','updated_at'],
        ],
    ];

    private function module(string $unit): array
    {
        abort_unless(isset($this->modules[$unit]), 404);
        return $this->modules[$unit];
    }

    private function authorizeUnit(string $unit): void
    {
        $user = auth()->user();
        $module = $this->module($unit);

        abort_if($user->role_id === 4, 403, 'Admin IT tidak membuka dokumen operasional intelijen.');
        abort_if($user->role_id === 2 && (int) $user->unit_id !== (int) $module['id'], 403, 'Operator hanya dapat membuka dokumen unit kerja masing-masing.');
    }

    private function findRecord(string $unit, int $id): array
    {
        $this->authorizeUnit($unit);
        $module = $this->module($unit);
        $item = $module['model']::with(['district','village','operator'])->findOrFail($id);
        return [$module, $item];
    }

    public function html(string $unit, int $id)
    {
        [$module, $item] = $this->findRecord($unit, $id);
        AuditLog::record('PREVIEW_DOCUMENT', 'Membuka pratinjau dokumen '.$module['title'].' ID '.$id);
        return view('documents.unit', compact('unit', 'module', 'item'));
    }

    // public function pdf(string $unit, int $id)
    // {
    //     [$module, $item] = $this->findRecord($unit, $id);
    //     $lines = $this->recordLines($module, $item);
    //     $pdf = $this->simplePdf($lines, 'SIBDI-PSK '.$module['title'].' ID '.$id);
    //     AuditLog::record('DOWNLOAD_PDF', 'Mengunduh PDF dokumen '.$module['title'].' ID '.$id);

    //     $filename = Str::slug($module['title'].'-'.$item->{$module['main']}.'-'.$item->id).'.pdf';
    //     return response($pdf, 200, [
    //         'Content-Type' => 'application/pdf',
    //         'Content-Disposition' => 'inline; filename="'.$filename.'"',
    //     ]);
    // }

    public function recordLines(array $module, object $item): array
    {
        $lines = [
            'SISTEM INFORMASI DATABASE INTELIJEN POLRES SUKABUMI KOTA',
            'DOKUMEN DATA: '.$module['title'],
            'ID ARSIP: #'.$item->id,
            'NAMA/ENTITAS: '.$item->{$module['main']},
            ' ',
        ];

        foreach ($module['fields'] as $field) {
            $label = strtoupper(str_replace('_', ' ', $field));
            $value = match ($field) {
                'district_id' => $item->district?->name ?? '-',
                'village_id' => $item->village?->name ?? '-',
                'created_at' => optional($item->created_at)->format('d/m/Y H:i') ?? '-',
                'updated_at' => optional($item->updated_at)->format('d/m/Y H:i') ?? '-',
                default => $item->{$field} ?? '-',
            };
            $lines[] = $label.': '.$value;
        }

        $lines[] = 'OPERATOR: '.($item->operator?->name ?? '-');
        $lines[] = 'DICETAK: '.now()->format('d/m/Y H:i');
        return $lines;
    }

    public function simplePdf(array $lines, string $title = 'SIBDI-PSK'): string
    {
        $safeLines = [];
        foreach ($lines as $line) {
            $line = preg_replace('/\s+/', ' ', (string) $line);
            $safeLines[] = mb_substr($line, 0, 112);
        }

        $content = "BT\n/F1 10 Tf\n50 790 Td\n14 TL\n";
        foreach (array_slice($safeLines, 0, 52) as $line) {
            $content .= '('.$this->pdfEscape($line).") Tj\nT*\n";
        }
        $content .= "ET\n";

        $objects = [];
        $objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
        $objects[] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>';
        $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
        $objects[] = '<< /Length '.strlen($content).' >>' . "\nstream\n" . $content . "endstream";

        $pdf = "%PDF-1.4\n%SIBDI-PSK\n";
        $offsets = [0];
        foreach ($objects as $i => $object) {
            $offsets[] = strlen($pdf);
            $pdf .= ($i + 1)." 0 obj\n".$object."\nendobj\n";
        }

        $xref = strlen($pdf);
        $pdf .= "xref\n0 ".(count($objects) + 1)."\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<< /Size ".(count($objects) + 1)." /Root 1 0 R /Title (".$this->pdfEscape($title).") >>\nstartxref\n".$xref."\n%%EOF";
        return $pdf;
    }

    private function pdfEscape(string $text): string
    {
        $text = iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $text) ?: $text;
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    }

    public function pdf(string $unit, int $id)
    {
        // 1. Ambil data rekam dokumen dari database
        [$module, $item] = $this->findRecord($unit, $id);
        
        // 2. Rekam riwayat unduhan berkas rahasia ke Audit Log
        AuditLog::record('DOWNLOAD_PDF', 'Mengunduh PDF dokumen '.$module['title'].' ID '.$id);

        // 3. Buat nama file unduhan yang bersih (Slug-friendly)
        $filename = Str::slug($module['title'].'-'.$item->{$module['main']}.'-'.$item->id).'.pdf';
        
        // 4. Render view 'units.pdf_cetak' yang sudah Anda buat ke dalam Dompdf
        $pdf = Pdf::loadView('units.pdf_cetak', compact('unit', 'module', 'item'));
        
        // 5. Set ukuran kertas resmi ke A4 bentuk potret (Portrait)
        $pdf->setPaper('a4', 'portrait');
        
        // 6. Alirkan (Stream) dokumen agar langsung memicu preview / print download otomatis di browser
        return $pdf->stream($filename);
    }
}
