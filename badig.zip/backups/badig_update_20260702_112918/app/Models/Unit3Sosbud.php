<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit3Sosbud extends Model
{
    protected $table = 'unit3_sosbud';
    protected $fillable = [
        'kategori', 'nama_organisasi', 'pimpinan', 'district_id', 'village_id',
        'total_anggota', 'legalitas', 'catatan_aktivitas', 'koordinat_lat', 'koordinat_lng',
        'status_laporan', 'catatan_validasi', 'operator_id'
    ];

    protected function casts(): array
    {
        return ['koordinat_lat' => 'decimal:8', 'koordinat_lng' => 'decimal:8'];
    }

    public function district(){ return $this->belongsTo(District::class); }
    public function village(){ return $this->belongsTo(Village::class); }
    public function operator(){ return $this->belongsTo(User::class, 'operator_id'); }
}
