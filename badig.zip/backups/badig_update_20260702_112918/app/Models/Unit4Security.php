<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit4Security extends Model
{
    protected $table = 'unit4_security_crim';
    protected $fillable = [
        'kategori', 'nama_kasus', 'district_id', 'village_id', 'modus', 'koordinat_lat',
        'koordinat_lng', 'status_kasus', 'data_enkripsi', 'status_laporan',
        'catatan_validasi', 'operator_id'
    ];

    protected function casts(): array
    {
        return [
            'koordinat_lat' => 'decimal:8',
            'koordinat_lng' => 'decimal:8',
            'data_enkripsi' => 'encrypted',
        ];
    }

    public function district(){ return $this->belongsTo(District::class); }
    public function village(){ return $this->belongsTo(Village::class); }
    public function operator(){ return $this->belongsTo(User::class, 'operator_id'); }
}
