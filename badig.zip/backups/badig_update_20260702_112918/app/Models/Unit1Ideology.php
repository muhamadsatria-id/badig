<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit1Ideology extends Model
{
    protected $table = 'unit1_ideology';
    protected $fillable = [
        'kategori', 'nama_subjek', 'district_id', 'village_id', 'pengikut',
        'status_legal', 'catatan_rawan', 'koordinat_lat', 'koordinat_lng',
        'status_laporan', 'catatan_validasi', 'operator_id'
    ];

    protected function casts(): array
    {
        return ['koordinat_lat' => 'decimal:8', 'koordinat_lng' => 'decimal:8'];
    }

    public function district(){ return $this->belongsTo(District::class); }
    public function village(){ return $this->belongsTo(Village::class); }
    public function operator(){ return $this->belongsTo(User::class, 'operator_id'); }
}
