@extends('layouts.app')

@section('title', $module['title'])
@section('page_title', $module['title'])

@section('content')
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 transition-all duration-500 ease-in-out animate-fade-in">
    <div>
        <h2 class="text-2xl font-extrabold tracking-tight text-primary transition-colors duration-300">
            Daftar Arsip: {{ $module['title'] }}
        </h2>
        <p class="text-xs text-secondary mt-1 max-w-xl leading-relaxed">
            Gunakan panel ini untuk mengaudit, memantau sebaran data sektoral, serta mengelola status rilis laporan operasional.
        </p>
    </div>
    <div class="bg-surface-container text-on-surface-variant font-bold text-xs px-4 py-1.5 rounded-full uppercase tracking-wider border border-outline-variant/40 flex items-center gap-1.5 shadow-sm hover:shadow transition-all duration-300 hover:border-primary/30">
        <span class="material-symbols-outlined text-[16px] text-primary animate-pulse">folder_open</span>
        {{ strtoupper($unit) }} Data Registry
    </div>
</div>

<div class="bg-white rounded-2xl border border-outline-variant shadow-sm hover:shadow-md transition-shadow duration-300 p-4 sm:p-5 md:p-6">
    
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
            <h3 class="font-bold text-primary text-base">Basis Data Terintegrasi</h3>
            <p class="text-xs text-on-surface-variant opacity-80">Tabel manajemen dilengkapi penelusuran riwayat operator dinas.</p>
        </div>
        
        @if(auth()->user()->role_id !== 1)
            <a href="{{ route('units.create', $unit) }}" 
               class="bg-primary-container hover:bg-[#0f1b40] text-on-primary font-bold text-xs px-5 py-3 rounded-xl transition-all duration-300 shadow-md hover:shadow-lg hover:-translate-y-0.5 flex items-center justify-center gap-2 group active:scale-[0.97]">
                <span class="material-symbols-outlined text-[18px] group-hover:rotate-90 transition-transform duration-300">add_circle</span>
                <span>Tambah Data Registrasi</span>
            </a>
        @endif
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 lg:hidden">
        @forelse($items as $item)
            <div class="bg-white border border-outline-variant/70 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group flex flex-col justify-between">
                <div class="absolute top-0 left-0 right-0 h-[3px] bg-primary scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
                
                <div>
                    <div class="flex justify-between items-center mb-3">
                        <span class="text-xs font-mono text-outline font-bold bg-surface-container/60 px-2 py-0.5 rounded">
                            #{{ $item->id }}
                        </span>
                        
                        <div>
                            @if($item->status_laporan === 'approved')
                                <span class="bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2.5 py-0.5 rounded-md font-bold text-[10px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> APPROVED
                                </span>
                            @elseif($item->status_laporan === 'rejected')
                                <span class="bg-error-container/40 text-on-error-container border border-error/20 px-2.5 py-0.5 rounded-md font-bold text-[10px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-error animate-ping absolute inline-flex opacity-75"></span>
                                    <span class="relative inline-flex rounded-full h-1.5 w-1.5 bg-error"></span> REJECTED
                                </span>
                            @else
                                <span class="bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-md font-bold text-[10px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span> {{ strtoupper($item->status_laporan) }}
                                </span>
                            @endif
                        </div>
                    </div>

                    <div class="mb-3">
                        <span class="bg-primary-container/10 text-primary px-2 py-0.5 rounded text-[11px] font-semibold border border-primary-container/10 inline-block mb-1.5">
                            {{ $item->kategori }}
                        </span>
                        <h4 class="font-bold text-primary text-base group-hover:text-primary-container transition-colors duration-200">
                            {{ $item->{$module['main']} }}
                        </h4>
                    </div>

                    <div class="space-y-2 pt-2 border-t border-outline-variant/40 text-xs">
                        <div class="flex items-center gap-2 text-on-surface-variant">
                            <span class="material-symbols-outlined text-[16px] text-outline">location_on</span>
                            <span class="truncate">{{ $item->village?->name ?? 'Kelurahan' }}, {{ $item->district?->name ?? 'Kecamatan' }}</span>
                        </div>
                        <div class="flex items-center gap-2 text-secondary">
                            <span class="w-5 h-5 rounded-full bg-surface-container flex items-center justify-center text-[10px] text-primary font-bold shadow-xs">
                                {{ strtoupper(substr($item->operator?->name ?? '-', 0, 1)) }}
                            </span>
                            <span class="truncate">{{ $item->operator?->name ?? '-' }}</span>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-outline-variant/40">
                    <a href="{{ route('units.show', [$unit, $item->id]) }}" 
                       class="flex items-center justify-center gap-1 text-primary bg-surface-container hover:bg-primary/10 py-2 rounded-xl transition-all duration-200 text-xs font-bold active:scale-95">
                        <span class="material-symbols-outlined text-[16px]">visibility</span> Detail
                    </a>
                    <a href="{{ route('units.pdf', [$unit, $item->id]) }}" target="_blank"
                       class="flex items-center justify-center gap-1 text-error bg-error-container/10 hover:bg-error-container/30 py-2 rounded-xl transition-all duration-200 text-xs font-bold active:scale-95">
                        <span class="material-symbols-outlined text-[16px]">picture_as_pdf</span> PDF
                    </a>
                    @if(auth()->user()->role_id !== 1)
                        <a href="{{ route('units.edit', [$unit, $item->id]) }}" 
                           class="flex items-center justify-center gap-1 text-amber-700 bg-amber-50 hover:bg-amber-100 py-2 rounded-xl transition-all duration-200 text-xs font-bold active:scale-95 col-span-1">
                            <span class="material-symbols-outlined text-[16px]">edit</span> Edit
                        </a>
                        <form method="POST" action="{{ route('units.destroy', [$unit, $item->id]) }}" class="col-span-1" 
                              onsubmit="return confirm('Apakah Anda yakin ingin menghapus arsip data ini?')">
                            @csrf 
                            @method('DELETE')
                            <button type="submit" class="w-full flex items-center justify-center gap-1 text-error bg-red-50 hover:bg-red-100 py-2 rounded-xl transition-all duration-200 text-xs font-bold active:scale-95">
                                <span class="material-symbols-outlined text-[16px]">delete</span> Hapus
                            </button>
                        </form>
                    @endif
                </div>
            </div>
        @empty
            <div class="col-span-1 md:col-span-2 text-center py-10 text-outline border border-dashed border-outline-variant rounded-2xl">
                <span class="material-symbols-outlined text-4xl mb-2 text-outline/60">inventory_2</span>
                <h4 class="text-sm font-bold text-primary">Arsip Data Kosong</h4>
            </div>
        @endforelse
    </div>

    <div class="hidden lg:block overflow-x-auto rounded-xl border border-outline-variant shadow-inner transition-all duration-300">
        <table class="min-w-full text-sm divide-y divide-outline-variant">
            <thead class="bg-surface-container text-on-surface-variant font-semibold">
                <tr>
                    <th class="p-4 text-left text-xs uppercase tracking-wider w-16">ID</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Kategori</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Nama Utama / Entitas</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Wilayah Sektor (Yurisdiksi)</th>
                    <th class="p-4 text-center text-xs uppercase tracking-wider">Status Laporan</th>
                    <th class="p-4 text-left text-xs uppercase tracking-wider">Operator Input</th>
                    <th class="p-4 text-right text-xs uppercase tracking-wider w-44">Aksi Operasi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-outline-variant bg-white text-on-surface">
                @forelse($items as $item)
                    <tr class="hover:bg-surface-container-low/60 transition-all duration-200 group/tr">
                        <td class="p-4 text-xs font-mono text-outline font-bold">
                            #{{ $item->id }}
                        </td>
                        <td class="p-4 whitespace-nowrap">
                            <span class="bg-primary-container/10 text-primary px-2.5 py-0.5 rounded-md text-xs font-semibold border border-primary-container/10 group-hover/tr:bg-primary group-hover/tr:text-white transition-all duration-300">
                                {{ $item->kategori }}
                            </span>
                        </td>
                        <td class="p-4 font-bold text-primary group-hover/tr:text-primary-container transition-colors duration-200">
                            {{ $item->{$module['main']} }}
                        </td>
                        <td class="p-4 text-xs text-on-surface-variant font-medium">
                            <div class="flex items-center gap-1 group-hover/tr:translate-x-0.5 transition-transform duration-200">
                                <span class="material-symbols-outlined text-[14px] text-outline">location_on</span>
                                <span>{{ $item->village?->name ?? 'Kelurahan' }}, {{ $item->district?->name ?? 'Kecamatan' }}</span>
                            </div>
                        </td>
                        <td class="p-4 text-center whitespace-nowrap">
                            @if($item->status_laporan === 'approved')
                                <span class="bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2.5 py-0.5 rounded-md font-bold text-[11px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> APPROVED
                                </span>
                            @elseif($item->status_laporan === 'rejected')
                                <span class="bg-error-container/40 text-on-error-container border border-error/20 px-2.5 py-0.5 rounded-md font-bold text-[11px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-error animate-pulse"></span> REJECTED
                                </span>
                            @else
                                <span class="bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-md font-bold text-[11px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span> {{ strtoupper($item->status_laporan) }}
                                </span>
                            @endif
                        </td>
                        <td class="p-4 text-xs text-secondary font-medium whitespace-nowrap">
                            <div class="flex items-center gap-1.5">
                                <span class="w-5 h-5 rounded-full bg-surface-container flex items-center justify-center text-[11px] text-primary font-bold group-hover/tr:scale-110 transition-transform duration-200 shadow-2xs">
                                    {{ strtoupper(substr($item->operator?->name ?? '-', 0, 1)) }}
                                </span>
                                <span>{{ $item->operator?->name ?? '-' }}</span>
                            </div>
                        </td>
                        <td class="p-4 text-right whitespace-nowrap text-xs font-bold">
                            <div class="inline-flex items-center gap-1 opacity-90 group-hover/tr:opacity-100 transition-opacity duration-200">
                                <a href="{{ route('units.show', [$unit, $item->id]) }}" 
                                   class="text-primary hover:bg-surface-container px-2.5 py-1.5 rounded-lg transition-all duration-200 inline-flex items-center gap-0.5 hover:scale-105 active:scale-95">
                                    <span class="material-symbols-outlined text-[16px]">visibility</span>
                                    <span>Detail</span>
                                </a>
                                <a href="{{ route('units.pdf', [$unit, $item->id]) }}" target="_blank"
                                   class="text-error hover:bg-error-container/20 px-2.5 py-1.5 rounded-lg transition-all duration-200 inline-flex items-center gap-0.5 hover:scale-105 active:scale-95">
                                    <span class="material-symbols-outlined text-[16px]">picture_as_pdf</span>
                                    <span>PDF</span>
                                </a>
                                
                                @if(auth()->user()->role_id !== 1)
                                    <a href="{{ route('units.edit', [$unit, $item->id]) }}" 
                                       class="text-amber-700 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg transition-all duration-200 inline-flex items-center gap-0.5 hover:scale-105 active:scale-95">
                                        <span class="material-symbols-outlined text-[16px]">edit</span>
                                        <span>Edit</span>
                                    </a>
                                    <form method="POST" action="{{ route('units.destroy', [$unit, $item->id]) }}" class="inline" 
                                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus arsip data intelijen ini?')">
                                        @csrf 
                                        @method('DELETE')
                                        <button type="submit" class="text-error hover:bg-red-50 px-2.5 py-1.5 rounded-lg transition-all duration-200 inline-flex items-center gap-0.5 hover:scale-105 active:scale-95">
                                            <span class="material-symbols-outlined text-[16px]">delete</span>
                                            <span>Hapus</span>
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="p-10 text-center text-outline bg-surface-container-low/30">
                            <div class="w-12 h-12 bg-white rounded-full border border-outline-variant/60 flex items-center justify-center mx-auto mb-3 shadow-xs text-outline animate-bounce">
                                <span class="material-symbols-outlined text-2xl">inventory_2</span>
                            </div>
                            <h4 class="text-sm font-bold text-primary mb-0.5">Arsip Data Kosong</h4>
                            <p class="text-xs text-on-surface-variant opacity-80">Belum ada rekaman data intelijen terdaftar untuk kategori unit ini.</p>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <div class="mt-6 pt-3 border-t border-outline-variant/30 flex justify-end">
        <div class="w-full sm:w-auto transition-transform duration-300">
            {{ $items->links() }}
        </div>
    </div>
</div>
@endsection