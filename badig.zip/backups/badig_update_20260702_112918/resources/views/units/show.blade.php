@extends('layouts.app')

@section('title', 'Detail '.$module['title'])
@section('page_title', 'Detail '.$module['title'])

@section('content')
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 animate-fade-in transition-all duration-500">
    <div>
        <h2 class="text-2xl font-extrabold tracking-tight text-primary">Pratinjau Informasi Dokumen</h2>
        <p class="text-xs text-secondary mt-1">Detail data operasional terintegrasi lintas unit yurisdiksi.</p>
    </div>
    <div class="flex gap-2.5 w-full sm:w-auto">
        <a href="{{ route('units.pdf', [$unit, $item->id]) }}" 
           target="_blank" 
           class="flex-1 sm:flex-none bg-error hover:bg-red-800 text-white px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-all duration-200 shadow-xs hover:shadow hover:-translate-y-0.5 active:scale-95">
            <span class="material-symbols-outlined text-[16px]">picture_as_pdf</span>
            <span>Buka PDF</span>
        </a>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
    
    <div class="lg:col-span-2 bg-white rounded-2xl border border-outline-variant shadow-sm p-4 sm:p-5 md:p-6 hover:shadow-md transition-shadow duration-300">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 pb-5 border-b border-outline-variant/40">
            <div>
                <h3 class="text-xl md:text-2xl font-extrabold tracking-tight text-primary transition-colors duration-200">
                    {{ $item->{$module['main']} }}
                </h3>
                <div class="text-xs text-on-surface-variant font-semibold flex items-center flex-wrap gap-x-2 gap-y-1 mt-2">
                    <span class="bg-primary-container/10 text-primary px-2 py-0.5 rounded border border-primary-container/10">{{ $item->kategori }}</span>
                    <span class="text-outline/60">•</span>
                    <span class="flex items-center gap-0.5 text-secondary">
                        <span class="material-symbols-outlined text-[14px]">location_on</span>
                        {{ $item->village?->name ?? 'Kelurahan' }}, {{ $item->district?->name ?? 'Kecamatan' }}
                    </span>
                </div>
            </div>
            
            <div class="shrink-0">
                @if($item->status_laporan === 'approved')
                    <span class="bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-3 py-1.5 rounded-lg font-bold text-xs uppercase tracking-wide inline-flex items-center gap-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> APPROVED
                    </span>
                @elseif($item->status_laporan === 'rejected')
                    <span class="bg-error-container/40 text-on-error-container border border-error/20 px-3 py-1.5 rounded-lg font-bold text-xs uppercase tracking-wide inline-flex items-center gap-1 relative">
                        <span class="w-1.5 h-1.5 rounded-full bg-error animate-ping absolute inline-flex opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-1.5 w-1.5 bg-error"></span> REJECTED
                    </span>
                @else
                    <span class="bg-amber-50 text-amber-700 border border-amber-200 px-3 py-1.5 rounded-lg font-bold text-xs uppercase tracking-wide inline-flex items-center gap-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span> {{ strtoupper($item->status_laporan) }}
                    </span>
                @endif
            </div>
        </div>

        <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            @foreach($module['fields'] as $field)
                @php 
                    $isFullWidth = str_contains($field, 'catatan') || str_contains($field, 'modus') || str_contains($field, 'data') || str_contains($field, 'alamat') || str_contains($field, 'kronologi'); 
                @endphp
                <div class="bg-surface-container-low/50 border border-outline-variant/40 rounded-xl p-4 {{ $isFullWidth ? 'sm:col-span-2' : '' }} hover:border-primary/20 hover:bg-surface-container-low transition-all duration-200 group">
                    <dt class="text-[11px] font-bold text-secondary uppercase tracking-wider mb-1.5 group-hover:text-primary transition-colors duration-200">
                        {{ ucwords(str_replace('_',' ', $field)) }}
                    </dt>
                    <dd class="font-semibold text-primary text-sm whitespace-pre-line leading-relaxed">
                        {{ $field === 'district_id' ? $item->district?->name : ($field === 'village_id' ? $item->village?->name : ($item->{$field} ?? '-')) }}
                    </dd>
                </div>
            @endforeach
            
            <div class="bg-surface-container-low/50 border border-outline-variant/40 rounded-xl p-4 hover:border-primary/20 transition-all duration-200">
                <dt class="text-[11px] font-bold text-secondary uppercase tracking-wider mb-1.5">Operator Registrasi</dt>
                <dd class="font-bold text-primary text-sm flex items-center gap-1.5">
                    <span class="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-[10px] text-primary font-bold">
                        {{ strtoupper(substr($item->operator?->name ?? '-', 0, 1)) }}
                    </span>
                    <span>{{ $item->operator?->name ?? '-' }}</span>
                </dd>
            </div>
            <div class="bg-surface-container-low/50 border border-outline-variant/40 rounded-xl p-4 hover:border-primary/20 transition-all duration-200">
                <dt class="text-[11px] font-bold text-secondary uppercase tracking-wider mb-1.5">Catatan Koreksi Validasi</dt>
                <dd class="font-bold text-error text-sm">{{ $item->catatan_validasi ?? '-' }}</dd>
            </div>
        </dl>

        <div class="mt-6 pt-5 border-t border-outline-variant/40 flex flex-wrap items-center gap-3">
            <a href="{{ route('units.index', $unit) }}" 
               class="w-full sm:w-auto bg-surface-container hover:bg-surface-container-high text-primary border border-outline-variant/60 px-5 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors active:scale-[0.97]">
                <span class="material-symbols-outlined text-[18px]">arrow_back</span>Kembali Ke Daftar
            </a>
            @if(auth()->user()->role_id !== 1)
                <a href="{{ route('units.edit', [$unit, $item->id]) }}" 
                   class="w-full sm:w-auto bg-primary-container hover:bg-[#0f1b40] text-on-primary font-bold text-xs px-5 py-3 rounded-xl shadow-xs hover:shadow flex items-center justify-center gap-1.5 transition-all hover:-translate-y-0.5 active:scale-[0.97]">
                    <span class="material-symbols-outlined text-[18px]">edit</span>Ubah Data Berkas
                </a>
            @endif
        </div>
    </div>

    <div class="space-y-6 lg:sticky lg:top-24">
        
        <div class="bg-white rounded-2xl border border-outline-variant shadow-sm p-4 sm:p-5 hover:shadow-md transition-shadow duration-300">
            <div class="flex items-center gap-2 mb-4">
                <span class="material-symbols-outlined text-primary animate-pulse">map</span>
                <h3 class="font-bold text-primary text-base">Penanda Geospasial / GIS</h3>
            </div>
            <div id="map" class="h-60 rounded-xl border border-outline-variant shadow-inner z-10 overflow-hidden"></div>
            <div class="mt-3 p-2.5 bg-surface-container rounded-xl flex justify-between items-center text-[10px] font-mono font-bold text-on-surface-variant border border-outline-variant/25">
                <span>Lat: {{ $item->koordinat_lat ?? '-' }}</span>
                <span>Lng: {{ $item->koordinat_lng ?? '-' }}</span>
            </div>
        </div>
        
        <div class="bg-white rounded-2xl border border-outline-variant shadow-sm p-4 hover:shadow-md transition-shadow duration-300">
            <h3 class="font-bold text-primary text-sm mb-3 flex items-center gap-2">
                <span class="material-symbols-outlined text-[18px]">picture_as_pdf</span>
                Pratinjau Lembar Dokumen (A4 Cover)
            </h3>
            
            <div class="w-full bg-surface-container-low rounded-xl p-3 flex justify-center items-center border border-outline-variant/20 shadow-inner overflow-hidden relative group">
                
                <div class="w-full aspect-[21/29.7] bg-white shadow-xs group-hover:shadow-md border border-outline-variant/30 rounded-xs overflow-hidden relative select-none transition-shadow duration-300">
                    <div class="absolute inset-0 bg-transparent z-20 cursor-default"></div>
                    <iframe src="{{ route('units.document', [$unit, $item->id, 'embed' => 1]) }}" 
                            class="absolute inset-0 w-full h-full border-none z-10 pointer-events-none"
                            style="transform: scale(1.02); transform-origin: top left;"
                            scrolling="no"></iframe>
                </div>
            </div>
            
            <p class="text-[10px] text-center text-on-surface-variant font-medium mt-2.5 opacity-80 leading-normal">
                Gunakan tombol <span class="font-bold text-primary">"Detail Dokumen"</span> di atas untuk membaca atau mencetak lembar data penuh secara utuh.
            </p>
        </div>

    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Parsing Koordinat Sukabumi Kota sebagai Fail-safe
    const lat = {{ $item->koordinat_lat ? (float) $item->koordinat_lat : -6.927 }};
    const lng = {{ $item->koordinat_lng ? (float) $item->koordinat_lng : 106.930 }};
    
    // Inisialisasi Peta Leaflet Moderen
    const map = L.map('map', { scrollWheelZoom: false }).setView([lat, lng], 14);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { 
        maxZoom: 19, 
        attribution: '© OpenStreetMap' 
    }).addTo(map);

    // Perbaikan Generator Rute Google Maps Resmi (Production-Ready)
    window.openSibdiGoogleRoute = function(destinationLat, destinationLng) {
        const openRoute = function(originLat, originLng) {
            const base = 'https://www.google.com/maps/dir/?api=1';
            const destParam = '&destination=' + destinationLat + ',' + destinationLng;
            const originParam = originLat && originLng ? '&origin=' + originLat + ',' + originLng : '';
            const modeParam = '&travelmode=driving';
            
            window.open(base + originParam + destParam + modeParam, '_blank', 'noopener,noreferrer');
        };

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(pos) {
                openRoute(pos.coords.latitude, pos.coords.longitude);
            }, function() {
                openRoute(null, null); // Jalankan tanpa koordinat asal jika izin GPS ditolak
            }, { enableHighAccuracy: true, timeout: 5000 });
        } else {
            openRoute(null, null);
        }
    };

    // Binding Data Pop-up Marker Peta
    const title = @json($item->{$module['main']});
    const popupContent = `
        <div class="font-sans text-xs p-1 min-w-[200px]">
            <b class="text-primary block mb-2 text-sm">${title}</b>
            <button type="button" onclick="openSibdiGoogleRoute(${lat}, ${lng})" 
                    class="w-full inline-flex items-center justify-center gap-1 rounded-lg bg-[#001143] hover:bg-[#0f1b40] px-3 py-2 text-white font-bold text-[10px] transition-colors cursor-pointer shadow-sm">
                Buka Rute Navigasi Google Maps
            </button>
        </div>`;
        
    L.marker([lat, lng]).addTo(map).bindPopup(popupContent).openPopup();
});
</script>
@endpush