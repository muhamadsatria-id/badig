<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dokumen {{ $module['title'] }} #{{ $item->id }}</title>
    <style>
        /* Gaya Dasar yang Didukung Aman oleh Dompdf */
        body { 
            font-family: Arial, Helvetica, sans-serif; 
            color: #1e293b; 
            margin: 0; 
            padding: 0;
            font-size: 12px;
            line-height: 1.4;
        }
        
        /* Layout Pembungkus Kertas A4 */
        .page {
            padding: 10mm;
            background: #ffffff;
        }

        /* Struktur KOP Surat Menggunakan Tabel Murni */
        .kop-table {
            width: 100%;
            border-collapse: collapse;
            border-bottom: 3px solid #001143;
            margin-bottom: 20px;
        }
        .kop-table td {
            border: none !important;
            padding: 0 0 15px 0 !important;
            background: none !important;
        }
        .logo-box { 
            width: 50px; 
            height: 50px; 
            background: #001143; 
            color: #ffffff; 
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            line-height: 50px;
            border-radius: 8px;
        }
        .kop-text h1 { 
            font-size: 14px; 
            margin: 0; 
            color: #001143; 
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .kop-text .sub-header { 
            font-size: 10px; 
            color: #64748b; 
            margin-top: 3px; 
        }

        /* Badge Status */
        .badge { 
            display: inline-block; 
            padding: 4px 10px; 
            border-radius: 4px; 
            font-size: 9px; 
            font-weight: bold; 
            text-transform: uppercase;
        }
        .status-approved { background-color: #e2fbe8; color: #0f5132; border: 1px solid #badbcc; }
        .status-rejected { background-color: #f8d7da; color: #842029; border: 1px solid #f5c2c7; }
        .status-pending { background-color: #fff3cd; color: #664d03; border: 1px solid #ffecb5; }

        /* Judul Utama Dokumen */
        .main-title { 
            color: #001143; 
            margin: 0px 0 0px 0; 
            font-size: 18px; 
            font-weight: bold;
        }
        .entity-sub { 
            font-size: 11px; 
            color: #475569; 
            margin-bottom: 20px;
        }

        /* Tabel Penampung Data Utama */
        .data-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px;
        }
        .data-table td { 
            border: 1px solid #cbd5e1; 
            padding: 8px 12px; 
            vertical-align: top; 
        }
        .data-table td.label-col { 
            width: 30%; 
            background: #f8fafc; 
            font-weight: bold; 
            color: #334155; 
            font-size: 10.5px;
            text-transform: uppercase;
        }
        .data-table td.value-col {
            color: #0f172a;
        }

        /* Bagian Tanda Tangan / Footer */
        .footer-table {
            width: 100%;
            margin-top: 40px;
            border-collapse: collapse;
        }
        .footer-table td {
            border: none !important;
            padding: 10px 0 0 0 !important;
            font-size: 11px;
            color: #64748b;
        }
        .signature-title {
            font-weight: bold;
            color: #334155;
            margin-top: 35px;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="page">
    <table class="kop-table">
        <tr>
            <td style="width: 60px;">
                <div class="logo-box">★</div>
            </td>
            <td class="kop-text">
                <h1>SISTEM INFORMASI DATABASE INTELIJEN POLRES SUKABUMI KOTA</h1>
                <div class="text-uppercase sub-header">DOKUMEN REKAM DATA INTERNAL / {{ strtoupper($module['title']) }} / ID ARSIP {{ strtoupper($item->id) }}</div>
            </td>
        </tr>
    </table>

    <div>
        @php
            $status = strtolower($item->status_laporan);
            $statusClass = match($status) {
                'approved' => 'status-approved',
                'rejected' => 'status-rejected',
                default => 'status-pending'
            };
        @endphp
        <div class="main-title">{{ $item->{$module['main']} }}</div>
        <div class="entity-sub">
            Kategori: <strong>{{ $item->kategori }}</strong> &nbsp;&bull;&nbsp; 
            Wilayah: <strong>{{ $item->village?->name ?? '-' }}, {{ $item->district?->name ?? '-' }}</strong>
        </div>
    </div>

    <table class="data-table">
        @foreach($module['fields'] as $field)
            @php
                $value = match($field) {
                    'district_id' => $item->district?->name ?? '-',
                    'village_id' => $item->village?->name ?? '-',
                    'created_at' => optional($item->created_at)->format('d/m/Y H:i') ?? '-',
                    'updated_at' => optional($item->updated_at)->format('d/m/Y H:i') ?? '-',
                    default => $item->{$field} ?? '-'
                };
            @endphp
            <tr>
                <td class="label-col">{{ ucwords(str_replace('_',' ', $field)) }}</td>
                <td class="value-col">{!! nl2br(e($value)) !!}</td>
            </tr>
        @endforeach
        <tr>
            <td class="label-col">Operator Input</td>
            <td class="value-col">{{ $item->operator?->name ?? '-' }}</td>
        </tr>
        <tr>
            <td class="label-col">Waktu Cetak</td>
            <td class="value-col">{{ now()->format('d/m/Y H:i') }} WIB</td>
        </tr>
    </table>

    <table class="footer-table" style="border-top: 1px dashed #cbd5e1 !important;">
        <tr>
            <td style="width: 60%; font-style: italic; padding-right: 20px !important;">
                Catatan: Dokumen intelijen ini dihasilkan secara otomatis oleh sistem SIBDI-PSK Resmi Polres Sukabumi Kota. Segala bentuk penyalahgunaan data berkas digital ini akan ditindak sesuai hukum yang berlaku.
            </td>
            <td style="width: 40%; text-align: right;">
                Sukabumi Kota, {{ now()->format('d/m/Y') }}<br>
                Dokumen Riwayat Digital
                <div class="signature-title">DOKUMEN VALID KEPOLISIAN</div>
                <span style="font-size: 9px; color: #94a3b8;">Sistem Keamanan Hash: {{ md5($item->id) }}</span>
            </td>
        </tr>
    </table>
</div>

</body>
</html>