@extends('layouts.app')

@php
    // Pada halaman create, controller memang tidak mengirim $item.
    // Karena itu $item harus dibuat aman sebagai null dan $isEdit harus boolean.
    $item = $item ?? null;
    $isEdit = !is_null($item);
@endphp

@section('title', $isEdit ? 'Edit '.$module['title'] : 'Tambah '.$module['title'])
@section('page_title', $isEdit ? 'Edit '.$module['title'] : 'Tambah '.$module['title'])

@section('content')
@php
    $action = $isEdit ? route('units.update', [$unit, $item->id]) : route('units.store', $unit);
    $categories = [
        'unit1' => ['Aliran','Parpol','Kades','Camat'],
        'unit2' => ['Pengusaha','SPBU','LPG','Pasar'],
        'unit3' => ['Ormas','Ormawa','LSM','Tokoh'],
        'unit4' => ['Terorisme','Narkotika','Curanmor','Premanisme'],
    ][$unit] ?? [];
@endphp

<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-primary">{{ $isEdit ? 'Perbarui Berkas Rekam Data' : 'Registrasi Berkas Rekam Baru' }}</h2>
        <p class="text-xs text-secondary mt-1">Koordinat dapat diisi otomatis dari lokasi realtime, dicari berdasarkan alamat, atau dipilih langsung dengan klik pada peta.</p>
    </div>
    <div class="bg-surface-container text-on-surface-variant font-bold text-xs px-4 py-1.5 rounded-full uppercase tracking-wider border border-outline-variant/40 flex items-center gap-1.5 shadow-sm">
        <span class="material-symbols-outlined text-[16px] text-primary">edit_note</span> Modul Input {{ strtoupper($unit) }}
    </div>
</div>

<div class="bg-white rounded-2xl border border-outline-variant shadow-sm p-5 md:p-6 max-w-6xl mx-auto">
    <form method="POST" action="{{ $action }}" class="grid grid-cols-1 md:grid-cols-2 gap-5">
        @csrf
        @if($isEdit) @method('PUT') @endif

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Kategori Entitas <span class="text-error">*</span></label>
            <div class="relative group">
                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant z-10 text-[20px]">category</span>
                <select name="kategori" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 pl-10 pr-4 text-sm font-semibold text-on-surface focus:border-primary-container focus:ring-2 focus:ring-primary-container/20" required>
                    @foreach($categories as $cat)
                        <option value="{{ $cat }}" @selected(old('kategori', data_get($item, 'kategori', '')) === $cat)>{{ $cat }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        @if($unit === 'unit1')
            <x-form-input name="nama_subjek" label="Nama Subjek Organisasi / Kelompok" :value="old('nama_subjek', data_get($item, 'nama_subjek', ''))" required="true" icon="person" />
            <x-form-input name="pengikut" label="Estimasi Jumlah Pengikut" type="number" :value="old('pengikut', data_get($item, 'pengikut', ''))" icon="groups" />
            <x-form-input name="status_legal" label="Status Legalitas Kemenkumham / Instansi" :value="old('status_legal', data_get($item, 'status_legal', ''))" icon="gavel" />
            <x-form-textarea name="catatan_rawan" label="Catatan Indeks Kerawanan Kamtibmas" :value="old('catatan_rawan', data_get($item, 'catatan_rawan', ''))" />
        @elseif($unit === 'unit2')
            <x-form-input name="nama_aset" label="Nama Objek Vital / Objek Ekonomi" :value="old('nama_aset', data_get($item, 'nama_aset', ''))" required="true" icon="factory" />
            <x-form-input name="alamat" label="Alamat Operasional Lengkap" :value="old('alamat', data_get($item, 'alamat', ''))" required="true" icon="location_on" />
            <x-form-input name="kapasitas" label="Kapasitas / Volume Komoditas Logistik" :value="old('kapasitas', data_get($item, 'kapasitas', ''))" icon="database" />
        @elseif($unit === 'unit3')
            <x-form-input name="nama_organisasi" label="Nama Resmi Ormas / LSM / Lembaga" :value="old('nama_organisasi', data_get($item, 'nama_organisasi', ''))" required="true" icon="corporate_fare" />
            <x-form-input name="pimpinan" label="Nama Penanggung Jawab / Pimpinan Utama" :value="old('pimpinan', data_get($item, 'pimpinan', ''))" icon="person_celebration" />
            <x-form-input name="total_anggota" label="Total Anggota Terdaftar" type="number" :value="old('total_anggota', data_get($item, 'total_anggota', ''))" icon="groups" />
            <x-form-input name="legalitas" label="Nomor SK Akta / Surat Izin Operasional" :value="old('legalitas', data_get($item, 'legalitas', ''))" icon="description" />
            <x-form-textarea name="catatan_aktivitas" label="Catatan Monitoring Rekam Jejak Aktivitas" :value="old('catatan_aktivitas', data_get($item, 'catatan_aktivitas', ''))" />
        @elseif($unit === 'unit4')
            <x-form-input name="nama_kasus" label="Nama Lengkap Tersangka / Judul Kasus" :value="old('nama_kasus', data_get($item, 'nama_kasus', ''))" required="true" icon="gpp_bad" />
            <x-form-textarea name="modus" label="Modus Operandi Tindakan Kriminalitas" :value="old('modus', data_get($item, 'modus', ''))" />
            <x-form-input name="status_kasus" label="Status Penanganan Kasus (Lidik / Sidik / P21)" :value="old('status_kasus', data_get($item, 'status_kasus', ''))" required="true" icon="quick_reference_all" />
            <x-form-textarea name="data_enkripsi" label="Data Sensitif Tambahan (Terenkripsi Internal)" :value="old('data_enkripsi', data_get($item, 'data_enkripsi', ''))" />
        @endif

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Kecamatan <span class="text-error">*</span></label>
            <select name="district_id" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-medium" required>
                @foreach($districts as $district)
                    <option value="{{ $district->id }}" @selected(old('district_id', data_get($item, 'district_id', '')) == $district->id)>{{ $district->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Kelurahan / Desa <span class="text-error">*</span></label>
            <select name="village_id" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-medium" required>
                @foreach($villages as $village)
                    <option value="{{ $village->id }}" @selected(old('village_id', data_get($item, 'village_id', '')) == $village->id)>{{ $village->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="md:col-span-2 bg-surface-container-low rounded-2xl border border-outline-variant p-4">
            <div class="flex flex-col lg:flex-row lg:items-end gap-3 mb-4">
                <div class="flex-1">
                    <label class="block text-xs font-bold text-secondary uppercase tracking-wider mb-1">Cari Alamat / Lokasi</label>
                    <input id="mapSearchInput" type="text" placeholder="Contoh: Polres Sukabumi Kota, Cikole, Sukabumi" class="w-full rounded-xl border-outline-variant bg-white text-sm">
                </div>
                <button type="button" id="mapSearchBtn" class="bg-primary text-on-primary px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center gap-1"><span class="material-symbols-outlined text-[16px]">search</span>Cari</button>
                <button type="button" id="useMyLocationBtn" class="bg-secondary-container text-on-secondary-container px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center gap-1"><span class="material-symbols-outlined text-[16px]">my_location</span>Lokasi Saya</button>
            </div>
            <div id="coordinateMap" class="h-[360px] rounded-xl border border-outline-variant shadow-inner z-10"></div>
            <p id="mapHelpText" class="text-xs text-secondary mt-2">Klik pada peta untuk memilih titik. Jika browser meminta izin lokasi, pilih Allow agar latitude dan longitude otomatis terisi.</p>
        </div>

        <x-form-input name="koordinat_lat" label="Koordinat Garis Lintang (Latitude)" :value="old('koordinat_lat', data_get($item, 'koordinat_lat', ''))" icon="explore" placeholder="Contoh: -6.92712" />
        <x-form-input name="koordinat_lng" label="Koordinat Garis Bujur (Longitude)" :value="old('koordinat_lng', data_get($item, 'koordinat_lng', ''))" icon="explore" placeholder="Contoh: 106.93041" />

        <div class="space-y-1.5">
            <label class="block text-xs font-bold text-on-surface-variant tracking-wide">Status Alur Laporan <span class="text-error">*</span></label>
            <select name="status_laporan" class="w-full bg-surface-container-lowest border border-outline-variant rounded-xl py-3 px-4 text-sm font-semibold" required>
                @foreach(['draft'=>'Draft (Arsip Internal)','submitted'=>'Diajukan (Validasi Kasat)','approved'=>'Disetujui (Rilis Pimpinan)','rejected'=>'Ditolak (Butuh Revisi)'] as $k=>$v)
                    <option value="{{ $k }}" @selected(old('status_laporan', data_get($item, 'status_laporan', 'draft')) === $k)>{{ $v }}</option>
                @endforeach
            </select>
        </div>

        <div class="md:col-span-2 flex items-center gap-3 pt-4 border-t border-outline-variant/30 mt-2">
            <button type="submit" class="bg-primary-container hover:bg-primary text-on-primary font-bold text-xs px-6 py-3.5 rounded-xl transition-all shadow-md flex items-center gap-2"><span class="material-symbols-outlined text-[18px]">save</span>Simpan Dokumen Intelijen</button>
            <a href="{{ route('units.index', $unit) }}" class="bg-surface-container hover:bg-surface-container-high text-primary border border-outline-variant/60 px-6 py-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1"><span class="material-symbols-outlined text-[18px]">arrow_back</span>Batal / Kembali</a>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', () => {
    const latInput = document.getElementById('koordinat_lat') || document.querySelector('[name="koordinat_lat"]');
    const lngInput = document.getElementById('koordinat_lng') || document.querySelector('[name="koordinat_lng"]');
    const helpText = document.getElementById('mapHelpText');

    if (!window.L || !latInput || !lngInput || !document.getElementById('coordinateMap')) {
        if (helpText) helpText.textContent = 'Peta belum dapat dimuat. Pastikan koneksi internet aktif untuk Leaflet.js.';
        return;
    }

    const defaultLat = parseFloat(latInput.value) || -6.927;
    const defaultLng = parseFloat(lngInput.value) || 106.930;
    const map = L.map('coordinateMap').setView([defaultLat, defaultLng], 13);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom:19, attribution:'&copy; OpenStreetMap contributors' }).addTo(map);
    let marker = L.marker([defaultLat, defaultLng], { draggable:true }).addTo(map);

    function setPoint(lat, lng, zoom = 16){
        lat = Number(lat); lng = Number(lng);
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
        latInput.value = lat.toFixed(8);
        lngInput.value = lng.toFixed(8);
        marker.setLatLng([lat, lng]);
        map.setView([lat, lng], zoom);
    }

    marker.on('dragend', e => { const p = e.target.getLatLng(); setPoint(p.lat, p.lng, map.getZoom()); });
    map.on('click', e => setPoint(e.latlng.lat, e.latlng.lng, map.getZoom()));

    function useBrowserLocation(){
        if(!navigator.geolocation){ helpText.textContent = 'Browser tidak mendukung geolocation.'; return; }
        helpText.textContent = 'Membaca lokasi realtime perangkat...';
        navigator.geolocation.getCurrentPosition(pos => {
            setPoint(pos.coords.latitude, pos.coords.longitude, 17);
            helpText.textContent = 'Lokasi realtime berhasil digunakan. Titik tetap dapat disesuaikan dengan klik/drag marker.';
        }, () => { helpText.textContent = 'Izin lokasi ditolak/tidak tersedia. Gunakan search alamat atau klik peta.'; }, { enableHighAccuracy:true, timeout:10000 });
    }

    if(!latInput.value || !lngInput.value){ useBrowserLocation(); }
    document.getElementById('useMyLocationBtn')?.addEventListener('click', useBrowserLocation);
    document.getElementById('mapSearchBtn')?.addEventListener('click', async () => {
        const q = document.getElementById('mapSearchInput').value.trim();
        if(!q){ helpText.textContent = 'Isi alamat/lokasi terlebih dahulu.'; return; }
        helpText.textContent = 'Mencari lokasi...';
        try{
            const res = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(q));
            const data = await res.json();
            if(data && data[0]){ setPoint(data[0].lat, data[0].lon, 16); helpText.textContent = data[0].display_name; }
            else { helpText.textContent = 'Alamat tidak ditemukan. Coba kata kunci yang lebih spesifik.'; }
        }catch(e){ helpText.textContent = 'Search alamat gagal. Pastikan internet aktif atau pilih titik secara manual di peta.'; }
    });
});
</script>
@endpush
