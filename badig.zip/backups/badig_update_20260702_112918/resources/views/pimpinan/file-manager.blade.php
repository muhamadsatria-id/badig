@extends('layouts.app')

@section('title', 'File Manager Pimpinan')
@section('page_title', 'File Manager Pimpinan')

@section('content')
<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-primary">File Manager Lintasan Data</h2>
        <p class="text-xs text-secondary mt-1">Hak Akses Khusus Pimpinan. Menampilkan repositori seluruh berkas operasional terintegrasi dari Unit 1 s.d. Unit 4.</p>
    </div>
    
    <div class="relative" id="exportMenuWrap">
        <button type="button" onclick="document.getElementById('exportMenu').classList.toggle('hidden')" 
                class="bg-primary-container hover:bg-[#0f1b40] text-on-primary px-5 py-3.5 rounded-xl text-xs font-bold inline-flex items-center gap-2 shadow-md transition-colors active:scale-[0.98]">
            <span class="material-symbols-outlined text-[18px]">ios_share</span> 
            <span>Ekspor Laporan</span> 
            <span class="material-symbols-outlined text-[18px]">expand_more</span>
        </button>
        <div id="exportMenu" class="hidden absolute right-0 mt-2 w-44 bg-white border border-outline-variant rounded-xl shadow-2xl p-1.5 z-30 animate-fade-in">
            <a class="flex items-center gap-2.5 px-3 py-2.5 rounded-lg hover:bg-surface-container text-xs font-bold text-primary transition-colors" 
               href="{{ route('pimpinan.file-manager.export', array_merge(request()->query(), ['type' => 'pdf'])) }}">
                <span class="material-symbols-outlined text-[18px] text-error">picture_as_pdf</span>Dokumen PDF (.pdf)
            </a>
            <a class="flex items-center gap-2.5 px-3 py-2.5 rounded-lg hover:bg-surface-container text-xs font-bold text-primary transition-colors" 
               href="{{ route('pimpinan.file-manager.export', array_merge(request()->query(), ['type' => 'excel'])) }}">
                <span class="material-symbols-outlined text-[18px] text-emerald-600">table_view</span>Lembar Kerja Excel (.xlsx)
            </a>
        </div>
    </div>
</div>

<form method="GET" action="{{ route('pimpinan.file-manager') }}" class="bg-white rounded-2xl border border-outline-variant shadow-sm p-5 mb-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-4 items-end">
    
<div class="md:col-span-1 space-y-1.5">
    <label class="text-xs font-bold text-on-surface-variant tracking-wide">Kata Kunci Pencarian</label>
    <div class="relative group">
        <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant z-10 text-[18px] group-focus-within:text-primary transition-colors">search</span>
        <input type="text" name="q" value="{{ $filters['q'] }}" 
               placeholder="Cari nama, kategori..." 
               class="w-full rounded-xl border-outline-variant bg-surface-container-lowest py-2.5 pl-9 pr-4 text-xs font-medium text-on-surface transition-all duration-200 focus:border-primary focus:ring-2 focus:ring-primary/20">
    </div>
</div>

    
    <div class="space-y-1.5">
        <label class="text-xs font-bold text-on-surface-variant tracking-wide">Pilah Unit</label>
        <div class="relative group">
            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant z-10 text-[18px]">grid_view</span>
            <select name="unit" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest py-2.5 pl-9 pr-4 text-xs font-semibold text-on-surface focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all">
                @foreach(['all'=>'Semua Unit','unit1'=>'Unit 1 (Ideologi)','unit2'=>'Unit 2 (Ekonomi)','unit3'=>'Unit 3 (Sosbud)','unit4'=>'Unit 4 (Keamanan)'] as $k=>$v)
                    <option value="{{ $k }}" @selected($filters['unit']===$k)>{{ $v }}</option>
                @endforeach
            </select>
        </div>
    </div>
    
    <div class="space-y-1.5">
        <label class="text-xs font-bold text-on-surface-variant tracking-wide">Status Audit</label>
        <div class="relative group">
            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant z-10 text-[18px]">verified_user</span>
            <select name="status" class="w-full rounded-xl border-outline-variant bg-surface-container-lowest py-2.5 pl-9 pr-4 text-xs font-semibold text-on-surface focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all">
                @foreach(['all'=>'Semua Status','draft'=>'Draft','submitted'=>'Submitted','approved'=>'Approved','rejected'=>'Rejected'] as $k=>$v)
                    <option value="{{ $k }}" @selected($filters['status']===$k)>{{ $v }}</option>
                @endforeach
            </select>
        </div>
    </div>
    
<div class="space-y-1.5">
        <label class="text-xs font-bold text-on-surface-variant tracking-wide">Rentang Dari</label>
        <input type="date" name="date_from" value="{{ $filters['date_from'] }}" 
               class="w-full rounded-xl border-outline-variant bg-surface-container-lowest py-2 text-xs font-medium text-on-surface focus:border-primary focus:ring-2 focus:ring-primary/20">
    </div>
    
    <div class="space-y-1.5">
        <label class="text-xs font-bold text-on-surface-variant tracking-wide">Sampai</label>
        <div class="flex gap-2">
            <input type="date" name="date_to" value="{{ $filters['date_to'] }}" 
                   class="w-full rounded-xl border-outline-variant bg-surface-container-lowest py-2 text-xs font-medium text-on-surface focus:border-primary focus:ring-2 focus:ring-primary/20 flex-1">
            <button type="submit" class="bg-primary text-on-primary px-4 rounded-xl font-bold text-xs hover:bg-[#0f1b40] transition-colors flex items-center justify-center gap-1">
                <span class="material-symbols-outlined text-[16px]">tune</span> Filter
            </button>
        </div>
    </div>
</form>

<div class="bg-white rounded-2xl border border-outline-variant shadow-sm overflow-hidden">
    <div class="px-5 py-4 border-b border-outline-variant flex items-center justify-between">
        <div class="flex items-center gap-2">
            <span class="material-symbols-outlined text-primary">inventory</span>
            <h3 class="font-bold text-primary text-sm md:text-base">Daftar Rekapitulasi Terintegrasi</h3>
        </div>
        <span class="text-xs bg-secondary-container text-on-secondary-container px-3 py-1 rounded-full font-bold">
            {{ $rows->count() }} Data Arsip
        </span>
    </div>
    
    <div class="overflow-x-auto custom-scrollbar">
        <table class="min-w-full text-sm divide-y divide-outline-variant">
            <thead class="bg-surface-container text-on-surface-variant font-semibold">
                <tr>
                    <th class="p-3.5 text-left text-xs uppercase tracking-wider w-24">Unit Kerja</th>
                    <th class="p-3.5 text-left text-xs uppercase tracking-wider">Nama / Entitas Subjek</th>
                    <th class="p-3.5 text-left text-xs uppercase tracking-wider">Kategori</th>
                    <th class="p-3.5 text-left text-xs uppercase tracking-wider">Wilayah Sektor</th>
                    <th class="p-3.5 text-left text-xs uppercase tracking-wider">Operator Input</th>
                    <th class="p-3.5 text-center text-xs uppercase tracking-wider">Status Laporan</th>
                    <th class="p-3.5 text-right text-xs uppercase tracking-wider w-64">Tindakan Dokumen</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-outline-variant bg-white text-on-surface">
                @forelse($rows as $row)
                    @php
                        $statusUpper = strtoupper($row['status']);
                        $isApproved = $statusUpper === 'APPROVED';
                        $isRejected = $statusUpper === 'REJECTED';
                    @endphp
                    <tr class="hover:bg-surface-container-low transition-colors">
                        
                        <td class="p-3.5 font-bold text-primary whitespace-nowrap">
                            <div class="flex flex-col">
                                <span class="text-xs">{{ $row['unit_title'] }}</span>
                                <span class="text-[10px] text-outline font-mono font-bold leading-none mt-0.5">#{{ $row['id'] }}</span>
                            </div>
                        </td>
                        
                        <td class="p-3.5 font-bold text-on-surface">
                            {{ $row['nama'] }}
                        </td>
                        
                        <td class="p-3.5 whitespace-nowrap">
                            <span class="bg-primary-container/10 text-primary px-2.5 py-0.5 rounded-md text-xs font-semibold border border-primary-container/10">
                                {{ $row['kategori'] }}
                            </span>
                        </td>
                        
                        <td class="p-3.5 text-xs text-on-surface-variant opacity-90 font-medium">
                            <div class="flex items-center gap-1">
                                <span class="material-symbols-outlined text-[14px] text-outline">location_on</span>
                                <span>{{ $row['village'] }}, {{ $row['district'] }}</span>
                            </div>
                        </td>
                        
                        <td class="p-3.5 text-xs text-secondary font-medium whitespace-nowrap">
                            {{ $row['operator'] }}
                        </td>
                        
                        <td class="p-3.5 text-center whitespace-nowrap">
                            @if($isApproved)
                                <span class="bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2.5 py-0.5 rounded-md font-bold text-[10px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> APPROVED
                                </span>
                            @elseif($isRejected)
                                <span class="bg-error-container/40 text-on-error-container border border-error/20 px-2.5 py-0.5 rounded-md font-bold text-[10px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-error animate-pulse"></span> REJECTED
                                </span>
                            @else
                                <span class="bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-md font-bold text-[10px] inline-flex items-center gap-1 uppercase tracking-wide">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span> {{ $statusUpper }}
                                </span>
                            @endif
                        </td>
                        
                        <td class="p-3.5 text-right whitespace-nowrap text-xs font-bold">
                            <div class="inline-flex items-center gap-1">
                                <a href="{{ route('units.show', [$row['unit'], $row['id']]) }}" 
                                   class="text-primary hover:bg-surface-container px-2 py-1.5 rounded transition-colors inline-flex items-center gap-0.5">
                                    <span class="material-symbols-outlined text-[16px]">visibility</span>
                                    <span>Detail</span>
                                </a>
                                
                                <a href="{{ route('units.document', [$row['unit'], $row['id']]) }}" target="_blank" 
                                   class="text-primary hover:bg-surface-container px-2 py-1.5 rounded transition-colors inline-flex items-center gap-0.5">
                                    <span class="material-symbols-outlined text-[16px]">article</span>
                                    <span>Preview</span>
                                </a>
                                
                                <a href="{{ route('units.pdf', [$row['unit'], $row['id']]) }}" target="_blank" 
                                   class="text-error hover:bg-error-container/20 px-2 py-1.5 rounded transition-colors inline-flex items-center gap-0.5">
                                    <span class="material-symbols-outlined text-[16px]">picture_as_pdf</span>
                                    <span>PDF</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="p-10 text-center text-outline bg-surface-container-low/50">
                            <div class="w-12 h-12 bg-white rounded-full border border-outline-variant/60 flex items-center justify-center mx-auto mb-3 shadow-xs text-outline">
                                <span class="material-symbols-outlined text-2xl">folder_zip</span>
                            </div>
                            <h4 class="text-sm font-bold text-primary mb-0.5">Berkas Tidak Ditemukan</h4>
                            <p class="text-xs text-on-surface-variant opacity-80">Tidak ada arsip lintasan unit intelijen yang cocok dengan kriteria filter pencarian Anda.</p>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<script>
    // Penutupan menu dropdown eksport secara otomatis jika pengguna mengeklik di luar area pembungkus
    document.addEventListener('click', function(e){ 
        const wrap = document.getElementById('exportMenuWrap'); 
        const menu = document.getElementById('exportMenu'); 
        if(wrap && menu && !wrap.contains(e.target)) {
            menu.classList.add('hidden'); 
        }
    });
</script>
@endsection