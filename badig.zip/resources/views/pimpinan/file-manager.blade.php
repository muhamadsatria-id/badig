@extends('layouts.app')

@section('title', 'File Manager Semua Unit')
@section('page_title', 'File Manager Semua Unit')

@section('content')
<div class="space-y-6">
    <div class="rounded-2xl border border-line bg-gradient-to-br from-surface-raised to-surface p-5 shadow-sm sm:p-6 badig-card">
        <div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div class="space-y-1">
                <x-ui.badge color="success" dot>Repositori Global</x-ui.badge>
                <h2 class="text-xl font-semibold tracking-tight text-ink">File Manager Semua Unit</h2>
                <p class="max-w-2xl text-sm leading-6 text-muted">
                    Repositori global untuk memantau lampiran berkas lintas unit operasional dengan akses yang lebih terarah.
                </p>
            </div>

            <a href="{{ route('pimpinan.file-manager.export', array_merge(request()->query(), ['type' => 'pdf'])) }}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 rounded-lg border border-danger/20 bg-[var(--danger-soft)] px-4 py-2.5 text-sm font-semibold text-danger transition hover:bg-[var(--danger-soft)] badig-action badig-action-danger">
                <span class="material-symbols-outlined text-base">picture_as_pdf</span>
                Ekspor Laporan PDF
            </a>
        </div>
    </div>

    <form method="GET" action="{{ route('pimpinan.file-manager') }}" class="grid grid-cols-1 gap-3 rounded-2xl border border-line bg-surface p-4 shadow-sm sm:grid-cols-2 md:grid-cols-6 md:items-end badig-card">
        <div class="space-y-2 md:col-span-2">
            <label for="q" class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Cari Berkas</label>
            <input id="q" type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Nama file, ekstensi, ID arsip..." class="h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition placeholder:text-faint focus:border-accent focus:bg-surface badig-field">
        </div>

        <div class="space-y-2">
            <label for="unit" class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Unit Kerja</label>
            <select id="unit" name="unit" class="h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
                <option value="all">Semua Unit</option>
                @foreach($units as $key => $label)
                    <option value="{{ $key }}" @selected(($filters['unit'] ?? '') === $key)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div class="space-y-2">
            <label for="date_from" class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Dari Tanggal</label>
            <input id="date_from" type="date" name="date_from" value="{{ $filters['date_from'] ?? '' }}" class="h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
        </div>

        <div class="space-y-2">
            <label for="date_to" class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Sampai</label>
            <div class="flex gap-2">
                <input id="date_to" type="date" name="date_to" value="{{ $filters['date_to'] ?? '' }}" class="h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
                <x-ui.button type="submit" variant="primary" class="h-11 px-4 text-xs"><flux:icon name="funnel" class="size-4" />Terapkan</x-ui.button>
                <!-- <button type="submit" class="inline-flex h-11 items-center justify-center rounded-lg bg-accent px-4 text-sm font-semibold text-[#07140c] transition hover:bg-accent-strong badig-action badig-action-primary">
                    Filter
                </button> -->
            </div>
        </div>
    </form>

    <form id="bulkExportForm" method="GET" action="{{ route('pimpinan.file-manager.export', 'pdf') }}" target="_blank" rel="noopener noreferrer">
    </form>

    <div class="overflow-hidden rounded-2xl border border-line bg-surface shadow-sm badig-card">
        <div class="flex flex-col gap-2 border-b border-line bg-surface-raised p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h3 class="text-sm font-semibold text-ink">Repositori Berkas Semua Unit</h3>
                <p class="text-sm text-muted">Gunakan checkbox untuk memilih beberapa berkas sekaligus lalu cetak gabungan.</p>
            </div>
            <button form="bulkExportForm" type="submit" class="inline-flex items-center justify-center gap-2 rounded-lg border border-danger/20 bg-[var(--danger-soft)] px-3 py-2 text-sm font-semibold text-danger transition hover:bg-[var(--danger-soft)] badig-action badig-action-danger">
                <span class="material-symbols-outlined text-base">picture_as_pdf</span>
                Cetak Pilihan
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-line text-sm">
                <thead class="bg-surface-raised">
                    <tr>
                        <th class="w-10 px-3 py-3 text-center">
                            <input type="checkbox" id="selectAllRows" class="rounded border-line text-ink focus:ring-accent/20">
                        </th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Identitas Berkas / Dokumen</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Asal Unit</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">ID Arsip</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Personel Uploader</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Waktu Unggah</th>
                        <th class="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line bg-surface text-muted">
                    @forelse($attachments as $attachment)
                        <tr class="transition hover:bg-surface-raised">
                            <td class="px-3 py-3 text-center">
                                <input class="rowCheckbox rounded border-line text-ink focus:ring-accent/20" type="checkbox" name="q" value="{{ $attachment->original_name }}" form="bulkExportForm">
                            </td>
                            <td class="px-4 py-3">
                                <div class="break-all font-semibold text-ink">{{ $attachment->original_name }}</div>
                                <div class="mt-1 text-[11px] uppercase tracking-[0.2em] text-faint">
                                    {{ $attachment->extension }} &bull; {{ $attachment->human_file_size }}
                                </div>
                            </td>
                            <td class="px-4 py-3">
                                <span class="rounded-full border border-line bg-surface-raised px-2.5 py-1 text-[11px] font-semibold text-muted badig-badge">
                                    {{ $units[$attachment->unit] ?? strtoupper($attachment->unit) }}
                                </span>
                            </td>
                            <td class="px-4 py-3 font-mono text-[12px] text-muted">#{{ $attachment->record_id }}</td>
                            <td class="px-4 py-3 font-medium text-muted">{{ $attachment->uploader?->name ?? '-' }}</td>
                            <td class="px-4 py-3 text-muted">{{ $attachment->created_at?->format('d/m/Y H:i') }}</td>
                            <td class="px-4 py-3 text-right">
                                <div x-data="{
                                    open: false,
                                    top: 0,
                                    left: 0,
                                    menuWidth: 160,

                                    toggle() {
                                        this.open = !this.open;
                                        if (this.open) {
                                            this.$nextTick(() => this.updatePosition());
                                        }
                                    },

                                    close() {
                                        this.open = false;
                                    },

                                    updatePosition() {
                                        const trigger = this.$refs.trigger;
                                        const menu = this.$refs.menu;
                                        if (!trigger) return;
                                        const rect = trigger.getBoundingClientRect();
                                        const gap = 8;
                                        const viewportPadding = 12;
                                        const menuHeight = menu?.offsetHeight || 160;

                                        let calculatedTop = rect.bottom + gap;
                                        if (calculatedTop + menuHeight > window.innerHeight - viewportPadding) {
                                            calculatedTop = rect.top - menuHeight - gap;
                                        }

                                        let calculatedLeft = rect.right - this.menuWidth;
                                        calculatedLeft = Math.max(viewportPadding, Math.min(calculatedLeft, window.innerWidth - this.menuWidth - viewportPadding));

                                        this.top = calculatedTop;
                                        this.left = calculatedLeft;
                                    }
                                }" class="inline-flex" @keydown.escape.window="close()" @resize.window="open && updatePosition()" @scroll.window="open && updatePosition()">
                                    <button x-ref="trigger" type="button" @click.stop="toggle()" class="badig-focus inline-flex h-9 items-center gap-2 rounded-lg border border-line bg-surface px-3 text-xs font-semibold text-ink shadow-sm transition hover:bg-surface-raised" :aria-expanded="open" aria-haspopup="menu">
                                        <flux:icon name="ellipsis-vertical" class="size-4 text-muted" />
                                        <span>Aksi</span>
                                        <span class="transition-transform duration-200" :class="{ 'rotate-180': open }">
                                            <flux:icon name="chevron-down" class="size-3.5 text-muted" />
                                        </span>
                                    </button>

                                    <template x-teleport="body">
                                        <div x-cloak x-show="open" x-ref="menu" role="menu" @click.outside="close()" @click.stop
                                            x-transition:enter="transition duration-150 ease-out"
                                            x-transition:enter-start="translate-y-1 scale-95 opacity-0"
                                            x-transition:enter-end="translate-y-0 scale-100 opacity-100"
                                            x-transition:leave="transition duration-100 ease-in"
                                            x-transition:leave-start="translate-y-0 scale-100 opacity-100"
                                            x-transition:leave-end="translate-y-1 scale-95 opacity-0"
                                            :style="`top: ${top}px; left: ${left}px; width: ${menuWidth}px;`"
                                            class="fixed z-[9999] origin-top-right rounded-xl border border-line bg-surface p-1.5 text-left shadow-2xl space-y-0.5">

                                            @if(in_array($attachment->unit, ['unit1','unit2','unit3','unit4'], true))
                                                <a href="{{ route('units.show', [$attachment->unit, $attachment->record_id]) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="eye" class="size-4 shrink-0 text-muted" />
                                                    <span>Lihat</span>
                                                </a>
                                            @else
                                                <a href="{{ route('database-orang.show', $attachment->record_id) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="eye" class="size-4 shrink-0 text-muted" />
                                                    <span>Lihat</span>
                                                </a>
                                            @endif

                                            <a href="{{ route('pimpinan.file-manager.attachments.download', $attachment->id) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                <flux:icon name="document-arrow-down" class="size-4 shrink-0 text-accent" />
                                                <span>Unduh</span>
                                            </a>

                                            <div class="my-1 border-t border-line"></div>

                                            @if(in_array($attachment->unit, ['unit1','unit2','unit3','unit4'], true))
                                                <a href="{{ route('units.edit', [$attachment->unit, $attachment->record_id]) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="pencil-square" class="size-4 shrink-0 text-warning" />
                                                    <span>Edit</span>
                                                </a>
                                            @else
                                                <a href="{{ route('database-orang.edit', $attachment->record_id) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="pencil-square" class="size-4 shrink-0 text-warning" />
                                                    <span>Edit</span>
                                                </a>
                                            @endif

                                            <form action="{{ route('pimpinan.file-manager.attachments.delete', $attachment->id) }}" method="POST" class="w-full" data-confirm="Apakah Anda yakin ingin menghapus file ini?">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-red-500 transition hover:bg-red-500/10">
                                                    <flux:icon name="trash" class="size-4 shrink-0 text-red-500" />
                                                    <span>Hapus</span>
                                                </button>
                                            </form>
                                        </div>
                                    </template>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-4 py-10 text-center text-sm text-muted">
                                Tidak ditemukan riwayat berkas lampiran digital pada parameter repositori global sistem.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="border-t border-line bg-surface-raised p-4">
            {{ $attachments->links() }}
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script @cspNonce>
document.addEventListener('DOMContentLoaded', () => {
    const all = document.getElementById('selectAllRows');
    const rows = document.querySelectorAll('.rowCheckbox');

    all?.addEventListener('change', () => rows.forEach((checkbox) => {
        checkbox.checked = all.checked;
    }));
});
</script>
@endpush