@extends('layouts.app')

@section('title', 'File Manager ' . $module['title'])
@section('page_title', 'File Manager ' . $module['title'])

@section('content')
<div class="w-full min-w-0">
    <div class="rounded-2xl border border-line bg-gradient-to-br from-surface-raised to-surface p-5 shadow-sm sm:p-6 badig-card">
        <div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div class="space-y-2">
                <div class="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                    <span class="material-symbols-outlined text-base text-muted">folder_open</span>
                    Direktori lampiran
                </div>
                <div>
                    <h2 class="text-xl font-semibold tracking-tight text-ink">
                        File Manager Berkas: {{ $module['title'] }}
                    </h2>
                    <p class="mt-1 max-w-2xl text-sm leading-6 text-muted">
                        Repositori sentral lampiran berkas fisik yang melekat pada rekam data indeks unit ini.
                    </p>
                </div>
            </div>

            <a href="{{ route('units.index', $unit) }}" class="inline-flex items-center justify-center gap-2 rounded-lg border border-line bg-surface px-4 py-2 text-sm font-semibold text-muted shadow-sm transition hover:bg-surface-raised badig-action badig-action-secondary">
                <span class="material-symbols-outlined text-base text-faint">arrow_back</span>
                Kembali
            </a>
        </div>
    </div>

    <div class="mt-6 rounded-2xl border border-line bg-surface p-5 shadow-sm sm:p-6 badig-card">
        <form method="GET" action="{{ route('units.file-manager', $unit) }}" class="min-w-0 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5 lg:items-end">
            <div class="lg:col-span-2">
                <label class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                    Cari Nama Berkas
                </label>
                <input type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Nama berkas atau ID arsip..." class="mt-1 h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
            </div>

            <!-- <div>
                <label class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                    Format Ekstensi
                </label>
                <input type="text" name="type" value="{{ $filters['type'] ?? '' }}" placeholder="Contoh: pdf, jpg, zip" class="mt-1 h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
            </div> -->

            <div>
                <label class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                    Dari Tanggal
                </label>
                <input type="date" name="date_from" value="{{ $filters['date_from'] ?? '' }}" class="mt-1 h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
            </div>

            <div>
                <label class="block text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                    Sampai
                </label>
                <div class="mt-1 flex gap-2">
                    <input type="date" name="date_to" value="{{ $filters['date_to'] ?? '' }}" class="h-11 w-full rounded-xl border border-line bg-surface-raised px-3 text-sm text-muted outline-none transition focus:border-accent focus:bg-surface badig-field">
                    <x-ui.button type="submit" variant="primary" class="h-11 px-4 text-xs"><flux:icon name="funnel" class="size-4" />Terapkan</x-ui.button>
                    <!-- <button type="submit" class="inline-flex h-11 items-center justify-center rounded-lg bg-accent px-4 text-sm font-semibold text-[#07140c] transition hover:bg-accent-strong badig-action badig-action-primary">
                        Filter
                    </button> -->
                </div>
            </div>
        </form>

        <form id="bulkExportForm" method="POST" action="{{ route('units.export-selected-pdf', $unit) }}" target="_blank" rel="noopener noreferrer">
            @csrf
        </form>

        <div class="mt-6 overflow-hidden rounded-2xl border border-line">
            <div class="flex flex-col gap-2 border-b border-line bg-surface-raised p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 class="text-sm font-semibold text-ink">Direktori Berkas Unit</h3>
                    <p class="text-sm text-muted">Gunakan checkbox untuk memilih beberapa berkas sekaligus lalu cetak gabungan.</p>
                </div>
                <button form="bulkExportForm" type="submit" class="inline-flex items-center justify-center gap-2 rounded-lg border border-danger/20 bg-[var(--danger-soft)] px-3 py-2 text-sm font-semibold text-danger transition hover:bg-[var(--danger-soft)] badig-action badig-action-danger">
                    <span class="material-symbols-outlined text-base">picture_as_pdf</span>
                    Cetak Pilihan
                </button>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-line">
                    <thead class="bg-surface-raised">
                        <tr>
                            <th class="w-10 px-3 py-3 text-center">
                                <input type="checkbox" id="selectAllRows" class="rounded border-line text-ink focus:ring-accent/20">
                            </th>
                            <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                                Identitas Berkas
                            </th>
                            <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                                ID Arsip
                            </th>
                            <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                                Pengunggah
                            </th>
                            <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                                Waktu Unggah
                            </th>
                            <th class="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                                Aksi
                            </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-line bg-surface">
                        @forelse($attachments as $attachment)
                            <tr class="transition hover:bg-surface-raised">
                                <td class="px-3 py-3 text-center">
                                    <input class="rowCheckbox rounded border-line text-ink focus:ring-accent/20" type="checkbox" name="ids[]" value="{{ $attachment->record_id }}" form="bulkExportForm">
                                </td>
                                <td class="px-4 py-3">
                                    <div class="font-semibold text-ink">{{ $attachment->original_name }}</div>
                                    <div class="mt-1 text-[10px] uppercase tracking-[0.24em] text-faint">
                                        {{ $attachment->extension }} • {{ $attachment->human_file_size }}
                                    </div>
                                </td>
                                <td class="px-4 py-3 font-mono text-sm text-muted">#{{ $attachment->record_id }}</td>
                                <td class="px-4 py-3 text-sm font-medium text-muted">{{ $attachment->uploader?->name ?? '-' }}</td>
                                <td class="px-4 py-3 text-sm text-muted">{{ $attachment->created_at?->format('d/m/Y H:i') }}</td>
                                <td class="px-4 py-3 text-right">
                                    <div x-data="{
                                        open: false,
                                        top: 0,
                                        left: 0,
                                        menuWidth: 160,

                                        toggle() {
                                            this.open = !this.open;
                                            if (this.open) {
                                                this.$nextTick(() => this.updatePosition());
                                            }
                                        },

                                        close() {
                                            this.open = false;
                                        },

                                        updatePosition() {
                                            const trigger = this.$refs.trigger;
                                            const menu = this.$refs.menu;
                                            if (!trigger) return;
                                            const rect = trigger.getBoundingClientRect();
                                            const gap = 8;
                                            const viewportPadding = 12;
                                            const menuHeight = menu?.offsetHeight || 160;

                                            let calculatedTop = rect.bottom + gap;
                                            if (calculatedTop + menuHeight > window.innerHeight - viewportPadding) {
                                                calculatedTop = rect.top - menuHeight - gap;
                                            }

                                            let calculatedLeft = rect.right - this.menuWidth;
                                            calculatedLeft = Math.max(viewportPadding, Math.min(calculatedLeft, window.innerWidth - this.menuWidth - viewportPadding));

                                            this.top = calculatedTop;
                                            this.left = calculatedLeft;
                                        }
                                    }" class="inline-flex" @keydown.escape.window="close()" @resize.window="open && updatePosition()" @scroll.window="open && updatePosition()">
                                        <button x-ref="trigger" type="button" @click.stop="toggle()" class="badig-focus inline-flex h-9 items-center gap-2 rounded-lg border border-line bg-surface px-3 text-xs font-semibold text-ink shadow-sm transition hover:bg-surface-raised" :aria-expanded="open" aria-haspopup="menu">
                                            <flux:icon name="ellipsis-vertical" class="size-4 text-muted" />
                                            <span>Aksi</span>
                                            <span class="transition-transform duration-200" :class="{ 'rotate-180': open }">
                                                <flux:icon name="chevron-down" class="size-3.5 text-muted" />
                                            </span>
                                        </button>

                                        <template x-teleport="body">
                                            <div x-cloak x-show="open" x-ref="menu" role="menu" @click.outside="close()" @click.stop
                                                x-transition:enter="transition duration-150 ease-out"
                                                x-transition:enter-start="translate-y-1 scale-95 opacity-0"
                                                x-transition:enter-end="translate-y-0 scale-100 opacity-100"
                                                x-transition:leave="transition duration-100 ease-in"
                                                x-transition:leave-start="translate-y-0 scale-100 opacity-100"
                                                x-transition:leave-end="translate-y-1 scale-95 opacity-0"
                                                :style="`top: ${top}px; left: ${left}px; width: ${menuWidth}px;`"
                                                class="fixed z-[9999] origin-top-right rounded-xl border border-line bg-surface p-1.5 text-left shadow-2xl space-y-0.5">

                                                <a href="{{ route('units.show', [$unit, $attachment->record_id]) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="eye" class="size-4 shrink-0 text-muted" />
                                                    <span>Lihat</span>
                                                </a>

                                                <a href="{{ route('units.attachments.download', [$unit, $attachment->id]) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="document-arrow-down" class="size-4 shrink-0 text-accent" />
                                                    <span>Unduh</span>
                                                </a>

                                                <div class="my-1 border-t border-line"></div>

                                                <a href="{{ route('units.edit', [$unit, $attachment->record_id]) }}" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-ink transition hover:bg-surface-raised">
                                                    <flux:icon name="pencil-square" class="size-4 shrink-0 text-warning" />
                                                    <span>Edit</span>
                                                </a>

                                                <form action="{{ route('units.attachments.delete', [$unit, $attachment->id]) }}" method="POST" class="w-full" data-confirm="Apakah Anda yakin ingin menghapus file ini?">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" role="menuitem" class="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-red-500 transition hover:bg-red-500/10">
                                                        <flux:icon name="trash" class="size-4 shrink-0 text-red-500" />
                                                        <span>Hapus</span>
                                                    </button>
                                                </form>
                                            </div>
                                        </template>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-4 py-10 text-center text-sm text-muted">
                                    Tidak ditemukan riwayat atau lampiran berkas fisik di dalam direktori unit ini.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-4 flex justify-end">
            {{ $attachments->links() }}
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script @cspNonce>
document.addEventListener('DOMContentLoaded', () => {
    const all = document.getElementById('selectAllRows');
    const rows = document.querySelectorAll('.rowCheckbox');

    all?.addEventListener('change', () => rows.forEach((checkbox) => {
        checkbox.checked = all.checked;
    }));
});
</script>
@endpush