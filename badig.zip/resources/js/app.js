import Alpine from 'alpinejs';

window.Alpine = Alpine;

const THEME_KEY = 'theme';

function resolveTheme() {
    // Dark is permanent default. Only an explicit saved "light" overrides it.
    return localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark';
}

function applyTheme(theme, persist = true) {
    const normalized = theme === 'light' ? 'light' : 'dark';

    document.documentElement.classList.toggle('dark', normalized === 'dark');
    document.documentElement.dataset.theme = normalized;
    document.documentElement.style.colorScheme = normalized;

    if (persist) {
        localStorage.setItem(THEME_KEY, normalized);
    }

    window.dispatchEvent(new CustomEvent('badig-theme-changed', {
        detail: { theme: normalized },
    }));

    return normalized;
}

// Re-assert the pre-paint theme immediately when the module is evaluated.
applyTheme(resolveTheme(), false);

window.BADIGTheme = {
    get: resolveTheme,
    set: (theme) => applyTheme(theme, true),
    toggle: () => applyTheme(resolveTheme() === 'dark' ? 'light' : 'dark', true),
};

Alpine.data('dashboardShell', () => ({
    mobileOpen: false,
    sidebarMini: false,

    init() {
        this.sidebarMini = window.innerWidth >= 1024 && localStorage.getItem('sidebar-mini') === 'true';

        this.$watch('sidebarMini', (value) => {
            localStorage.setItem('sidebar-mini', value ? 'true' : 'false');
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                this.mobileOpen = false;
            } else {
                this.sidebarMini = false;
            }
        });
    },

    toggleSidebar() {
        if (window.innerWidth >= 1024) {
            this.sidebarMini = !this.sidebarMini;
            return;
        }

        this.mobileOpen = !this.mobileOpen;
    },
}));

Alpine.data('themeSwitcher', () => ({
    theme: resolveTheme(),

    init() {
        this.theme = applyTheme(resolveTheme(), false);

        window.addEventListener('storage', (event) => {
            if (event.key === THEME_KEY) {
                this.theme = applyTheme(event.newValue === 'light' ? 'light' : 'dark', false);
            }
        });
    },

    toggle() {
        this.theme = applyTheme(this.theme === 'dark' ? 'light' : 'dark', true);
    },
}));

Alpine.start();
