-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sibdi_psk
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `archive_files`
--

DROP TABLE IF EXISTS `archive_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archive_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` bigint unsigned NOT NULL,
  `nama_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `archive_files_unit_id_foreign` (`unit_id`),
  CONSTRAINT `archive_files_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archive_files`
--

LOCK TABLES `archive_files` WRITE;
/*!40000 ALTER TABLE `archive_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `archive_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archives`
--

DROP TABLE IF EXISTS `archives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archives` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tanggal_pembuatan_file` date DEFAULT NULL,
  `attachment_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `archives_unit_id_foreign` (`unit_id`),
  CONSTRAINT `archives_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archives`
--

LOCK TABLES `archives` WRITE;
/*!40000 ALTER TABLE `archives` DISABLE KEYS */;
/*!40000 ALTER TABLE `archives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,NULL,'TEST','AUTH','127.0.0.1','Audit log test','2026-07-10 02:56:22','2026-07-10 02:56:22'),(2,1,'OTP_ISSUED','AUTH','127.0.0.1','Kode OTP demo dibuat untuk login.','2026-07-10 02:56:46','2026-07-10 02:56:46'),(3,1,'LOGIN','AUTH','127.0.0.1','Login berhasil melalui OTP.','2026-07-10 02:57:05','2026-07-10 02:57:05');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badig_notifications`
--

DROP TABLE IF EXISTS `badig_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `badig_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `badig_notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `badig_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badig_notifications`
--

LOCK TABLES `badig_notifications` WRITE;
/*!40000 ALTER TABLE `badig_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `badig_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_attachments`
--

DROP TABLE IF EXISTS `data_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_id` tinyint unsigned NOT NULL,
  `record_table` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` bigint unsigned NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_attachments_uploaded_by_foreign` (`uploaded_by`),
  KEY `data_attachments_unit_record_table_record_id_index` (`unit`,`record_table`,`record_id`),
  KEY `data_attachments_unit_index` (`unit`),
  KEY `data_attachments_unit_id_index` (`unit_id`),
  KEY `data_attachments_record_table_index` (`record_table`),
  KEY `data_attachments_record_id_index` (`record_id`),
  KEY `data_attachments_extension_index` (`extension`),
  CONSTRAINT `data_attachments_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_attachments`
--

LOCK TABLES `data_attachments` WRITE;
/*!40000 ALTER TABLE `data_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_orang`
--

DROP TABLE IF EXISTS `database_orang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `database_orang` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` bigint unsigned NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kategori` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_hp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `analisa_deskripsi_kerja` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `database_orang_unit_id_foreign` (`unit_id`),
  CONSTRAINT `database_orang_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_orang`
--

LOCK TABLES `database_orang` WRITE;
/*!40000 ALTER TABLE `database_orang` DISABLE KEYS */;
/*!40000 ALTER TABLE `database_orang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `districts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `districts_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,'Baros','2026-07-10 06:24:25','2026-07-10 06:24:25'),(2,'Cibeureum','2026-07-10 06:24:25','2026-07-10 06:24:25'),(3,'Cikole','2026-07-10 06:24:25','2026-07-10 06:24:25'),(4,'Citamiang','2026-07-10 06:24:25','2026-07-10 06:24:25'),(5,'Gunungpuyuh','2026-07-10 06:24:25','2026-07-10 06:24:25'),(6,'Lembursitu','2026-07-10 06:24:25','2026-07-10 06:24:25'),(7,'Warudoyong','2026-07-10 06:24:25','2026-07-10 06:24:25');
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_01_01_000001_add_sibdi_fields_to_users_table',1),(5,'2026_01_01_000002_create_sibdi_master_tables',1),(6,'2026_01_01_000003_create_sibdi_unit_tables',1),(7,'2026_01_01_000004_create_sibdi_security_tables',1),(8,'2026_07_02_000001_add_badig_archive_attachments',1),(9,'2026_07_10_082348_add_profile_fields_to_users_table',1),(10,'2026_07_10_082349_create_units_table',1),(11,'2026_07_10_082350_add_unit_reference_to_users_table',1),(12,'2026_07_10_084405_add_archive_metadata_fields',1),(13,'2026_07_10_085440_create_archive_files_table',1),(14,'2026_07_10_085639_create_database_orang_table',1),(15,'2026_07_10_085749_create_audit_logs_table',2),(16,'2026_07_10_085912_create_badig_notifications_table',2),(17,'2026_07_10_090909_create_system_settings_table',3),(18,'2026_07_10_000001_create_units_and_profile_fields',4),(19,'2026_07_10_000002_create_database_orang_table',4),(20,'2026_07_10_000003_repair_units_schema_after_partial_patch',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('60ZhWlF5DiCxDp3X0jbDZuaPzRCDnsvDDYVmd1M9',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJYTkVBOVRwb3ZxUU5XelFmNzBJMzRhb2VjRTZhSmxidTdnOWY1dzlvIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxLCJsYXN0X2FjdGl2aXR5X3RpbWUiOjE3ODM2Nzc2NDJ9',1783677656),('Yruazid4dSi0BaaVXrThmSky6G368I2wH57V0Kbu',17,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJlMVVmUlBLRDJQME9jdXRuZlZFWmhlQ0Jma3hzaFdrYXF6NGFDREIzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9hZG1pbi1pdFwvYmFja3VwIiwicm91dGUiOiJhZG1pbi5iYWNrdXAifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MTcsImxhc3RfYWN0aXZpdHlfdGltZSI6MTc4MzY5MDI4Nn0=',1783690286);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_backups`
--

DROP TABLE IF EXISTS `system_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ukuran` bigint unsigned NOT NULL DEFAULT '0',
  `status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_backups_operator_id_foreign` (`operator_id`),
  CONSTRAINT `system_backups_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_backups`
--

LOCK TABLES `system_backups` WRITE;
/*!40000 ALTER TABLE `system_backups` DISABLE KEYS */;
INSERT INTO `system_backups` VALUES (1,'backup-pending-20260710133142.sql',0,'PENDING',17,'2026-07-10 06:31:42','2026-07-10 06:31:42');
/*!40000 ALTER TABLE `system_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit1_ideology`
--

DROP TABLE IF EXISTS `unit1_ideology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit1_ideology` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_subjek` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pengikut` int unsigned DEFAULT NULL,
  `status_legal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_rawan` text COLLATE utf8mb4_unicode_ci,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit1_ideology_district_id_foreign` (`district_id`),
  KEY `unit1_ideology_village_id_foreign` (`village_id`),
  KEY `unit1_ideology_operator_id_foreign` (`operator_id`),
  KEY `unit1_ideology_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit1_ideology_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit1_ideology_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit1_ideology_unit_id_index` (`unit_id`),
  CONSTRAINT `unit1_ideology_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit1_ideology_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit1_ideology_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit1_ideology`
--

LOCK TABLES `unit1_ideology` WRITE;
/*!40000 ALTER TABLE `unit1_ideology` DISABLE KEYS */;
INSERT INTO `unit1_ideology` VALUES (1,'Parpol','Basis Aktivitas Politik Wilayah Cikole',3,7,-6.91920000,106.92720000,'submitted',NULL,10,'2026-07-10 06:24:25','2026-07-10 06:24:25',125,'Terdaftar','Perlu pemantauan dinamika kegiatan publik.',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `unit1_ideology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit2_economy`
--

DROP TABLE IF EXISTS `unit2_economy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit2_economy` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_aset` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `alamat` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapasitas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit2_economy_district_id_foreign` (`district_id`),
  KEY `unit2_economy_village_id_foreign` (`village_id`),
  KEY `unit2_economy_operator_id_foreign` (`operator_id`),
  KEY `unit2_economy_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit2_economy_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit2_economy_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit2_economy_unit_id_index` (`unit_id`),
  CONSTRAINT `unit2_economy_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit2_economy_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit2_economy_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit2_economy`
--

LOCK TABLES `unit2_economy` WRITE;
/*!40000 ALTER TABLE `unit2_economy` DISABLE KEYS */;
INSERT INTO `unit2_economy` VALUES (1,'SPBU','SPBU Strategis Warudoyong',7,19,-6.92560000,106.92180000,'approved',NULL,11,'2026-07-10 06:24:25','2026-07-10 06:24:25','Koridor utama Warudoyong','Tinggi',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `unit2_economy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit3_sosbud`
--

DROP TABLE IF EXISTS `unit3_sosbud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit3_sosbud` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_organisasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pimpinan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_anggota` int unsigned DEFAULT NULL,
  `legalitas` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_aktivitas` text COLLATE utf8mb4_unicode_ci,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit3_sosbud_district_id_foreign` (`district_id`),
  KEY `unit3_sosbud_village_id_foreign` (`village_id`),
  KEY `unit3_sosbud_operator_id_foreign` (`operator_id`),
  KEY `unit3_sosbud_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit3_sosbud_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit3_sosbud_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit3_sosbud_unit_id_index` (`unit_id`),
  CONSTRAINT `unit3_sosbud_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit3_sosbud_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit3_sosbud_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit3_sosbud`
--

LOCK TABLES `unit3_sosbud` WRITE;
/*!40000 ALTER TABLE `unit3_sosbud` DISABLE KEYS */;
INSERT INTO `unit3_sosbud` VALUES (1,'Ormas','Forum Sosial Kemasyarakatan Baros','Koordinator Wilayah',1,1,-6.95200000,106.92800000,'draft',NULL,12,'2026-07-10 06:24:25','2026-07-10 06:24:25',80,'Terdata','Aktif dalam agenda sosial lokal.',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `unit3_sosbud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit4_security_crim`
--

DROP TABLE IF EXISTS `unit4_security_crim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit4_security_crim` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_kasus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `modus` text COLLATE utf8mb4_unicode_ci,
  `status_kasus` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_enkripsi` longtext COLLATE utf8mb4_unicode_ci,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit4_security_crim_district_id_foreign` (`district_id`),
  KEY `unit4_security_crim_village_id_foreign` (`village_id`),
  KEY `unit4_security_crim_operator_id_foreign` (`operator_id`),
  KEY `unit4_security_crim_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit4_security_crim_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit4_security_crim_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit4_security_crim_unit_id_index` (`unit_id`),
  CONSTRAINT `unit4_security_crim_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit4_security_crim_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit4_security_crim_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit4_security_crim`
--

LOCK TABLES `unit4_security_crim` WRITE;
/*!40000 ALTER TABLE `unit4_security_crim` DISABLE KEYS */;
INSERT INTO `unit4_security_crim` VALUES (1,'Curanmor','Pemetaan Kasus Curanmor Citamiang',4,10,-6.92620000,106.93480000,'submitted',NULL,13,'2026-07-10 06:24:25','2026-07-10 06:24:25','Pencurian kendaraan roda dua di area parkir terbuka.','Penyelidikan','eyJpdiI6InAyS0pVd1lhS2VKWGVjdlN6U3k4YkE9PSIsInZhbHVlIjoiNHA5Ukd3S2hkU1RvY2Z6SDdwSVFpeXJxR2RkSnpjdGg4RHlIZ2pUdFJnV3p0Sy9tbGxJSEJGT0x4b2F3bERhMXFCcDJuQ3Y4K1ZMcGRqMm9uQ255NHZEK2VQbG1pWHJqWU81QjJPdnFvVE09IiwibWFjIjoiZjY1ZTg3MTY3NGQ5YjNhYmY3OTg5MTZiNGM5Yzk4NDQ4NDIyNWFkODJlMWE1ZGIxZGUwMzIyZGRjMDAwNGZlZCIsInRhZyI6IiJ9',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `unit4_security_crim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode_unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `units_kode_unit_unique` (`kode_unit`),
  KEY `units_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'Ideologi Politik','ADMIN','Unit bidang ideologi dan politik.','2026-07-10 06:28:12','2026-07-10 06:28:12','IP','unit1',1),(2,'Keamanan Negara','IP','Unit bidang keamanan negara.','2026-07-10 06:28:12','2026-07-10 06:28:12','KN','unit2',1),(3,'Unit 3','KN','Unit 3.','2026-07-10 06:28:12','2026-07-10 06:28:12','U3','unit3',1),(4,'Unit 4','U3','Unit 4.','2026-07-10 06:28:12','2026-07-10 06:28:12','U4','unit4',1),(5,'Unit 4','U4',NULL,'2026-07-10 02:26:36','2026-07-10 02:26:36',NULL,NULL,1),(6,'Unit 1 Ideologi','U1',NULL,'2026-07-10 02:36:50','2026-07-10 02:36:50',NULL,NULL,1),(7,'Unit 2 Ekonomi','U2',NULL,'2026-07-10 02:36:50','2026-07-10 02:36:50',NULL,NULL,1);
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nrp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` tinyint unsigned NOT NULL DEFAULT '2',
  `unit_id` tinyint unsigned DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `login_attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `otp_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super Admin BADIG','00000001',NULL,NULL,NULL,'admin@badig.local',NULL,'$2y$12$SFOJWmqLd.6r3bh.AZJb2.sZstjv86wVDWnceJ/ihdFFXK7hjCFYm',5,1,0,0,NULL,NULL,NULL,'2026-07-10 02:36:50','2026-07-10 02:57:05'),(2,'Pimpinan','PIM-0001','080000000003','BADIG',NULL,'pimpinan@badig.local','2026-07-10 06:28:13','$2y$12$7/z9f4cpUAtYdgY1XzgakeFs93o6TskLqHOfojpawRbINZwbJnH7u',1,NULL,0,0,'123456','2027-07-10 06:28:13','Ep8T3bKUth','2026-07-10 02:36:50','2026-07-10 06:28:13'),(3,'Admin IT','AIT-0001','080000000002','BADIG',NULL,'adminit@badig.local','2026-07-10 06:28:13','$2y$12$ud.90xRF1S/x1jVwXUk/uualElTsizon1sjRHLBXmb8jsZQZxAsu2',4,NULL,0,0,'123456','2027-07-10 06:28:13','s6CNLmPcPy','2026-07-10 02:36:51','2026-07-10 06:28:13'),(4,'Operator Unit 1 Ideologi','00000004',NULL,NULL,NULL,'unit1@badig.local',NULL,'$2y$12$/rJBqt4fwpoH2xm1KbbIHeq/5rmxwUe.bko5IIz9xkuj2qXTlD5OO',2,6,0,0,NULL,NULL,NULL,'2026-07-10 02:36:51','2026-07-10 02:36:51'),(5,'Operator Unit 2 Ekonomi','00000005',NULL,NULL,NULL,'unit2@badig.local',NULL,'$2y$12$s9pgbmj5bDIxPkrVvNTdXuHScsYBnxW3aGEI5PKqzFrOT9DQAeeXi',2,7,0,0,NULL,NULL,NULL,'2026-07-10 02:36:51','2026-07-10 02:36:51'),(6,'Operator Unit 3 Sosbud','00000006',NULL,NULL,NULL,'unit3@badig.local',NULL,'$2y$12$WVlkg6oFJdWuxNhZy5BewetFZSXxsoz7ULvxruGMmRfZo3UNSdXrK',2,4,0,0,NULL,NULL,NULL,'2026-07-10 02:36:52','2026-07-10 02:36:52'),(7,'Operator Unit 4 Keamanan','00000007',NULL,NULL,NULL,'unit4@badig.local',NULL,'$2y$12$A7WB62EMq2yFCQ3gaEBQPuJN14MVGV2vbUPPzKG4XDV7GckhzCdKC',2,5,0,0,NULL,NULL,NULL,'2026-07-10 02:36:53','2026-07-10 02:36:53'),(8,'Viewer BADIG','00000008',NULL,NULL,NULL,'viewer@badig.local',NULL,'$2y$12$YDokVx0iiZhNCGXZC.dZzeCZmxQY2qcJ3nQB1i6uoiKmArd0BSlAy',3,4,0,0,NULL,NULL,NULL,'2026-07-10 02:36:53','2026-07-10 02:36:53'),(9,'Pimpinan Polres',NULL,NULL,NULL,NULL,'pimpinan@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',1,NULL,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(10,'Operator Unit 1',NULL,NULL,NULL,NULL,'operator1@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',2,1,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(11,'Operator Unit 2',NULL,NULL,NULL,NULL,'operator2@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',2,2,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(12,'Operator Unit 3',NULL,NULL,NULL,NULL,'operator3@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',2,3,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(13,'Operator Unit 4',NULL,NULL,NULL,NULL,'operator4@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',2,4,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(14,'Kasat Intelkam',NULL,NULL,NULL,NULL,'kasat@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',3,NULL,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(15,'Admin IT',NULL,NULL,NULL,NULL,'admin@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',4,NULL,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(16,'Super Admin IT',NULL,NULL,NULL,NULL,'superadmin@sibdi.local',NULL,'$2y$12$6J0tzHIUn8McON3wnJDyLuo2Ap.hpaHj04ql.E57I76p5hjUPIp72',5,NULL,0,0,NULL,NULL,NULL,'2026-07-10 06:24:25','2026-07-10 06:24:25'),(17,'Super Admin IT','SA-0001','080000000001','BADIG',NULL,'superadmin@badig.local','2026-07-10 06:28:13','$2y$12$NgbPPJ7tYrov2rFohrK0Q.fTNOZNASTMQsWoHh2cnZN9blPr/3G2G',5,NULL,0,0,NULL,NULL,'vPlOHKb7tZ','2026-07-10 06:28:13','2026-07-10 06:29:02'),(18,'Kasat','KST-0001','080000000004','BADIG',NULL,'kasat@badig.local','2026-07-10 06:28:14','$2y$12$qrJ18iwi6SDU7PvPPIRkSOF4EgV.DBUQlPQHOBSH1smIEt1QKLC1i',3,NULL,0,0,'123456','2027-07-10 06:28:14','iZhoHrvgpf','2026-07-10 06:28:14','2026-07-10 06:28:14'),(19,'Operator Ideologi Politik','OP-IP-0001','080000000011','Unit Ideologi Politik',NULL,'operator.ip@badig.local','2026-07-10 06:28:14','$2y$12$j930Jg/JuONp0RHOTvmw4OZ59eIeKOCAvFLw09ig7JZ7pJasifYsO',2,1,0,0,'123456','2027-07-10 06:28:14','il8Ti2stD3','2026-07-10 06:28:14','2026-07-10 06:28:14'),(20,'Operator Keamanan Negara','OP-KN-0001','080000000012','Unit Keamanan Negara',NULL,'operator.kn@badig.local','2026-07-10 06:28:15','$2y$12$dSqkNlwIJB61LbPAFqRuA..81k/9AEXEh9InSuXHbSF9Kteg5Nw/y',2,2,0,0,'123456','2027-07-10 06:28:15','CbRoJjlCxs','2026-07-10 06:28:15','2026-07-10 06:28:15'),(21,'Operator Unit 3','OP-U3-0001','080000000013','Unit 3',NULL,'operator.u3@badig.local','2026-07-10 06:28:15','$2y$12$TwsLwJBMcTLK.T63vCyJqub7IiKqAkyLo0mXdnaRc3rbACIXtJFOi',2,3,0,0,'123456','2027-07-10 06:28:15','jwQ31VLQ8K','2026-07-10 06:28:15','2026-07-10 06:28:15'),(22,'Operator Unit 4','OP-U4-0001','080000000014','Unit 4',NULL,'operator.u4@badig.local','2026-07-10 06:28:15','$2y$12$GrSvfLc5zwVdvsUmdo9N6.Uuak6TGiCdl2D1P3ZScOnOVtWUDiR92',2,4,0,0,'123456','2027-07-10 06:28:15','Ffm8by3O2y','2026-07-10 06:28:15','2026-07-10 06:28:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `villages`
--

DROP TABLE IF EXISTS `villages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `villages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `district_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `villages_district_id_name_unique` (`district_id`,`name`),
  CONSTRAINT `villages_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `villages`
--

LOCK TABLES `villages` WRITE;
/*!40000 ALTER TABLE `villages` DISABLE KEYS */;
INSERT INTO `villages` VALUES (1,1,'Baros','2026-07-10 06:24:25','2026-07-10 06:24:25'),(2,1,'Jayaraksa','2026-07-10 06:24:25','2026-07-10 06:24:25'),(3,1,'Sudajaya Hilir','2026-07-10 06:24:25','2026-07-10 06:24:25'),(4,2,'Cibeureum Hilir','2026-07-10 06:24:25','2026-07-10 06:24:25'),(5,2,'Sindangpalay','2026-07-10 06:24:25','2026-07-10 06:24:25'),(6,2,'Limusnunggal','2026-07-10 06:24:25','2026-07-10 06:24:25'),(7,3,'Cikole','2026-07-10 06:24:25','2026-07-10 06:24:25'),(8,3,'Gunungparang','2026-07-10 06:24:25','2026-07-10 06:24:25'),(9,3,'Kebonjati','2026-07-10 06:24:25','2026-07-10 06:24:25'),(10,4,'Citamiang','2026-07-10 06:24:25','2026-07-10 06:24:25'),(11,4,'Nanggeleng','2026-07-10 06:24:25','2026-07-10 06:24:25'),(12,4,'Tipar','2026-07-10 06:24:25','2026-07-10 06:24:25'),(13,5,'Gunungpuyuh','2026-07-10 06:24:25','2026-07-10 06:24:25'),(14,5,'Karamat','2026-07-10 06:24:25','2026-07-10 06:24:25'),(15,5,'Sriwidari','2026-07-10 06:24:25','2026-07-10 06:24:25'),(16,6,'Cikundul','2026-07-10 06:24:25','2026-07-10 06:24:25'),(17,6,'Lembursitu','2026-07-10 06:24:25','2026-07-10 06:24:25'),(18,6,'Sindangsari','2026-07-10 06:24:25','2026-07-10 06:24:25'),(19,7,'Benteng','2026-07-10 06:24:25','2026-07-10 06:24:25'),(20,7,'Dayeuhluhur','2026-07-10 06:24:25','2026-07-10 06:24:25'),(21,7,'Sukakarya','2026-07-10 06:24:25','2026-07-10 06:24:25');
/*!40000 ALTER TABLE `villages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sibdi_psk'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-10 20:31:43
