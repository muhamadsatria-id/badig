-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sibdi_psk
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `action` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,NULL,NULL,NULL,'SEEDER_INIT','Seeder awal SIBDI-PSK berhasil dijalankan.','2026-06-24 05:44:26','2026-06-24 05:44:26'),(2,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 05:45:30','2026-06-24 05:45:30'),(3,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 05:45:36','2026-06-24 05:45:36'),(4,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 05:46:26','2026-06-24 05:46:26'),(5,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 05:47:01','2026-06-24 05:47:01'),(6,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 05:47:05','2026-06-24 05:47:05'),(7,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 05:47:36','2026-06-24 05:47:36'),(8,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 05:47:51','2026-06-24 05:47:51'),(9,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 05:47:55','2026-06-24 05:47:55'),(10,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 05:49:24','2026-06-24 05:49:24'),(11,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 05:49:32','2026-06-24 05:49:32'),(12,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','CREATE_unit1','Menambah data Unit 1 Ideologi ID 2','2026-06-24 05:51:57','2026-06-24 05:51:57'),(13,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','VALIDATE_REPORT','APPROVED Unit 1 Ideologi ID 2','2026-06-24 05:55:41','2026-06-24 05:55:41'),(14,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 05:56:23','2026-06-24 05:56:23'),(15,3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 05:56:29','2026-06-24 05:56:29'),(16,3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 05:56:33','2026-06-24 05:56:33'),(17,3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 05:57:09','2026-06-24 05:57:09'),(18,4,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 05:57:15','2026-06-24 05:57:15'),(19,4,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 05:57:21','2026-06-24 05:57:21'),(20,4,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 05:57:46','2026-06-24 05:57:46'),(21,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 06:02:12','2026-06-24 06:02:12'),(22,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 06:02:26','2026-06-24 06:02:26'),(23,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 09:02:48','2026-06-24 09:02:48'),(24,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 09:02:51','2026-06-24 09:02:51'),(25,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:19:27','2026-06-24 23:19:27'),(26,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:19:33','2026-06-24 23:19:33'),(27,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:22:15','2026-06-24 23:22:15'),(28,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:22:25','2026-06-24 23:22:25'),(29,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:22:29','2026-06-24 23:22:29'),(30,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:26:24','2026-06-24 23:26:24'),(31,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:26:40','2026-06-24 23:26:40'),(32,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:26:44','2026-06-24 23:26:44'),(33,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:29:21','2026-06-24 23:29:21'),(34,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:29:40','2026-06-24 23:29:40'),(35,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:29:44','2026-06-24 23:29:44'),(36,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','BACKUP_DATABASE','Backup database status: FAILED_MISSING_MYSQLDUMP','2026-06-24 23:31:04','2026-06-24 23:31:04'),(37,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:51:00','2026-06-24 23:51:00'),(38,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:51:14','2026-06-24 23:51:14'),(39,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:51:25','2026-06-24 23:51:25'),(40,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:52:30','2026-06-24 23:52:30'),(41,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:52:37','2026-06-24 23:52:37'),(42,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:52:42','2026-06-24 23:52:42'),(43,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:53:14','2026-06-24 23:53:14'),(44,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:53:27','2026-06-24 23:53:27'),(45,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:53:34','2026-06-24 23:53:34'),(46,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','BACKUP_DATABASE','Backup database status: FAILED_MISSING_MYSQLDUMP','2026-06-24 23:53:49','2026-06-24 23:53:49'),(47,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:54:17','2026-06-24 23:54:17'),(48,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:54:28','2026-06-24 23:54:28'),(49,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:54:32','2026-06-24 23:54:32'),(50,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:57:25','2026-06-24 23:57:25'),(51,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:57:38','2026-06-24 23:57:38'),(52,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-24 23:57:42','2026-06-24 23:57:42'),(53,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','BACKUP_DATABASE','Backup database status: SUCCESS','2026-06-24 23:57:52','2026-06-24 23:57:52'),(54,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-24 23:59:47','2026-06-24 23:59:47'),(55,5,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-24 23:59:58','2026-06-24 23:59:58'),(56,5,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 00:00:01','2026-06-25 00:00:01'),(57,5,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 00:00:47','2026-06-25 00:00:47'),(58,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 00:00:59','2026-06-25 00:00:59'),(59,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 00:01:03','2026-06-25 00:01:03'),(60,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 00:04:35','2026-06-25 00:04:35'),(61,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 00:04:48','2026-06-25 00:04:48'),(62,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 00:04:52','2026-06-25 00:04:52'),(63,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 00:08:44','2026-06-25 00:08:44'),(64,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 00:09:08','2026-06-25 00:09:08'),(65,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 00:09:14','2026-06-25 00:09:14'),(66,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 1','2026-06-25 00:37:04','2026-06-25 00:37:04'),(67,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 00:37:27','2026-06-25 00:37:27'),(68,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 1','2026-06-25 00:37:41','2026-06-25 00:37:41'),(69,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 3 Sosbud ID 1','2026-06-25 00:38:01','2026-06-25 00:38:01'),(70,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 3 Sosbud ID 1','2026-06-25 00:38:29','2026-06-25 00:38:29'),(71,6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 00:39:15','2026-06-25 00:39:15'),(72,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 00:39:33','2026-06-25 00:39:33'),(73,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 00:39:38','2026-06-25 00:39:38'),(74,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PIMPINAN_EXPORT_PDF','Export File Manager Pimpinan format pdf total 5 data.','2026-06-25 00:39:56','2026-06-25 00:39:56'),(75,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 2','2026-06-25 00:40:09','2026-06-25 00:40:09'),(76,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 2','2026-06-25 00:40:13','2026-06-25 00:40:13'),(77,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 2','2026-06-25 00:40:18','2026-06-25 00:40:18'),(78,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 2','2026-06-25 00:40:28','2026-06-25 00:40:28'),(79,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 01:16:50','2026-06-25 01:16:50'),(80,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 01:37:59','2026-06-25 01:37:59'),(81,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 01:39:36','2026-06-25 01:39:36'),(82,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 01:39:57','2026-06-25 01:39:57'),(83,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 01:40:07','2026-06-25 01:40:07'),(84,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 01:40:38','2026-06-25 01:40:38'),(85,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 01:40:43','2026-06-25 01:40:43'),(86,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 01:40:51','2026-06-25 01:40:51'),(87,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 01:41:42','2026-06-25 01:41:42'),(88,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 01:41:47','2026-06-25 01:41:47'),(89,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 01:42:05','2026-06-25 01:42:05'),(90,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 01:42:20','2026-06-25 01:42:20'),(91,1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 01:42:34','2026-06-25 01:42:34'),(92,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 01:42:43','2026-06-25 01:42:43'),(93,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 01:42:48','2026-06-25 01:42:48'),(94,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','CREATE_unit1','Menambah data Unit 1 Ideologi ID 3','2026-06-25 01:54:18','2026-06-25 01:54:18'),(95,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 01:54:20','2026-06-25 01:54:20'),(96,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 01:55:17','2026-06-25 01:55:17'),(97,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 01:59:57','2026-06-25 01:59:57'),(98,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:00:29','2026-06-25 02:00:29'),(99,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:02:42','2026-06-25 02:02:42'),(100,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:03:23','2026-06-25 02:03:23'),(101,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:07:11','2026-06-25 02:07:11'),(102,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:07:42','2026-06-25 02:07:42'),(103,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:14:34','2026-06-25 02:14:34'),(104,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 02:37:01','2026-06-25 02:37:01'),(105,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 02:37:16','2026-06-25 02:37:16'),(106,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 02:37:21','2026-06-25 02:37:21'),(107,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ILLEGAL_ACCESS_ATTEMPT','Akses ditolak ke rute: http://127.0.0.1:8000/super-admin','2026-06-25 02:37:38','2026-06-25 02:37:38'),(108,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ILLEGAL_ACCESS_ATTEMPT','Akses ditolak ke rute: http://127.0.0.1:8000/super-admin','2026-06-25 02:38:00','2026-06-25 02:38:00'),(109,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 02:39:41','2026-06-25 02:39:41'),(110,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','LOGIN','Login berhasil melalui OTP.','2026-06-25 02:39:46','2026-06-25 02:39:46'),(111,7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 02:56:32','2026-06-25 02:56:32'),(112,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 02:56:56','2026-06-25 02:56:56'),(113,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 02:57:01','2026-06-25 02:57:01'),(114,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 02:57:11','2026-06-25 02:57:11'),(115,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:57:43','2026-06-25 02:57:43'),(116,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:58:30','2026-06-25 02:58:30'),(117,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 02:58:50','2026-06-25 02:58:50'),(118,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 02:59:25','2026-06-25 02:59:25'),(119,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:03:03','2026-06-25 03:03:03'),(120,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:03:10','2026-06-25 03:03:10'),(121,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:03:53','2026-06-25 03:03:53'),(122,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:04:25','2026-06-25 03:04:25'),(123,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:07:05','2026-06-25 03:07:05'),(124,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:07:36','2026-06-25 03:07:36'),(125,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:07:41','2026-06-25 03:07:41'),(126,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:08:44','2026-06-25 03:08:44'),(127,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:08:54','2026-06-25 03:08:54'),(128,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:09:24','2026-06-25 03:09:24'),(129,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:10:02','2026-06-25 03:10:02'),(130,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:23:21','2026-06-25 03:23:21'),(131,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:23:27','2026-06-25 03:23:27'),(132,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:29:16','2026-06-25 03:29:16'),(133,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:29:36','2026-06-25 03:29:36'),(134,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:36:58','2026-06-25 03:36:58'),(135,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:37:46','2026-06-25 03:37:46'),(136,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:38:21','2026-06-25 03:38:21'),(137,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:39:09','2026-06-25 03:39:09'),(138,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:39:15','2026-06-25 03:39:15'),(139,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:39:26','2026-06-25 03:39:26'),(140,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:40:31','2026-06-25 03:40:31'),(141,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:40:59','2026-06-25 03:40:59'),(142,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:41:22','2026-06-25 03:41:22'),(143,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:41:35','2026-06-25 03:41:35'),(144,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:41:47','2026-06-25 03:41:47'),(145,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','DOWNLOAD_PDF','Mengunduh PDF dokumen Unit 1 Ideologi ID 3','2026-06-25 03:43:06','2026-06-25 03:43:06'),(146,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:44:06','2026-06-25 03:44:06'),(147,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 03:44:31','2026-06-25 03:44:31'),(148,2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGOUT','Pengguna keluar dari sistem.','2026-06-25 03:45:29','2026-06-25 03:45:29'),(149,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','OTP_ISSUED','Kode OTP demo dibuat untuk login.','2026-06-25 04:06:54','2026-06-25 04:06:54'),(150,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','LOGIN','Login berhasil melalui OTP.','2026-06-25 04:07:07','2026-06-25 04:07:07'),(151,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 04:27:25','2026-06-25 04:27:25'),(152,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','VALIDATE_REPORT','APPROVED Unit 1 Ideologi ID 3','2026-06-25 04:27:29','2026-06-25 04:27:29'),(153,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:27:45','2026-06-25 04:27:45'),(154,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:34:37','2026-06-25 04:34:37'),(155,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:35:19','2026-06-25 04:35:19'),(156,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:35:35','2026-06-25 04:35:35'),(157,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:35:57','2026-06-25 04:35:57'),(158,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:39:39','2026-06-25 04:39:39'),(159,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:40:25','2026-06-25 04:40:25'),(160,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 1','2026-06-25 04:40:57','2026-06-25 04:40:57'),(161,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PIMPINAN_EXPORT_PDF','Export File Manager Pimpinan format pdf total 6 data.','2026-06-25 04:41:16','2026-06-25 04:41:16'),(162,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PIMPINAN_EXPORT_EXCEL','Export File Manager Pimpinan format excel total 6 data.','2026-06-25 04:41:31','2026-06-25 04:41:31'),(163,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 04:42:20','2026-06-25 04:42:20'),(164,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 04:42:30','2026-06-25 04:42:30'),(165,8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','PREVIEW_DOCUMENT','Membuka pratinjau dokumen Unit 1 Ideologi ID 3','2026-06-25 04:42:44','2026-06-25 04:42:44');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_audit_logs_no_update` BEFORE UPDATE ON `audit_logs` FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Audit logs cannot be updated'; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_audit_logs_no_delete` BEFORE DELETE ON `audit_logs` FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Audit logs cannot be deleted'; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `districts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `districts_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,'Baros','2026-06-24 05:44:26','2026-06-24 05:44:26'),(2,'Cibeureum','2026-06-24 05:44:26','2026-06-24 05:44:26'),(3,'Cikole','2026-06-24 05:44:26','2026-06-24 05:44:26'),(4,'Citamiang','2026-06-24 05:44:26','2026-06-24 05:44:26'),(5,'Gunungpuyuh','2026-06-24 05:44:26','2026-06-24 05:44:26'),(6,'Lembursitu','2026-06-24 05:44:26','2026-06-24 05:44:26'),(7,'Warudoyong','2026-06-24 05:44:26','2026-06-24 05:44:26');
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_01_01_000001_add_sibdi_fields_to_users_table',1),(5,'2026_01_01_000002_create_sibdi_master_tables',1),(6,'2026_01_01_000003_create_sibdi_unit_tables',2),(7,'2026_01_01_000004_create_sibdi_security_tables',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('fON9EO1wAwxO231lzolvWMlcDkAy46HXjePsT0lr',8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','eyJfdG9rZW4iOiI3RVFiSzNwRVI0SkwwVFdqTEZ2SVdhUVlpT085TkJlOWtGeXZobXFoIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL3N1cGVyLWFkbWluIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC8xMjcuMC4wLjE6ODAwMFwvYWRtaW4taXRcL3VzZXJzIiwicm91dGUiOiJhZG1pbi51c2VycyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjo4LCJsYXN0X2FjdGl2aXR5X3RpbWUiOjE3ODIzODA2MDV9',1782380607),('sJldBEmicA8PHIETc0pNH7GeO6I23Qot36jo5uhI',8,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJxTHBFcG51YVRwOEhORTl6YllIQ3FpaDlmMlZ0bnZ4eWxxQnVKMjhOIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL2FkbWluLWl0XC9iYWNrdXAiLCJyb3V0ZSI6ImFkbWluLmJhY2t1cCJ9LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6OCwibGFzdF9hY3Rpdml0eV90aW1lIjoxNzgyMzg4MDI3fQ==',1782388029);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_backups`
--

DROP TABLE IF EXISTS `system_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ukuran` bigint unsigned NOT NULL DEFAULT '0',
  `status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_backups_operator_id_foreign` (`operator_id`),
  CONSTRAINT `system_backups_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_backups`
--

LOCK TABLES `system_backups` WRITE;
/*!40000 ALTER TABLE `system_backups` DISABLE KEYS */;
INSERT INTO `system_backups` VALUES (1,'backups/sibdi_backup_20260625_063104.sql',67,'FAILED_MISSING_MYSQLDUMP',7,'2026-06-24 23:31:04','2026-06-24 23:31:04'),(2,'backups/sibdi_backup_20260625_065348.sql',67,'FAILED_MISSING_MYSQLDUMP',7,'2026-06-24 23:53:49','2026-06-24 23:53:49'),(3,'backups/sibdi_backup_20260625_065751.sql',42005,'SUCCESS',7,'2026-06-24 23:57:52','2026-06-24 23:57:52');
/*!40000 ALTER TABLE `system_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit1_ideology`
--

DROP TABLE IF EXISTS `unit1_ideology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit1_ideology` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_subjek` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pengikut` int unsigned DEFAULT NULL,
  `status_legal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_rawan` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `unit1_ideology_district_id_foreign` (`district_id`),
  KEY `unit1_ideology_village_id_foreign` (`village_id`),
  KEY `unit1_ideology_operator_id_foreign` (`operator_id`),
  CONSTRAINT `unit1_ideology_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit1_ideology_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit1_ideology_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit1_ideology`
--

LOCK TABLES `unit1_ideology` WRITE;
/*!40000 ALTER TABLE `unit1_ideology` DISABLE KEYS */;
INSERT INTO `unit1_ideology` VALUES (1,'Parpol','Basis Aktivitas Politik Wilayah Cikole',3,7,-6.91920000,106.92720000,'submitted',NULL,2,'2026-06-24 05:44:26','2026-06-24 05:44:26',125,'Terdaftar','Perlu pemantauan dinamika kegiatan publik.'),(2,'Aliran','Tes',1,1,-7.91000000,110.43000000,'approved',NULL,2,'2026-06-24 05:51:56','2026-06-24 05:55:41',12,'Legal','Hdahabjhv'),(3,'Kades','lklklkas',1,1,-6.82826135,107.13935852,'approved',NULL,2,'2026-06-25 01:54:18','2026-06-25 04:27:29',2131,'amdad a kadmk','amdaafmf');
/*!40000 ALTER TABLE `unit1_ideology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit2_economy`
--

DROP TABLE IF EXISTS `unit2_economy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit2_economy` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_aset` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `alamat` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapasitas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit2_economy_district_id_foreign` (`district_id`),
  KEY `unit2_economy_village_id_foreign` (`village_id`),
  KEY `unit2_economy_operator_id_foreign` (`operator_id`),
  CONSTRAINT `unit2_economy_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit2_economy_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit2_economy_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit2_economy`
--

LOCK TABLES `unit2_economy` WRITE;
/*!40000 ALTER TABLE `unit2_economy` DISABLE KEYS */;
INSERT INTO `unit2_economy` VALUES (1,'SPBU','SPBU Strategis Warudoyong',7,19,-6.92560000,106.92180000,'approved',NULL,3,'2026-06-24 05:44:26','2026-06-24 05:44:26','Koridor utama Warudoyong','Tinggi');
/*!40000 ALTER TABLE `unit2_economy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit3_sosbud`
--

DROP TABLE IF EXISTS `unit3_sosbud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit3_sosbud` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_organisasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pimpinan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_anggota` int unsigned DEFAULT NULL,
  `legalitas` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_aktivitas` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `unit3_sosbud_district_id_foreign` (`district_id`),
  KEY `unit3_sosbud_village_id_foreign` (`village_id`),
  KEY `unit3_sosbud_operator_id_foreign` (`operator_id`),
  CONSTRAINT `unit3_sosbud_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit3_sosbud_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit3_sosbud_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit3_sosbud`
--

LOCK TABLES `unit3_sosbud` WRITE;
/*!40000 ALTER TABLE `unit3_sosbud` DISABLE KEYS */;
INSERT INTO `unit3_sosbud` VALUES (1,'Ormas','Forum Sosial Kemasyarakatan Baros','Koordinator Wilayah',1,1,-6.95200000,106.92800000,'draft',NULL,4,'2026-06-24 05:44:26','2026-06-24 05:44:26',80,'Terdata','Aktif dalam agenda sosial lokal.');
/*!40000 ALTER TABLE `unit3_sosbud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit4_security_crim`
--

DROP TABLE IF EXISTS `unit4_security_crim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit4_security_crim` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_kasus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `modus` text COLLATE utf8mb4_unicode_ci,
  `status_kasus` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_enkripsi` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `unit4_security_crim_district_id_foreign` (`district_id`),
  KEY `unit4_security_crim_village_id_foreign` (`village_id`),
  KEY `unit4_security_crim_operator_id_foreign` (`operator_id`),
  CONSTRAINT `unit4_security_crim_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit4_security_crim_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit4_security_crim_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit4_security_crim`
--

LOCK TABLES `unit4_security_crim` WRITE;
/*!40000 ALTER TABLE `unit4_security_crim` DISABLE KEYS */;
INSERT INTO `unit4_security_crim` VALUES (1,'Curanmor','Pemetaan Kasus Curanmor Citamiang',4,10,-6.92620000,106.93480000,'submitted',NULL,5,'2026-06-24 05:44:26','2026-06-24 05:44:26','Pencurian kendaraan roda dua di area parkir terbuka.','Penyelidikan','eyJpdiI6Im9UZ1k2aktKZXJnZ0dNQVNDWUpxL3c9PSIsInZhbHVlIjoiL0NIYXdHQnZ1T1NEU0tWM1VzWG5pZ2JvRTQwWjRRTFBOckVSM24xdS9kL2tWUEVEZEpIQm1UbFJyeGNLZ29XbmgzaUpTelc1Ukl0Qm81L1M4Ni9tbi84bTJLSjBTMWRHMG82QU5rdTdWTnM9IiwibWFjIjoiMDExZTU0ODM4NGY5M2NhYmIwOTgyZGMwZDA0MTU3MjM3NjI5OWJlZjVjMDE5ZTVkZDdhNjYxOGJkYTVlMmM3OCIsInRhZyI6IiJ9');
/*!40000 ALTER TABLE `unit4_security_crim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` tinyint unsigned NOT NULL DEFAULT '2',
  `unit_id` tinyint unsigned DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `login_attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `otp_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Pimpinan Polres','pimpinan@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',1,NULL,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-25 01:42:20'),(2,'Operator Unit 1','operator1@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',2,1,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-25 02:57:01'),(3,'Operator Unit 2','operator2@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',2,2,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-24 05:56:33'),(4,'Operator Unit 3','operator3@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',2,3,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-24 05:57:21'),(5,'Operator Unit 4','operator4@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',2,4,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-25 00:00:01'),(6,'Kasat Intelkam','kasat@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',3,NULL,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-25 00:09:13'),(7,'Admin IT','admin@sibdi.local',NULL,'$2y$12$hs3LPQLxITOTVaY.Mqgh5OM0zCXvGX8syX0gZww.BCX9tnZMq5mPC',4,NULL,0,0,NULL,NULL,NULL,'2026-06-24 05:44:26','2026-06-25 02:37:21'),(8,'Super Admin IT','superadmin@sibdi.local',NULL,'$2y$12$YBKgLOLxg3g0fcuGkL.3IO.JyY2Ei7zGhi/q2vRiIgxLGYQXhHnoa',5,NULL,0,0,NULL,NULL,NULL,'2026-06-25 02:36:41','2026-06-25 04:07:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `villages`
--

DROP TABLE IF EXISTS `villages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `villages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `district_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `villages_district_id_name_unique` (`district_id`,`name`),
  CONSTRAINT `villages_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `villages`
--

LOCK TABLES `villages` WRITE;
/*!40000 ALTER TABLE `villages` DISABLE KEYS */;
INSERT INTO `villages` VALUES (1,1,'Baros','2026-06-24 05:44:26','2026-06-24 05:44:26'),(2,1,'Jayaraksa','2026-06-24 05:44:26','2026-06-24 05:44:26'),(3,1,'Sudajaya Hilir','2026-06-24 05:44:26','2026-06-24 05:44:26'),(4,2,'Cibeureum Hilir','2026-06-24 05:44:26','2026-06-24 05:44:26'),(5,2,'Sindangpalay','2026-06-24 05:44:26','2026-06-24 05:44:26'),(6,2,'Limusnunggal','2026-06-24 05:44:26','2026-06-24 05:44:26'),(7,3,'Cikole','2026-06-24 05:44:26','2026-06-24 05:44:26'),(8,3,'Gunungparang','2026-06-24 05:44:26','2026-06-24 05:44:26'),(9,3,'Kebonjati','2026-06-24 05:44:26','2026-06-24 05:44:26'),(10,4,'Citamiang','2026-06-24 05:44:26','2026-06-24 05:44:26'),(11,4,'Nanggeleng','2026-06-24 05:44:26','2026-06-24 05:44:26'),(12,4,'Tipar','2026-06-24 05:44:26','2026-06-24 05:44:26'),(13,5,'Gunungpuyuh','2026-06-24 05:44:26','2026-06-24 05:44:26'),(14,5,'Karamat','2026-06-24 05:44:26','2026-06-24 05:44:26'),(15,5,'Sriwidari','2026-06-24 05:44:26','2026-06-24 05:44:26'),(16,6,'Cikundul','2026-06-24 05:44:26','2026-06-24 05:44:26'),(17,6,'Lembursitu','2026-06-24 05:44:26','2026-06-24 05:44:26'),(18,6,'Sindangsari','2026-06-24 05:44:26','2026-06-24 05:44:26'),(19,7,'Benteng','2026-06-24 05:44:26','2026-06-24 05:44:26'),(20,7,'Dayeuhluhur','2026-06-24 05:44:26','2026-06-24 05:44:26'),(21,7,'Sukakarya','2026-06-24 05:44:26','2026-06-24 05:44:26');
/*!40000 ALTER TABLE `villages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sibdi_psk'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-25 18:47:14
