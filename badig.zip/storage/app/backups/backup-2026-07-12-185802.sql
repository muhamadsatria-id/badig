-- Backup SQL BADIG
-- Database: sibdi_psk
-- Dibuat pada: 2026-07-12 18:58:02

SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------------
-- Struktur tabel archive_files
DROP TABLE IF EXISTS `archive_files`;
CREATE TABLE `archive_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` tinyint unsigned DEFAULT NULL,
  `nama_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `archive_files_unit_id_index` (`unit_id`),
  KEY `archive_files_extension_index` (`extension`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel audit_logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `action` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 'SEEDER_INIT', NULL, 'Seeder awal SIBDI-PSK berhasil dijalankan.', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('2', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'OTP_ISSUED', NULL, 'Kode OTP demo dibuat untuk login.', '2026-07-12 15:36:05', '2026-07-12 15:36:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('3', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'LOGIN', NULL, 'Login berhasil melalui OTP.', '2026-07-12 15:36:24', '2026-07-12 15:36:24');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('4', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'CREATE_DATABASE_BURONAN', NULL, 'Menambah Data Buronan/DPO ID 1 atas nama Abdurr', '2026-07-12 15:41:39', '2026-07-12 15:41:39');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('5', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'EXPORT_DATABASE_BURONAN_PDF', NULL, 'Mencetak dokumen DPO 12 atas nama Abdurr', '2026-07-12 15:42:09', '2026-07-12 15:42:09');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('6', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'OTP_ISSUED', NULL, 'Kode OTP demo dibuat untuk login.', '2026-07-12 17:51:43', '2026-07-12 17:51:43');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('7', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'LOGIN', NULL, 'Login berhasil melalui OTP.', '2026-07-12 17:51:51', '2026-07-12 17:51:51');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('8', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'LOGOUT', NULL, 'Pengguna keluar dari sistem.', '2026-07-12 17:52:13', '2026-07-12 17:52:13');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('9', '4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'OTP_ISSUED', NULL, 'Kode OTP demo dibuat untuk login.', '2026-07-12 17:54:36', '2026-07-12 17:54:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('10', '4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'LOGIN', NULL, 'Login berhasil melalui OTP.', '2026-07-12 17:54:40', '2026-07-12 17:54:40');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('11', '4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'LOGOUT', NULL, 'Pengguna keluar dari sistem.', '2026-07-12 17:55:36', '2026-07-12 17:55:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('12', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'OTP_ISSUED', NULL, 'Kode OTP demo dibuat untuk login.', '2026-07-12 18:05:10', '2026-07-12 18:05:10');
INSERT INTO `audit_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `action`, `module`, `description`, `created_at`, `updated_at`) VALUES ('13', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'LOGIN', NULL, 'Login berhasil melalui OTP.', '2026-07-12 18:05:16', '2026-07-12 18:05:16');

-- --------------------------------------------------------
-- Struktur tabel badig_notifications
DROP TABLE IF EXISTS `badig_notifications`;
CREATE TABLE `badig_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `badig_notifications_user_id_foreign` (`user_id`),
  KEY `badig_notifications_is_read_index` (`is_read`),
  CONSTRAINT `badig_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel cache
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel cache_locks
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel data_attachments
DROP TABLE IF EXISTS `data_attachments`;
CREATE TABLE `data_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_id` tinyint unsigned NOT NULL,
  `record_table` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` bigint unsigned NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `attachment_role` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_attachments_uploaded_by_foreign` (`uploaded_by`),
  KEY `data_attachments_unit_record_table_record_id_index` (`unit`,`record_table`,`record_id`),
  KEY `data_attachments_unit_index` (`unit`),
  KEY `data_attachments_unit_id_index` (`unit_id`),
  KEY `data_attachments_record_table_index` (`record_table`),
  KEY `data_attachments_record_id_index` (`record_id`),
  KEY `data_attachments_extension_index` (`extension`),
  KEY `data_attachments_attachment_role_index` (`attachment_role`),
  CONSTRAINT `data_attachments_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel database_orang
DROP TABLE IF EXISTS `database_orang`;
CREATE TABLE `database_orang` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` tinyint unsigned DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_kelamin` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tempat_lahir` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pekerjaan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kategori` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_dpo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instansi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sifat_dokumen` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_dokumen` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomor_dpo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_dikeluarkan` date DEFAULT NULL,
  `tempat_dikeluarkan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kewarganegaraan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_hukum` text COLLATE utf8mb4_unicode_ci,
  `rumus_dactiloscopy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_alternatif` text COLLATE utf8mb4_unicode_ci,
  `tinggi_badan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `berat_badan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rambut` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bentuk_tubuh` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warna_kulit` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warna_mata` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidung` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bibir` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ciri_lainnya` text COLLATE utf8mb4_unicode_ci,
  `dugaan_tindak_pidana` text COLLATE utf8mb4_unicode_ci,
  `melanggar_pasal` text COLLATE utf8mb4_unicode_ci,
  `no_reg_kejahatan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keterangan_lain` text COLLATE utf8mb4_unicode_ci,
  `analisis_deskripsi` longtext COLLATE utf8mb4_unicode_ci,
  `nama_penyidik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jabatan_penyidik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_hp_penyidik` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pejabat_penandatangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jabatan_penandatangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nrp_penandatangan` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `database_orang_created_by_foreign` (`created_by`),
  KEY `database_orang_unit_id_nama_index` (`unit_id`,`nama`),
  KEY `database_orang_unit_id_index` (`unit_id`),
  KEY `database_orang_nama_index` (`nama`),
  KEY `database_orang_nik_index` (`nik`),
  KEY `database_orang_nrp_index` (`nrp`),
  KEY `database_orang_kategori_index` (`kategori`),
  KEY `database_orang_status_dpo_index` (`status_dpo`),
  KEY `database_orang_nomor_dpo_index` (`nomor_dpo`),
  KEY `database_orang_tanggal_dikeluarkan_index` (`tanggal_dikeluarkan`),
  KEY `database_orang_no_reg_kejahatan_index` (`no_reg_kejahatan`),
  CONSTRAINT `database_orang_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `database_orang` (`id`, `unit_id`, `nama`, `nik`, `nrp`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `phone`, `email`, `pekerjaan`, `keterangan`, `created_by`, `created_at`, `updated_at`, `foto`, `kategori`, `status_dpo`, `instansi`, `sifat_dokumen`, `jenis_dokumen`, `nomor_dpo`, `tanggal_dikeluarkan`, `tempat_dikeluarkan`, `kewarganegaraan`, `catatan_hukum`, `rumus_dactiloscopy`, `alamat_alternatif`, `tinggi_badan`, `berat_badan`, `rambut`, `bentuk_tubuh`, `warna_kulit`, `warna_mata`, `hidung`, `bibir`, `ciri_lainnya`, `dugaan_tindak_pidana`, `melanggar_pasal`, `no_reg_kejahatan`, `keterangan_lain`, `analisis_deskripsi`, `nama_penyidik`, `jabatan_penyidik`, `no_hp_penyidik`, `pejabat_penandatangan`, `jabatan_penandatangan`, `nrp_penandatangan`) VALUES ('1', '1', 'Abdurr', '3202320040321000', NULL, 'Laki-laki', 'Sukabumi', '2000-08-09', 'Kp. Kalapa Nunggal', '08988712313', NULL, 'PT Mang coding', NULL, '8', '2026-07-12 15:41:14', '2026-07-12 15:41:38', 'badig/database-buronan/1/foto-4ec87d03-4b9a-4e49-93e8-d9c247b43261.jpeg', 'Penjahat Kelamin', 'Aktif', 'SATUAN INTELKAM', 'TERBATAS', 'DAFTAR PENCARIAN ORANG (DPO)', '12', '2026-07-12', 'Sukabumi', 'Indonesia', 'Pernah Melakukan Kejahatan Kelamin', 'Muhsauha', NULL, '180', '65', 'Hitam/Pendek', 'Kecil Berisi', 'Sawo Matang', 'Hitam', '-', '-', NULL, 'Memaksa Keluarkan Air Mani', '32 Pasal IT', '019308147', 'jdaida', 'ajhuiabfd', 'Muhamad Satria', 'Ketua yayasan', '8974417871', 'Nadhbafh', 'ahfiahb', '917871479');

-- --------------------------------------------------------
-- Struktur tabel districts
DROP TABLE IF EXISTS `districts`;
CREATE TABLE `districts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `districts_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('1', 'Baros', '2026-07-12 15:29:14', '2026-07-12 15:29:14');
INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('2', 'Cibeureum', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('3', 'Cikole', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('4', 'Citamiang', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('5', 'Gunungpuyuh', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('6', 'Lembursitu', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `districts` (`id`, `name`, `created_at`, `updated_at`) VALUES ('7', 'Warudoyong', '2026-07-12 15:29:16', '2026-07-12 15:29:16');

-- --------------------------------------------------------
-- Struktur tabel failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel job_batches
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel jobs
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('1', '0001_01_01_000000_create_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('2', '0001_01_01_000001_create_cache_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('3', '0001_01_01_000002_create_jobs_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('4', '2026_01_01_000001_add_sibdi_fields_to_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('5', '2026_01_01_000002_create_sibdi_master_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('6', '2026_01_01_000003_create_sibdi_unit_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('7', '2026_01_01_000004_create_sibdi_security_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('8', '2026_07_02_000001_add_badig_archive_attachments', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('9', '2026_07_09_235959_fix_legacy_units_kode_unit_nullable', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('10', '2026_07_10_000001_create_units_and_profile_fields', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('11', '2026_07_10_000002_create_database_orang_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('12', '2026_07_10_000003_repair_units_schema_after_partial_patch', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('13', '2026_07_10_000004_repair_units_active_scope_compatibility', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('14', '2026_07_10_082348_add_profile_fields_to_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('15', '2026_07_10_082349_create_units_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('16', '2026_07_10_082350_add_unit_reference_to_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('17', '2026_07_10_084405_add_archive_metadata_fields', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('18', '2026_07_10_085440_create_archive_files_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('19', '2026_07_10_085639_create_database_orang_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('20', '2026_07_10_085749_create_audit_logs_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('21', '2026_07_10_085912_create_badig_notifications_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('22', '2026_07_10_090909_create_system_settings_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('23', '2026_07_10_235959_sync_units_kode_and_kode_unit', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('24', '2026_07_12_000010_upgrade_units_and_database_buronan', '1');

-- --------------------------------------------------------
-- Struktur tabel password_reset_tokens
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES ('XPfJaM3Ovi5gSB0nOsLux6LAZA2fdoORaLhSMLZO', '8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiJmRjgxSzBnZ01USGRBRWczSWNxTmtudGtlWFYzYjBkNG5WSnE3cld5IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL2FkbWluLWl0XC9iYWNrdXAiLCJyb3V0ZSI6ImFkbWluLmJhY2t1cCJ9LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6OCwibGFzdF9hY3Rpdml0eV90aW1lIjoxNzgzODgyNjY5fQ==', '1783882670');

-- --------------------------------------------------------
-- Struktur tabel system_backups
DROP TABLE IF EXISTS `system_backups`;
CREATE TABLE `system_backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ukuran` bigint unsigned NOT NULL DEFAULT '0',
  `status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_backups_operator_id_foreign` (`operator_id`),
  CONSTRAINT `system_backups_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel system_settings
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Struktur tabel unit1_ideology
DROP TABLE IF EXISTS `unit1_ideology`;
CREATE TABLE `unit1_ideology` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_subjek` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pengikut` int unsigned DEFAULT NULL,
  `status_legal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_rawan` text COLLATE utf8mb4_unicode_ci,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit1_ideology_district_id_foreign` (`district_id`),
  KEY `unit1_ideology_village_id_foreign` (`village_id`),
  KEY `unit1_ideology_operator_id_foreign` (`operator_id`),
  KEY `unit1_ideology_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit1_ideology_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit1_ideology_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit1_ideology_unit_id_index` (`unit_id`),
  CONSTRAINT `unit1_ideology_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit1_ideology_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit1_ideology_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `unit1_ideology` (`id`, `kategori`, `nama_subjek`, `district_id`, `village_id`, `koordinat_lat`, `koordinat_lng`, `status_laporan`, `catatan_validasi`, `operator_id`, `created_at`, `updated_at`, `pengikut`, `status_legal`, `catatan_rawan`, `tanggal_pembuatan`, `pelapor_nama`, `pelapor_nrp`, `unit_id`) VALUES ('1', 'Parpol', 'Basis Aktivitas Politik Wilayah Cikole', '3', '7', '-6.91920000', '106.92720000', 'submitted', NULL, '2', '2026-07-12 15:29:16', '2026-07-12 15:29:16', '125', 'Terdaftar', 'Perlu pemantauan dinamika kegiatan publik.', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Struktur tabel unit2_economy
DROP TABLE IF EXISTS `unit2_economy`;
CREATE TABLE `unit2_economy` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_aset` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `alamat` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapasitas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit2_economy_district_id_foreign` (`district_id`),
  KEY `unit2_economy_village_id_foreign` (`village_id`),
  KEY `unit2_economy_operator_id_foreign` (`operator_id`),
  KEY `unit2_economy_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit2_economy_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit2_economy_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit2_economy_unit_id_index` (`unit_id`),
  CONSTRAINT `unit2_economy_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit2_economy_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit2_economy_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `unit2_economy` (`id`, `kategori`, `nama_aset`, `district_id`, `village_id`, `koordinat_lat`, `koordinat_lng`, `status_laporan`, `catatan_validasi`, `operator_id`, `created_at`, `updated_at`, `alamat`, `kapasitas`, `tanggal_pembuatan`, `pelapor_nama`, `pelapor_nrp`, `unit_id`) VALUES ('1', 'SPBU', 'SPBU Strategis Warudoyong', '7', '19', '-6.92560000', '106.92180000', 'approved', NULL, '3', '2026-07-12 15:29:16', '2026-07-12 15:29:16', 'Koridor utama Warudoyong', 'Tinggi', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Struktur tabel unit3_sosbud
DROP TABLE IF EXISTS `unit3_sosbud`;
CREATE TABLE `unit3_sosbud` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_organisasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pimpinan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_anggota` int unsigned DEFAULT NULL,
  `legalitas` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_aktivitas` text COLLATE utf8mb4_unicode_ci,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit3_sosbud_district_id_foreign` (`district_id`),
  KEY `unit3_sosbud_village_id_foreign` (`village_id`),
  KEY `unit3_sosbud_operator_id_foreign` (`operator_id`),
  KEY `unit3_sosbud_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit3_sosbud_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit3_sosbud_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit3_sosbud_unit_id_index` (`unit_id`),
  CONSTRAINT `unit3_sosbud_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit3_sosbud_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit3_sosbud_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `unit3_sosbud` (`id`, `kategori`, `nama_organisasi`, `pimpinan`, `district_id`, `village_id`, `koordinat_lat`, `koordinat_lng`, `status_laporan`, `catatan_validasi`, `operator_id`, `created_at`, `updated_at`, `total_anggota`, `legalitas`, `catatan_aktivitas`, `tanggal_pembuatan`, `pelapor_nama`, `pelapor_nrp`, `unit_id`) VALUES ('1', 'Ormas', 'Forum Sosial Kemasyarakatan Baros', 'Koordinator Wilayah', '1', '1', '-6.95200000', '106.92800000', 'draft', NULL, '4', '2026-07-12 15:29:16', '2026-07-12 15:29:16', '80', 'Terdata', 'Aktif dalam agenda sosial lokal.', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Struktur tabel unit4_security_crim
DROP TABLE IF EXISTS `unit4_security_crim`;
CREATE TABLE `unit4_security_crim` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_kasus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned DEFAULT NULL,
  `village_id` bigint unsigned DEFAULT NULL,
  `koordinat_lat` decimal(11,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status_laporan` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_validasi` text COLLATE utf8mb4_unicode_ci,
  `operator_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `modus` text COLLATE utf8mb4_unicode_ci,
  `status_kasus` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_enkripsi` longtext COLLATE utf8mb4_unicode_ci,
  `tanggal_pembuatan` date DEFAULT NULL,
  `pelapor_nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pelapor_nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit4_security_crim_district_id_foreign` (`district_id`),
  KEY `unit4_security_crim_village_id_foreign` (`village_id`),
  KEY `unit4_security_crim_operator_id_foreign` (`operator_id`),
  KEY `unit4_security_crim_tanggal_pembuatan_index` (`tanggal_pembuatan`),
  KEY `unit4_security_crim_pelapor_nama_index` (`pelapor_nama`),
  KEY `unit4_security_crim_pelapor_nrp_index` (`pelapor_nrp`),
  KEY `unit4_security_crim_unit_id_index` (`unit_id`),
  CONSTRAINT `unit4_security_crim_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit4_security_crim_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unit4_security_crim_village_id_foreign` FOREIGN KEY (`village_id`) REFERENCES `villages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `unit4_security_crim` (`id`, `kategori`, `nama_kasus`, `district_id`, `village_id`, `koordinat_lat`, `koordinat_lng`, `status_laporan`, `catatan_validasi`, `operator_id`, `created_at`, `updated_at`, `modus`, `status_kasus`, `data_enkripsi`, `tanggal_pembuatan`, `pelapor_nama`, `pelapor_nrp`, `unit_id`) VALUES ('1', 'Curanmor', 'Pemetaan Kasus Curanmor Citamiang', '4', '10', '-6.92620000', '106.93480000', 'submitted', NULL, '5', '2026-07-12 15:29:16', '2026-07-12 15:29:16', 'Pencurian kendaraan roda dua di area parkir terbuka.', 'Penyelidikan', 'eyJpdiI6InNGSTBoL2hZSjN6Q2NlaE1YRzFjcGc9PSIsInZhbHVlIjoidjF5VXJIY3FpZy9XTWJlbXBjWktsMVJXMTdGYTU4dE5KRVhUZHUwM3daNmNuOFpEL3pmK09hN1hGN1hrRXpLTFRFTkN0SlFBMTZyS3NwZjBVY1ljREs5Vk9UVERYd0FrSDJYVlZreFQ4RjQ9IiwibWFjIjoiMDczMTJmNmNlYmExYzUwZTVjMTIyMDkwZGRmNmVkZGI1ZDEwN2ViOWZjZGY0YjVmNTM3ZDBhNTUyNjkyMDgxNCIsInRhZyI6IiJ9', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Struktur tabel units
DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `nama_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kode_unit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `units_nama_unit_unique` (`nama_unit`),
  UNIQUE KEY `units_kode_unique` (`kode`),
  UNIQUE KEY `units_kode_unit_unique` (`kode_unit`),
  UNIQUE KEY `units_slug_unique` (`slug`),
  KEY `units_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `units` (`id`, `nama_unit`, `kode`, `kode_unit`, `slug`, `deskripsi`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Ideologi Politik', 'IP', 'IP', 'unit1', 'Unit bidang ideologi dan politik.', '1', '2026-07-12 15:29:04', '2026-07-12 15:29:09');
INSERT INTO `units` (`id`, `nama_unit`, `kode`, `kode_unit`, `slug`, `deskripsi`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Ekonomi', 'EKO', 'EKO', 'unit2', 'Unit bidang ekonomi dan objek vital ekonomi.', '1', '2026-07-12 15:29:04', '2026-07-12 15:29:09');
INSERT INTO `units` (`id`, `nama_unit`, `kode`, `kode_unit`, `slug`, `deskripsi`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Sosial Budaya', 'SOSBUD', 'SOSBUD', 'unit3', 'Unit bidang sosial dan budaya.', '1', '2026-07-12 15:29:04', '2026-07-12 15:29:09');
INSERT INTO `units` (`id`, `nama_unit`, `kode`, `kode_unit`, `slug`, `deskripsi`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Keamanan Negara', 'KAMNEG', 'KAMNEG', 'unit4', 'Unit bidang keamanan negara.', '1', '2026-07-12 15:29:04', '2026-07-12 15:29:09');

-- --------------------------------------------------------
-- Struktur tabel users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` tinyint unsigned NOT NULL DEFAULT '2',
  `unit_id` tinyint unsigned DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `login_attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `otp_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `nrp` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_nrp_index` (`nrp`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('1', 'Pimpinan Polres', 'pimpinan@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '1', NULL, '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 15:29:14', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('2', 'Operator Unit 1', 'operator1@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '2', '1', '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 15:29:14', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('3', 'Operator Unit 2', 'operator2@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '2', '2', '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 15:29:14', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('4', 'Operator Sosial Budaya', 'operator3@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '2', '3', '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 17:54:40', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('5', 'Operator Keamanan Negara', 'operator4@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '2', '4', '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 15:29:14', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('6', 'Kasat Intelkam', 'kasat@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '3', NULL, '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 15:29:14', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('7', 'Admin IT', 'admin@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '4', NULL, '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 15:29:14', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `unit_id`, `is_locked`, `login_attempts`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`, `nrp`, `phone`, `address`, `photo`) VALUES ('8', 'Super Admin IT', 'superadmin@sibdi.local', NULL, '$2y$12$ftmohQ.E3ZoLd8YAs57mjOOKgloyzHOQauSMfQ3XUvNKhgqx9ZwqW', '5', NULL, '0', '0', NULL, NULL, NULL, '2026-07-12 15:29:14', '2026-07-12 18:05:16', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Struktur tabel villages
DROP TABLE IF EXISTS `villages`;
CREATE TABLE `villages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `district_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `villages_district_id_name_unique` (`district_id`,`name`),
  CONSTRAINT `villages_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('1', '1', 'Baros', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('2', '1', 'Jayaraksa', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('3', '1', 'Sudajaya Hilir', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('4', '2', 'Cibeureum Hilir', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('5', '2', 'Sindangpalay', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('6', '2', 'Limusnunggal', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('7', '3', 'Cikole', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('8', '3', 'Gunungparang', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('9', '3', 'Kebonjati', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('10', '4', 'Citamiang', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('11', '4', 'Nanggeleng', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('12', '4', 'Tipar', '2026-07-12 15:29:15', '2026-07-12 15:29:15');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('13', '5', 'Gunungpuyuh', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('14', '5', 'Karamat', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('15', '5', 'Sriwidari', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('16', '6', 'Cikundul', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('17', '6', 'Lembursitu', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('18', '6', 'Sindangsari', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('19', '7', 'Benteng', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('20', '7', 'Dayeuhluhur', '2026-07-12 15:29:16', '2026-07-12 15:29:16');
INSERT INTO `villages` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES ('21', '7', 'Sukakarya', '2026-07-12 15:29:16', '2026-07-12 15:29:16');

SET FOREIGN_KEY_CHECKS=1;
