<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'levels' => [],
    'columns' => 12,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'levels' => [],
    'columns' => 12,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $normalized = collect($levels)->map(fn ($level) => max(0, min(4, (int) $level)));
?>

<div class="space-y-3">
    <div class="grid gap-1.5" style="grid-template-columns: repeat(<?php echo e($columns); ?>, minmax(0, 1fr));">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $normalized; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'aspect-square min-h-3 rounded-[4px] border border-line transition hover:scale-110',
                    'bg-surface-raised' => $level === 0,
                    'bg-accent/20' => $level === 1,
                    'bg-accent/40' => $level === 2,
                    'bg-accent/65' => $level === 3,
                    'bg-accent' => $level === 4,
                ]); ?>"
                title="Aktivitas level <?php echo e($level); ?>"
            ></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < 84; $i++): ?>
                <span class="aspect-square min-h-3 rounded-[4px] border border-line bg-surface-raised"></span>
            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="flex items-center justify-end gap-1.5 text-[10px] text-muted">
        <span>Rendah</span>
        <span class="size-2.5 rounded-[3px] border border-line bg-surface-raised"></span>
        <span class="size-2.5 rounded-[3px] bg-accent/25"></span>
        <span class="size-2.5 rounded-[3px] bg-accent/50"></span>
        <span class="size-2.5 rounded-[3px] bg-accent/75"></span>
        <span class="size-2.5 rounded-[3px] bg-accent"></span>
        <span>Tinggi</span>
    </div>
</div>
<?php /**PATH /home/adaloker/badig.sardev.biz.id/resources/views/components/ui/heatmap.blade.php ENDPATH**/ ?>