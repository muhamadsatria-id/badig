<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<style>
@page { margin: 16mm 14mm 16mm; }
body { font-family: DejaVu Sans, sans-serif; color: #172033; font-size: 9.3px; line-height: 1.48; }
.header { border-bottom: 2px solid #172033; padding-bottom: 10px; margin-bottom: 12px; }
.brand { font-size: 8px; font-weight: 800; letter-spacing: 1.1px; }
.title { text-align: center; font-size: 15px; font-weight: 800; margin: 9px 0 2px; }
.subtitle { text-align: center; font-size: 8.5px; color: #64748b; }
.hero { border: 1px solid #d7dee8; background: #f8fafc; padding: 11px; margin-bottom: 12px; }
.hero-title { font-size: 14px; font-weight: 800; color: #0f172a; }
.hero-meta { margin-top: 5px; color: #64748b; }
.section { margin-top: 14px; page-break-inside: avoid; }
.section-title { background: #172033; color: #fff; padding: 7px 9px; font-size: 8.7px; font-weight: 800; letter-spacing: .5px; }
.data { width: 100%; border-collapse: collapse; }
.data td { border: 1px solid #d7dee8; padding: 6px 8px; vertical-align: top; word-break: break-word; }
.data .label { width: 31%; background: #f8fafc; color: #475569; font-weight: 700; text-transform: capitalize; }
.sub-heading { font-size: 9px; font-weight: 800; color: #172033; margin-top: 10px; margin-bottom: 4px; padding-bottom: 3px; border-bottom: 1px dashed #cbd5e1; }
.image-grid { width: 100%; border-collapse: separate; border-spacing: 6px; margin-top: 6px; }
.image-cell { width: 50%; border: 1px solid #d7dee8; padding: 6px; vertical-align: top; text-align: center; background: #ffffff; }
.image-cell img { width: 100%; max-height: 220px; object-fit: contain; }
.doc-meta { margin-top: 5px; font-size: 8px; color: #64748b; text-align: left; }
.doc-grid { width: 100%; border-collapse: separate; border-spacing: 6px; margin-top: 6px; }
.doc-card { width: 50%; border: 1px solid #d7dee8; background: #f8fafc; padding: 9px; vertical-align: top; }
.doc-name { font-weight: 700; color: #0f172a; font-size: 9px; }
.doc-link { display: inline-block; margin-top: 6px; color: #1e40af; text-decoration: underline; font-weight: 700; font-size: 8.5px; }
.footer { margin-top: 22px; border-top: 1px solid #cbd5e1; padding-top: 7px; color: #64748b; font-size: 7.7px; }
</style>
</head>
<body>
<div class="header">
    <div class="brand">BADIG · BASIS DATA TERINTEGRASI SAT INTELKAM</div>
    <div class="title">DOKUMEN REKAM DATA INTERNAL</div>
    <div class="subtitle"><?php echo e(strtoupper($module['title'])); ?> · Nomor Rekam #<?php echo e($item->id); ?></div>
</div>

<div class="hero">
    <div class="hero-title"><?php echo e($item->{$module['main']} ?: 'Rekam Data #'.$item->id); ?></div>
    <div class="hero-meta">Kategori: <strong><?php echo e($item->kategori ?: '-'); ?></strong> · Tanggal: <strong><?php echo e(optional($item->tanggal_pembuatan)->format('d/m/Y') ?: '-'); ?></strong> · Operator: <strong><?php echo e($item->operator?->name ?: '-'); ?></strong></div>
</div>

<div class="section">
    <div class="section-title">A. IDENTITAS DAN ATRIBUT REKAM DATA</div>
    <table class="data">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $module['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $value=$item->{$field} ?? null;
    if($field==='district_id')$value=$item->district?->name;
    elseif($field==='village_id')$value=$item->village?->name;
    elseif($field==='tanggal_pembuatan')$value=optional($item->tanggal_pembuatan)->format('d/m/Y');
    elseif(in_array($field,['created_at','updated_at'],true))$value=optional($item->{$field})->format('d/m/Y H:i');
    ?>
    <tr><td class="label"><?php echo e(ucwords(str_replace('_',' ',$field))); ?></td><td><?php echo nl2br(e($value ?: '-')); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <tr><td class="label">Operator Registrasi</td><td><?php echo e($item->operator?->name ?: '-'); ?></td></tr>
    </table>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($attachmentImages->isNotEmpty() || $documentAttachments->isNotEmpty()): ?>
<div class="section">
    <div class="section-title">B. LAMPIRAN DOKUMEN PENDUKUNG</div>
    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($attachmentImages->isNotEmpty()): ?>
    <div class="sub-heading">📷 DOKUMENTASI FOTO / GAMBAR VISUAL</div>
    <table class="image-grid">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $attachmentImages->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td class="image-cell">
            <img src="<?php echo e($row['data_uri']); ?>">
            <div class="doc-meta">
                <strong><?php echo e($row['file']->original_name); ?></strong><br>
                Format <?php echo e(strtoupper($row['file']->extension)); ?> · <?php echo e($row['file']->human_file_size); ?>

            </div>
        </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chunk->count()===1): ?><td class="image-cell" style="border:none;background:transparent;"></td><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($documentAttachments->isNotEmpty()): ?>
    <div class="sub-heading">📁 BERKAS DOKUMEN PENDUKUNG (PDF / WORD / EXCEL / DLL)</div>
    <table class="doc-grid">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $documentAttachments->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td class="doc-card">
            <div class="doc-name">📄 <?php echo e($file->original_name); ?></div>
            <div class="doc-meta">
                Format: <strong><?php echo e(strtoupper($file->extension)); ?></strong> · Ukuran: <strong><?php echo e($file->human_file_size); ?></strong><br>
                Diunggah: <?php echo e(optional($file->created_at)->format('d/m/Y H:i')); ?>

            </div>
            <div style="margin-top:6px;">
                <a href="<?php echo e(route('units.attachments.download', [$unit, $file->id])); ?>" class="doc-link" target="_blank" rel="noopener noreferrer">🔗 Unduh melalui akses BADIG (<?php echo e(strtoupper($file->extension)); ?>)</a>
            </div>
        </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chunk->count()===1): ?><td class="doc-card" style="border:none;background:transparent;"></td><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="footer">Dicetak melalui BADIG pada <?php echo e(now()->format('d/m/Y H:i')); ?>. Tautan lampiran memerlukan sesi BADIG yang aktif dan otorisasi unit yang sesuai.</div>
</body>
</html>
<?php /**PATH /home/adaloker/badig.sardev.biz.id/resources/views/units/pdf_cetak.blade.php ENDPATH**/ ?>