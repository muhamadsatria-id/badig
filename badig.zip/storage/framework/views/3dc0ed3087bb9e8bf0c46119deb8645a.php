<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'name',
    'type' => 'text',
    'value' => null,
    'placeholder' => null,
    'required' => false,
    'readonly' => false,
    'disabled' => false,
    'icon' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'name',
    'type' => 'text',
    'value' => null,
    'placeholder' => null,
    'required' => false,
    'readonly' => false,
    'disabled' => false,
    'icon' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<flux:input
    name="<?php echo e($name); ?>"
    type="<?php echo e($type); ?>"
    :label="$label"
    value="<?php echo e(old($name, $value)); ?>"
    placeholder="<?php echo e($placeholder); ?>"
    :required="$required"
    :readonly="$readonly"
    :disabled="$disabled"
    <?php if($icon): ?> icon="<?php echo e($icon); ?>" <?php endif; ?>
    <?php echo e($attributes); ?>

/>
<?php /**PATH /home/adaloker/badig.sardev.biz.id/resources/views/components/form-input.blade.php ENDPATH**/ ?>