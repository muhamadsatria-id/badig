<!DOCTYPE html>
<html lang="id" class="min-h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php if (isset($component)) { $__componentOriginal20b086bb95a018fb9768b5ea61d158fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20b086bb95a018fb9768b5ea61d158fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.seo-head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.seo-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20b086bb95a018fb9768b5ea61d158fb)): ?>
<?php $attributes = $__attributesOriginal20b086bb95a018fb9768b5ea61d158fb; ?>
<?php unset($__attributesOriginal20b086bb95a018fb9768b5ea61d158fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20b086bb95a018fb9768b5ea61d158fb)): ?>
<?php $component = $__componentOriginal20b086bb95a018fb9768b5ea61d158fb; ?>
<?php unset($__componentOriginal20b086bb95a018fb9768b5ea61d158fb); ?>
<?php endif; ?>
    <script <?php echo 'nonce="'.e((string) request()->attributes->get('csp_nonce', '')).'"'; ?>>
        (function () {
            try {
                const savedTheme = localStorage.getItem('theme');
                const theme = savedTheme === 'light' ? 'light' : 'dark';
                document.documentElement.classList.toggle('dark', theme === 'dark');
                document.documentElement.dataset.theme = theme;
                document.documentElement.style.colorScheme = theme;
            } catch (error) {
                document.documentElement.classList.add('dark');
                document.documentElement.dataset.theme = 'dark';
                document.documentElement.style.colorScheme = 'dark';
            }
        })();
    </script>
    <link
    rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700,800&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="min-h-screen bg-base text-ink antialiased">
    <div class="fixed right-4 top-4 z-50 sm:right-6 sm:top-6">
        <?php if (isset($component)) { $__componentOriginalf68ff725785b54e52eb2f4f358bccde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf68ff725785b54e52eb2f4f358bccde0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.theme-toggle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.theme-toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf68ff725785b54e52eb2f4f358bccde0)): ?>
<?php $attributes = $__attributesOriginalf68ff725785b54e52eb2f4f358bccde0; ?>
<?php unset($__attributesOriginalf68ff725785b54e52eb2f4f358bccde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf68ff725785b54e52eb2f4f358bccde0)): ?>
<?php $component = $__componentOriginalf68ff725785b54e52eb2f4f358bccde0; ?>
<?php unset($__componentOriginalf68ff725785b54e52eb2f4f358bccde0); ?>
<?php endif; ?>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

<script <?php echo 'nonce="'.e((string) request()->attributes->get('csp_nonce', '')).'"'; ?>>
document.addEventListener('submit', (event) => {
    const form = event.target.closest('form[data-confirm]');
    if (form && !window.confirm(form.dataset.confirm || 'Lanjutkan tindakan ini?')) {
        event.preventDefault();
    }
});
document.addEventListener('click', (event) => {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    if (target.dataset.action === 'reload-page') window.location.reload();
    if (target.dataset.action === 'print-page') window.print();
});
</script>

    <?php if (isset($component)) { $__componentOriginal929715dcacade4e957f0bc5aff0c8a6d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal929715dcacade4e957f0bc5aff0c8a6d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cookie-consent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cookie-consent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal929715dcacade4e957f0bc5aff0c8a6d)): ?>
<?php $attributes = $__attributesOriginal929715dcacade4e957f0bc5aff0c8a6d; ?>
<?php unset($__attributesOriginal929715dcacade4e957f0bc5aff0c8a6d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal929715dcacade4e957f0bc5aff0c8a6d)): ?>
<?php $component = $__componentOriginal929715dcacade4e957f0bc5aff0c8a6d; ?>
<?php unset($__componentOriginal929715dcacade4e957f0bc5aff0c8a6d); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH E:\Projects\Laravel\badig\resources\views/layouts/guest.blade.php ENDPATH**/ ?>