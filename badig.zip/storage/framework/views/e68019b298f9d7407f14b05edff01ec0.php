<?php $__env->startSection('title', 'Super Admin'); ?>
<?php $__env->startSection('page_title', 'Super Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full min-w-0">
    <div class="rounded-2xl border border-line bg-gradient-to-br from-surface-raised to-surface p-5 shadow-sm sm:p-6 badig-card">
        <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
            <div class="space-y-1">
                <div class="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-muted">
                    <span class="material-symbols-outlined text-base text-muted">admin_panel_settings</span>
                    Ruang kendali sistem
                </div>
                <h2 class="text-xl font-semibold tracking-tight text-ink">
                    Ruang Kendali Super Admin
                </h2>
                <p class="max-w-2xl text-sm leading-6 text-muted">
                    Otoritas sistem level 5 untuk pengelolaan akun, audit, backup, dan akses lintas unit.
                </p>
            </div>

            <div class="inline-flex items-center gap-2 rounded-full border border-line bg-surface px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.24em] text-muted shadow-sm">
                <span class="material-symbols-outlined text-base text-muted">shield_person</span>
                Access Level 5
            </div>
        </div>
    </div>

    <div class="mt-6 min-w-0 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [
            ['label' => 'Total Pengguna', 'value' => $stats['users'], 'icon' => 'groups'],
            ['label' => 'Super Admin', 'value' => $stats['super_admins'], 'icon' => 'shield_person'],
            ['label' => 'Audit Internal', 'value' => $stats['audit'], 'icon' => 'receipt_long'],
            ['label' => 'Backup Sistem', 'value' => $stats['backups'], 'icon' => 'database'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-2xl border border-line bg-surface p-4 shadow-sm badig-card">
                <div class="flex items-start justify-between gap-3">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-[0.24em] text-faint"><?php echo e($card['label']); ?></p>
                        <h3 class="mt-2 text-2xl font-semibold tracking-tight text-ink"><?php echo e($card['value']); ?></h3>
                    </div>
                    <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-surface-raised text-muted">
                        <span class="material-symbols-outlined text-lg"><?php echo e($card['icon']); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- <div class="mt-6 min-w-0 grid gap-6 xl:grid-cols-3">
        <div class="xl:col-span-2 rounded-2xl border border-line bg-surface p-5 shadow-sm badig-card">
            <div class="space-y-1">
                <h3 class="text-sm font-semibold text-ink">Akses Cepat Sistem</h3>
                <p class="text-sm text-muted">Navigasi utama untuk mengelola akun, audit, backup, dan file global.</p>
            </div>

            <div class="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-2 rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm font-semibold text-muted transition hover:border-accent/30 hover:bg-surface-raised">
                    <span class="material-symbols-outlined text-base text-faint">dashboard</span>
                    Dashboard Utama
                </a>
                <a href="<?php echo e(route('pimpinan.file-manager')); ?>" class="flex items-center gap-2 rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm font-semibold text-muted transition hover:border-accent/30 hover:bg-surface-raised">
                    <span class="material-symbols-outlined text-base text-faint">folder_managed</span>
                    File Manager Global
                </a>
                <a href="<?php echo e(route('reports.index')); ?>" class="flex items-center gap-2 rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm font-semibold text-muted transition hover:border-accent/30 hover:bg-surface-raised">
                    <span class="material-symbols-outlined text-base text-faint">block</span>
                    Status Alur Lama
                </a>
                <a href="<?php echo e(route('admin.users')); ?>" class="flex items-center gap-2 rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm font-semibold text-muted transition hover:border-accent/30 hover:bg-surface-raised">
                    <span class="material-symbols-outlined text-base text-faint">manage_accounts</span>
                    Manajemen Pengguna
                </a>
                <a href="<?php echo e(route('admin.audit')); ?>" class="flex items-center gap-2 rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm font-semibold text-muted transition hover:border-accent/30 hover:bg-surface-raised">
                    <span class="material-symbols-outlined text-base text-faint">receipt_long</span>
                    Log Audit Trail
                </a>
                <a href="<?php echo e(route('admin.backup')); ?>" class="flex items-center gap-2 rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm font-semibold text-muted transition hover:border-accent/30 hover:bg-surface-raised">
                    <span class="material-symbols-outlined text-base text-faint">database</span>
                    Pencadangan Sistem
                </a>
            </div>

            <div class="mt-6 min-w-0 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['unit1' => 'Ideologi Politik', 'unit2' => 'Ekonomi', 'unit3' => 'Sosial Budaya', 'unit4' => 'Keamanan Negara']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('units.index', $key)); ?>" class="rounded-xl bg-accent px-3 py-3 text-center text-[#07140c] transition hover:bg-accent-strong">
                        <div class="text-[10px] font-semibold uppercase tracking-[0.24em] text-faint"><?php echo e($label); ?></div>
                        <div class="mt-1 text-base font-semibold"><?php echo e($stats[$key]); ?></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="rounded-2xl border border-line bg-surface p-5 shadow-sm badig-card">
            <div class="space-y-1">
                <h3 class="text-sm font-semibold text-ink">Aktivitas Privilege</h3>
                <p class="text-sm text-muted">Jejak log mutasi sistem internal level root.</p>
            </div>

            <div class="mt-4 space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $superLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="rounded-xl border border-line bg-surface-raised px-3 py-3 text-sm">
                        <div class="flex items-center justify-between gap-3 text-[11px] text-faint">
                            <span><?php echo e($log->created_at?->format('d/m/Y H:i')); ?></span>
                            <span class="truncate max-w-[120px]"><?php echo e($log->user?->email); ?></span>
                        </div>
                        <div class="mt-1 font-semibold text-ink"><?php echo e($log->action); ?></div>
                        <p class="mt-1 text-sm leading-6 text-muted"><?php echo e($log->description); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="rounded-xl border border-dashed border-line bg-surface px-3 py-8 text-center text-sm text-muted">
                        Belum ada aktivitas mutasi yang terekam.
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div> -->

    <div class="mt-6 overflow-hidden rounded-2xl border border-line bg-surface shadow-sm badig-card">
        <div class="border-b border-line bg-surface-raised px-5 py-4">
            <h3 class="text-sm font-semibold text-ink">Daftar Akun Sistem Komplit</h3>
            <p class="mt-1 text-sm text-muted">Menampilkan seluruh pengguna terdaftar yang memiliki akses sistem.</p>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-line text-sm">
                <thead class="bg-surface-raised text-muted">
                    <tr>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em]">Nama Personel</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em]">Alamat Email</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em]">Tingkat Otoritas</th>
                        <th class="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.24em]">Status Akses</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line bg-surface">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-surface-raised">
                            <td class="whitespace-nowrap px-4 py-3 font-semibold text-ink"><?php echo e($user->name); ?></td>
                            <td class="whitespace-nowrap px-4 py-3 font-mono text-sm text-muted"><?php echo e($user->email); ?></td>
                            <td class="whitespace-nowrap px-4 py-3">
                                <span class="inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold <?php echo e($user->isSuperAdmin() ? 'bg-accent text-white' : 'bg-surface-raised text-muted'); ?>">
                                    <?php echo e($user->roleName()); ?>

                                </span>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3">
                                <span class="inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold <?php echo e($user->is_locked ? 'bg-[var(--danger-soft)] text-danger' : 'bg-[var(--accent-soft)] text-accent'); ?>">
                                    <?php echo e($user->is_locked ? 'Suspended / Locked' : 'Active / Granted'); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\Laravel\badig\resources\views/super-admin/index.blade.php ENDPATH**/ ?>