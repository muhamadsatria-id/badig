<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'color' => 'neutral',
    'dot' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'color' => 'neutral',
    'dot' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classes = match ($color) {
        'success' => 'border-accent/20 bg-[var(--accent-soft)] text-accent-strong dark:text-accent',
        'warning' => 'border-warning/20 bg-[var(--warning-soft)] text-warning',
        'danger' => 'border-danger/20 bg-[var(--danger-soft)] text-danger',
        default => 'border-line bg-surface-raised text-muted',
    };
?>

<span <?php echo e($attributes->class("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] {$classes}")); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dot): ?>
        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'size-1.5 rounded-full',
            'bg-accent' => $color === 'success',
            'bg-warning' => $color === 'warning',
            'bg-danger' => $color === 'danger',
            'bg-faint' => $color === 'neutral',
        ]); ?>"></span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php echo e($slot); ?>

</span>
<?php /**PATH /home/adaloker/badig.sardev.biz.id/resources/views/components/ui/badge.blade.php ENDPATH**/ ?>