<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
            color: #0f172a;
            margin: 20px;
            line-height: 1.4;
        }

        .header {
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 12px;
            margin-bottom: 14px;
        }

        .title {
            font-size: 16px;
            font-weight: 700;
            margin: 0 0 4px;
            color: #0f172a;
        }

        .subtitle {
            font-size: 9px;
            color: #64748b;
            margin: 0;
        }

        .summary {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 10px 12px;
            margin-bottom: 12px;
        }

        .summary p {
            margin: 0 0 3px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9px;
        }

        th, td {
            border: 1px solid #d1d5db;
            padding: 6px;
            vertical-align: top;
            text-align: left;
        }

        th {
            background: #f1f5f9;
            font-weight: 700;
            color: #334155;
        }

        tr:nth-child(even) td {
            background: #fcfdff;
        }
    </style>
</head>
<body>
    <?php
        $rows = $people ?? [];
        $totalPeople = count($rows);
    ?>

    <div class="header">
        <h1 class="title">Daftar Data Orang BADIG</h1>
        <p class="subtitle">Daftar data orang yang diekspor secara resmi pada <?php echo e(now()->format('d-m-Y H:i')); ?>.</p>
    </div>

    <div class="summary">
        <p><strong>Total Data:</strong> <?php echo e($totalPeople); ?></p>
        <p><strong>Dicetak:</strong> <?php echo e(now()->format('d-m-Y H:i')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Unit</th>
                <th>NIK</th>
                <th>NRP</th>
                <th>Kontak</th>
                <th>Alamat</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $orang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($orang->nama ?? '-'); ?></td>
                    <td><?php echo e($orang->unit?->nama_unit ?? '-'); ?></td>
                    <td><?php echo e($orang->nik ?? '-'); ?></td>
                    <td><?php echo e($orang->nrp ?? '-'); ?></td>
                    <td><?php echo e($orang->phone ?? '-'); ?><br><?php echo e($orang->email ?? '-'); ?></td>
                    <td><?php echo e($orang->alamat ?? '-'); ?></td>
                    <td><?php echo e($orang->keterangan ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH E:\Projects\Laravel\badig\resources\views/database-orang/pdf.blade.php ENDPATH**/ ?>