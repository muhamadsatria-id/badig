<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        @page {
            /* Margin standar surat dinas kepolisian */
            margin: 15mm 15mm 15mm 15mm;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            color: #000000;
            font-size: 10pt;
            line-height: 1.25;
            position: relative; /* Penting untuk penempatan watermark */
        }
        
        /* --- WATERMARK SETTINGS --- */
        .watermark {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 350px; /* Atur ukuran lebar logo watermark di sini */
            height: auto;
            opacity: 0.12; /* Tingkat transparansi (0.1 = sangat samar, 0.2 = jelas) */
            z-index: -1000; /* Memastikan watermark berada di belakang teks dan tabel */
            text-align: center;
        }
        .watermark img {
            width: 100%;
            height: auto;
            object-fit: contain;
        }

        /* --- KOP SURAT KIRI ATAS --- */
        .kop-surat {
            text-align: left;
            font-size: 10pt;
            font-weight: bold;
            line-height: 1.15;
            margin-bottom: 15px;
        }
        .kop-surat .underline {
            text-decoration: underline;
        }
        .pro-justitia {
            margin-top: 3px;
            font-weight: bold;
        }

        /* --- JUDUL DPO / DATA ORANG --- */
        .title-section {
            text-align: center;
            margin-bottom: 12px;
        }
        .emblem-placeholder {
            font-size: 14pt;
            margin-bottom: 2px;
            letter-spacing: 3px;
        }
        .dpo-title {
            font-size: 12pt;
            font-weight: bold;
            text-decoration: underline;
            letter-spacing: 0.5px;
        }
        .dpo-number {
            font-size: 10pt;
            margin-top: 2px;
        }

        /* --- TABEL ATAS (FOTO & INSTRUKSI) --- */
        .top-box {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #000000;
            background-color: transparent; /* Memastikan background transparan */
        }
        .top-box td {
            border: 1px solid #000000;
            padding: 8px;
            vertical-align: top;
            font-size: 9.5pt;
            background-color: transparent;
        }
        .photo-cell {
            width: 22%;
            text-align: center;
            vertical-align: middle !important;
        }
        .photo-frame {
            width: 110px;
            height: 140px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .photo-frame img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* --- TABEL KETERANGAN --- */
        .keterangan-header {
            text-align: center;
            font-weight: bold;
            letter-spacing: 3px;
            text-decoration: underline;
            padding: 6px 0;
            border-left: 1px solid #000000;
            border-right: 1px solid #000000;
            background-color: transparent;
        }
        .keterangan-table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #000000;
            border-top: none;
            background-color: transparent;
        }
        .keterangan-table td {
            padding: 3px 6px;
            vertical-align: top;
            border: none;
            font-size: 9.5pt;
            background-color: transparent;
        }
        .col-num {
            width: 4%;
            text-align: left;
        }
        .col-label {
            width: 38%;
        }
        .col-colon {
            width: 3%;
            text-align: center;
        }
        .col-val {
            width: 55%;
        }

        /* Tabel khusus untuk poin (Ciri-ciri) */
        .sub-table {
            width: 100%;
            border-collapse: collapse;
            background-color: transparent;
        }
        .sub-table td {
            padding: 1px 0;
            font-size: 9.5pt;
            background-color: transparent;
        }
        .sub-num {
            width: 20px;
        }

        /* --- BAGIAN TANDA TANGAN & DISTRIBUSI --- */
        .footer-table {
            width: 100%;
            margin-top: 15px;
            border-collapse: collapse;
            page-break-inside: avoid;
            background-color: transparent;
        }
        .footer-table td {
            vertical-align: top;
            border: none;
            padding: 0;
            font-size: 9.5pt;
            background-color: transparent;
        }
        .sign-gap {
            height: 55px;
        }
        .font-bold {
            font-weight: bold;
        }
        .underline {
            text-decoration: underline;
        }

        /* --- LAMPIRAN (PAGE BREAK) --- */
        .attachment-section {
            page-break-before: always;
            margin-top: 20px;
        }
        .image-grid {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .image-grid td {
            width: 50%;
            border: 1px solid #000000;
            padding: 8px;
            text-align: center;
        }
        .image-grid img {
            max-width: 90%;
            height: 160px;
            object-fit: contain;
        }
    </style>
</head>
<body>

    <div class="watermark">
        <img src="<?php echo e(asset('logo-badig.png')); ?>" alt="Watermark BADIG">
    </div>

    <div class="kop-surat">
        KEPOLISIAN NEGARA REPUBLIK INDONESIA<br>
        DAERAH <?php echo e(strtoupper($orang->polda ?: 'JAWA BARAT')); ?><br>
        RESOR <?php echo e(strtoupper($orang->instansi ?: 'KOTA BANDUNG')); ?><br>
        <span class="underline">Jl. Perintis Kemerdekaan No.10, Gunungparang <br> Kec. Cikole, Kota Sukabumi, Jawa Barat </span>
    </div>

    <div class="title-section">
        <div class="emblem-placeholder"></div>
        <div class="dpo-title">DAFTAR ORANG</div>
        <div class="dpo-number">Nomor : <?php echo e($orang->nomor_dpo ?: 'ORANG/80/VII/RES.1.11./2025/Sat Reskrim'); ?></div>
    </div>

    <table class="top-box">
        <tr>
            <td class="photo-cell">
                <div class="photo-frame">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($photoDataUri): ?>
                        <img src="<?php echo e($photoDataUri); ?>" alt="Foto Orang">
                    <?php else: ?>
                        <div style="font-weight: bold; color: #555; padding-top: 55px;">FOTO</div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </td>
            <td style="width: 43%;">
                Untuk diawasi/ ditangkap/ diserahkan/ diinformasikan keberadaannya kepada Agen/ Agen Pembantu pada kantor Kepolisian tersebut di atas, dengan nomor Hp. <strong><?php echo e($orang->no_hp_penyidik ?: '-'); ?></strong>.<br><br>
                di<br>
                <strong><?php echo e($orang->tempat_dikeluarkan ?: 'Soreang'); ?></strong>
            </td>
            <td style="width: 35%;">
                Tersebut dalam surat permintaan dari :<br>
                <?php echo e($orang->instansi ?: 'Kepala Resor Kepolisian Kota Bandung'); ?><br>
                Nomor &nbsp; : <?php echo e($orang->no_reg_kejahatan ?: '-'); ?><br>
                Tanggal : <?php echo e(optional($orang->tanggal_dikeluarkan)->format('d F Y') ?: '-'); ?>

            </td>
        </tr>
    </table>

    <div class="keterangan-header">K E T E R A N G A N</div>

    <table class="keterangan-table">
        <tr>
            <td class="col-num">1.</td>
            <td class="col-label">Nama</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e(strtoupper($orang->nama ?: '-')); ?></td>
        </tr>
        <tr>
            <td class="col-num">2.</td>
            <td class="col-label">Nomor identitas [KTP/ SIM/ Paspor/ dll]</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->nik ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num">3.</td>
            <td class="col-label">Kewarganegaraan</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->kewarganegaraan ?: 'Indonesia'); ?></td>
        </tr>
        <tr>
            <td class="col-num">4.</td>
            <td class="col-label">Jenis kelamin</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->jenis_kelamin ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num">5.</td>
            <td class="col-label">Tempat tanggal lahir</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->tempat_lahir ?: '-'); ?>, <?php echo e(optional($orang->tanggal_lahir)->format('d F Y') ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num">6.</td>
            <td class="col-label">Pekerjaan terakhir / dahulu</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->pekerjaan ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num">7.</td>
            <td class="col-label">Alamat tempat tinggal</td>
            <td class="col-colon">:</td>
            <td class="col-val">
                <?php echo e($orang->alamat ?: '-'); ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orang->alamat_alternatif): ?>
                    <br><em>Alt: <?php echo e($orang->alamat_alternatif); ?></em>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </td>
        </tr>
        <tr>
            <td class="col-num">8.</td>
            <td class="col-label">[No. (Telp./Hp.)/ email / Fax / Akun Medsos]</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->phone ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num">9.</td>
            <td class="col-label">Catatan pernah dihukum dan sebagainya</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->catatan_hukum ?: 'Tidak Pernah menjalani hukuman;'); ?></td>
        </tr>
        <tr>
            <td class="col-num">10.</td>
            <td class="col-label">Ciri &ndash; ciri khusus</td>
            <td class="col-colon">:</td>
            <td class="col-val">
                <table class="sub-table">
                    <tr><td class="sub-num">a.</td><td>Tinggi/ Berat : <?php echo e($orang->tinggi_badan ?: '-'); ?> cm/ <?php echo e($orang->berat_badan ?: '-'); ?> kg;</td></tr>
                    <tr><td class="sub-num">b.</td><td>Rambut <?php echo e($orang->rambut ?: '-'); ?>;</td></tr>
                    <tr><td class="sub-num">c.</td><td>Bentuk tubuh <?php echo e($orang->bentuk_tubuh ?: '-'); ?>;</td></tr>
                    <tr><td class="sub-num">d.</td><td>Warna kulit <?php echo e($orang->warna_kulit ?: '-'); ?>;</td></tr>
                    <tr><td class="sub-num">e.</td><td>Mata <?php echo e($orang->warna_mata ?: '-'); ?>;</td></tr>
                    <tr><td class="sub-num">f.</td><td>Hidung <?php echo e($orang->hidung ?: '-'); ?>;</td></tr>
                    <tr><td class="sub-num">g.</td><td>Bibir <?php echo e($orang->bibir ?: '-'); ?>;</td></tr>
                    <tr><td class="sub-num">h.</td><td>Lainnya <?php echo e($orang->ciri_lainnya ?: '-'); ?>.</td></tr>
                </table>
            </td>
        </tr>
        
        <tr>
            <td class="col-num" style="padding-top: 6px;">11.</td>
            <td colspan="3" style="padding-top: 6px; padding-right: 8px; text-align: justify;">
                Subjek diduga terkait <?php echo e($orang->dugaan_tindak_pidana ?: '-'); ?> 
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orang->analisis_deskripsi): ?>
                    berupa <?php echo e($orang->analisis_deskripsi); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orang->melanggar_pasal): ?>
                    , sebagaimana dimaksud dalam pasal <?php echo e($orang->melanggar_pasal); ?>.
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </td>
        </tr>

        <tr>
            <td class="col-num">12.</td>
            <td class="col-label">Melanggar Pasal</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->melanggar_pasal ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num">13.</td>
            <td class="col-label">No. Reg. Kejahatan/ Pelanggaran</td>
            <td class="col-colon">:</td>
            <td class="col-val"><?php echo e($orang->no_reg_kejahatan ?: '-'); ?></td>
        </tr>
        <tr>
            <td class="col-num" style="padding-bottom: 8px;">14.</td>
            <td class="col-label" style="padding-bottom: 8px;">Keterangan lain yang penting</td>
            <td class="col-colon" style="padding-bottom: 8px;">:</td>
            <td class="col-val" style="padding-bottom: 8px;"><?php echo e($orang->keterangan_lain ?: '-'); ?></td>
        </tr>
    </table>

    <table class="footer-table">
        <tr>
            <td style="width: 45%;">
                Kepada :<br><br>
                1. Direskrimum jajaran.<br>
                2. Kapolres jajaran.<br>
                3. Kapolsek jajaran.
            </td>
            <td style="width: 55%; text-align: center;">
                <?php echo e($orang->tempat_dikeluarkan ?: 'Soreang'); ?>, <?php echo e(optional($orang->tanggal_dikeluarkan)->format('d F Y') ?: now()->format('d F Y')); ?><br>
                An. KAPOLRESTA KOTA SUKABUMI
                <div class="sign-gap"></div>
                <span class="underline font-bold"><?php echo e(strtoupper($orang->pejabat_penandatangan ?: '........................................')); ?></span><br>
                <?php echo e(strtoupper($orang->pangkat_penandatangan ?: 'KOMISARIS POLISI')); ?> NRP <?php echo e($orang->nrp_penandatangan ?: '....................'); ?>

            </td>
        </tr>
    </table>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($attachmentImages->isNotEmpty() || $documentAttachments->isNotEmpty()): ?>
        <div class="attachment-section">
            <div style="font-weight: bold; text-decoration: underline; margin-bottom: 10px;">LAMPIRAN DOKUMENTASI & BERKAS PENDUKUNG</div>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($attachmentImages->isNotEmpty()): ?>
                <table class="image-grid">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $attachmentImages->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <img src="<?php echo e($row['data_uri']); ?>" alt="Lampiran">
                                    <div style="font-size: 8pt; margin-top: 4px;"><?php echo e($row['file']->original_name); ?></div>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?> 
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chunk->count() === 1): ?>
                                <td></td>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </table>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($documentAttachments->isNotEmpty()): ?>
                <div style="margin-top: 15px; font-weight: bold; font-size: 9pt;">Daftar Berkas Lampiran:</div>
                <ul style="font-size: 9pt; padding-left: 20px; margin-top: 5px;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $documentAttachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e($file->original_name); ?></strong> (<?php echo e(strtoupper($file->extension)); ?> - <?php echo e($file->human_file_size); ?>)</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</body>
</html><?php /**PATH /home/adaloker/badig.sardev.biz.id/resources/views/database-orang/dpo-pdf.blade.php ENDPATH**/ ?>